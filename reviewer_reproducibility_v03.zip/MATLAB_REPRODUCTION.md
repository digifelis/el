# Closed-loop vehicle reproduction

Requires **MATLAB R2025b (25.2), Simulink, Powertrain Blockset**, and a working supported compiler if MATLAB requests one for model-reference simulation targets. A license is required. The proprietary MathWorks vehicle is not in this archive.

Create the model with Virtual Vehicle Composer, Configure Virtual Vehicle → Electric, 1 EM:

* Front Wheel Drive; Electric Motors: 1EM; Electric Machine 1: Electric Vehicle 1EM – Mapped Motor.
* Energy Storage: Mapped Battery (Electric Vehicle 1EM); Battery Management System: Battery Management System.
* VCU: EV 1EM with BMS (`EvPowertrainControllerBMS`).
* Driver: Longitudinal Driver; Body: Vehicle Body 3DOF Longitudinal.
* Brake Control: Open Loop; no engine or engine controller.
* Differential: Open / No Control; DC-DC: HVDCPassThrough.
* Test plan: Drive Cycle (`Scenario.sldd`), initial FTP75. The run script replaces this with a workspace cycle.
* Build `ConfiguredEv1EmVirtualVehicle.slx`. Preserve the surrounding project and data dictionaries.

The `--model-root` directory must contain `VirtualVehicle/VirtualVehicle/VirtualVehicle.prj`. The vehicle has a 96S47P pack, nominal cell capacity 2.6958 Ah, and the mapped-battery OCV/resistance tables. The supplied small table export is the exact table input used by the study; it must correspond to your generated model. See source attribution before public redistribution.

From the package folder, using the Python environment installed for the core package:

```powershell
python run_matlab.py --model-root "D:\reference_vehicle" --matlab "C:\Program Files\MATLAB\R2025b\bin\matlab.exe" --work "D:\review_run"
```

Use an **unused** output directory and prefer a short path. The runner copies the generated project into that directory, excluding old caches, and executes only that copy. It never saves the author's original project. It also copies the integration scripts and data into the run. A new MATLAB batch process executes the 18-case controller matrix and 8-case BMS-error matrix. Logs and numerical comparisons are written in the run directory. Timing columns are excluded; all other CSV values are checked with the core tolerance. Missing outputs or NaN values where the reference is finite fail the comparison.

`pt_run.m` now reads `EVBMS_PT_MODEL_ROOT`; data/output paths resolve relative to the copied scripts. These are filesystem-only edits, listed in `provenance/portability_changes.json`. Controller equations, configuration matrices and metric extraction are unchanged. Review `soh_limit_law.m` and `insert_law.m` for the inserted limit law and bus connections.

Changing MATLAB release, Composer variants, solver settings, data dictionaries or the configured controller can change the results. See `validation/` for actual local reproduction status. Configuration instructions alone are not evidence that a different model build reproduced the paper.

If the build stops with `rt_nonfinite.c: error C2099: initializer is not a constant`, rerun into a new output directory with `--msvc-nan-workaround`. This passes `/D_UCRT_NOISY_NAN` to MSVC via the child process's `CL` environment variable, without changing model equations or system configuration. This compiler definition is the workaround documented by the [MathWorks Support Team](https://www.mathworks.com/matlabcentral/answers/2173510-why-rapid-accelerator-simulation-fails-with-visual-studio-compiler-error-rt_nonfinite-c-4-error) for a Windows SDK NaN initialization bug. The report records whether it was enabled.

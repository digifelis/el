"""Run the two closed-loop matrices on a disposable copy of a licensed vehicle project."""
from pathlib import Path
import argparse, json, os, shutil, subprocess, time
from reproduce import ROOT, compare

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--model-root',required=True,help='Directory containing VirtualVehicle/VirtualVehicle/VirtualVehicle.prj')
    ap.add_argument('--matlab',default='matlab')
    ap.add_argument('--work',required=True,help='New writable run directory; short absolute path recommended')
    ap.add_argument('--msvc-nan-workaround',action='store_true',help='Pass /D_UCRT_NOISY_NAN to MSVC for the documented Windows SDK NaN initializer bug')
    a=ap.parse_args();src=Path(a.model_root).resolve();work=Path(a.work).resolve()
    if work.is_relative_to(src):raise SystemExit('The work directory must be outside the source model project')
    if not (src/'VirtualVehicle/VirtualVehicle/VirtualVehicle.prj').is_file():raise SystemExit('Expected VirtualVehicle/VirtualVehicle/VirtualVehicle.prj missing')
    if work.exists():raise SystemExit('Choose a new --work directory')
    work.mkdir(parents=True)
    shutil.copytree(ROOT/'yeni_calisma',work/'yeni_calisma',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.nbc','*.nbi'))
    (work/'yeni_calisma/sonuclar').mkdir()
    model=work/'model'
    shutil.copytree(src,model,ignore=shutil.ignore_patterns('b','slprj','*.slxc','.git'))
    env=os.environ.copy();env['EVBMS_PT_MODEL_ROOT']=str(model);env.pop('PT_NOINSERT',None)
    if a.msvc_nan_workaround:env['CL']=(env.get('CL','')+' /D_UCRT_NOISY_NAN').strip()
    kod=work/'yeni_calisma/kod/powertrain'
    quote=lambda p:str(p).replace('\\','/').replace("'","''")
    command=f"addpath('{quote(kod)}'); pt_matrix; pt_matrix2; bdclose('all');"
    start=time.time()
    with (work/'matlab.log').open('w',encoding='utf-8') as log:
        proc=subprocess.run([a.matlab,'-batch',command],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
    checks=[]
    for name in ('faz5_kapali_cevrim.csv','faz5b_bms_hata.csv'):
        actual=work/'yeni_calisma/sonuclar'/name
        if actual.exists():checks.append(compare(actual,ROOT/'reference_results'/name))
        else:checks.append({'file':name,'pass':False,'error':'missing output'})
    report={'stage':'matlab','exit_code':proc.returncode,'msvc_nan_workaround':a.msvc_nan_workaround,'elapsed_seconds':time.time()-start,'comparisons':checks,
            'pass':proc.returncode==0 and all(c['pass'] for c in checks)}
    (work/'validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return report['pass']

if __name__=='__main__':raise SystemExit(0 if main() else 1)

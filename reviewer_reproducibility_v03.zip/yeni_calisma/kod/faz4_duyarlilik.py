"""Aşama 4: Parametre ve BMS-bilgisi duyarlılığı.

Her tedirgin parametre ve temsilî senaryo için indirgenmiş ızgarada oracle ayarlı sınır:
  (a) aware_S'nin unaware'a göre kazancı (ε=2% kontrolcü-kaynaklı güç kısıtında en düşük kayıp farkı)
  (b) aware_RS'nin pencere ihlalsiz çözüm bulup bulmadığı ve kayıp bedeli
BMS bilgi hatası: kR_nom (BMS'in bildiği direnç artışı katsayısı) ve SoH tahmin hatası.
Çıktı: sonuclar/faz4_duyarlilik.csv"""
import itertools, sys
from dataclasses import replace
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from evbms import Controller, Params, Scenario, simulate
from optimize import LIQUID, AIR, NOMINAL, OUT

CASES = [
    ("UDDS_25C_SoH80", Scenario(cycle="UDDS", T_amb_C=25, SoH0=0.8, soc0=0.9), LIQUID),
    ("WLTP_25C_SoH60", Scenario(cycle="WLTP", T_amb_C=25, SoH0=0.6, soc0=0.8), LIQUID),
    ("UDDSx4_45C_SoH80_air", Scenario(cycle="UDDS", n_rep=4, T_amb_C=45, SoH0=0.8, soc0=0.9), AIR),
    ("WLTP_-10C_SoH60", Scenario(cycle="WLTP", T_amb_C=-10, SoH0=0.6, soc0=0.3), LIQUID),
    ("WLTP_0C_SoH75_lowSoC", Scenario(cycle="WLTP", T_amb_C=0, SoH0=0.75, soc0=0.3), LIQUID),
    ("US06_25C_SoH65", Scenario(cycle="US06", T_amb_C=25, SoH0=0.65, soc0=0.9), LIQUID),
]
# (etiket, parametre-değişimi, BMS-bilgi değişimi)
PERT = [("baz", {}, {})]
for v in (0.5, 3.0, 5.0): PERT.append((f"kR_true={v}", {"kR_true": v}, {"kR_nom": v}))     # gerçek ve BMS bilgisi birlikte
for v in (15e3, 40e3, 60e3): PERT.append((f"E_R={v/1e3:.0f}kJ", {"E_R_J_mol": v}, {}))
for v in (20e3, 55e3, 0.0, -30e3): PERT.append((f"E_a={v/1e3:.0f}kJ", {"Ea_age_J_mol": v}, {}))
for v in (0.0, 1.0): PERT.append((f"gamma={v}", {"gamma_C": v}, {}))
PERT.append(("gamma_dis=0,gamma_ch=2", {"gamma_dis_C": 0.0, "gamma_C": 2.0}, {}))   # Bodnár2025/Preger2020: deşarj C-oranı etkisi küçük, şarj etkisi büyük
# kaynaklarla uyumlu birleşik durum: k_R=3 (Lee2025), E_R=40 kJ/mol (Ludwig2022 aralığı), E_a=58 kJ/mol (Schmalstieg2014 takvim), deşarj-γ=0
PERT.append(("literatur_birlesik", {"kR_true": 3.0, "E_R_J_mol": 40e3, "Ea_age_J_mol": 58e3, "gamma_dis_C": 0.0}, {"kR_nom": 3.0}))
for v in (0.4, 1.0): PERT.append((f"regen_share={v}", {"regen_share": v}, {}))
for v in (2.0, 4.0): PERT.append((f"thermal_mass={v}", {"thermal_mass_factor": v}, {}))
for v in (0.5, 2.0): PERT.append((f"BMS_kR_nom={v}x", {}, {"kR_nom": 1.5 * v}))         # BMS yanlış biliyor
for v in (-0.05, 0.05): PERT.append((f"SoH_est_err={v:+.2f}", {}, {"soh_est_err": v}))

CD = [1.0, 1.6, 2.5, 3.5]; CC = [0.3, 0.6, 1.0]; G = [0.0, 0.5, 1.0, 1.5]; TD = [40.0]


def baseline_vals(name, scen, params):
    return simulate(NOMINAL, scen, params), simulate(Controller(mode="fixed", c_dis=50, c_ch=50), scen, params)["shortfall_frac"]


def job(args):
    label, pdict, sdict = args
    rows = []
    for name, scen0, params0 in CASES:
        params = replace(params0, **pdict)
        scen = replace(scen0, **sdict)
        # referans her zaman bu parametreler altında, BMS hatasız bilgiyle (fixed mod BMS bilgisi kullanmaz)
        f, sp = baseline_vals(name, scen, params)
        best = {}
        for mode in ("unaware", "aware_S", "aware_RS"):
            gs = [0.0] if mode == "unaware" else G
            res = []
            for cd, cc, g, td in itertools.product(CD, CC, gs, TD):
                r = simulate(Controller(mode=mode, c_dis=cd, c_ch=cc, g_soh=g, T_der=td, T_set=25.0, Kp=0.05, Ki=0.005), scen, params)
                res.append((100 * max(0.0, r["shortfall_frac"] - sp), r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12), r["n_violations"]))
            res = np.array(res)
            ok = res[res[:, 0] <= 2.0]
            best[mode] = (ok[:, 1].min() if len(ok) else np.nan,
                          ok[ok[:, 2] == 0][:, 1].min() if (len(ok) and (ok[:, 2] == 0).any()) else np.nan,
                          ok[ok[:, 1].argmin(), 2] if len(ok) else np.nan)
        rows.append(dict(pert=label, scenario=name,
                         loss_unaware=best["unaware"][0], loss_S=best["aware_S"][0], loss_RS=best["aware_RS"][0],
                         loss_RS_nowin=best["aware_RS"][1], win_unaware=best["unaware"][2], win_S=best["aware_S"][2],
                         gain_S_pp=100 * (best["unaware"][0] - best["aware_S"][0])))
    return rows


if __name__ == "__main__":
    with ProcessPoolExecutor() as ex:
        out = [r for rows in ex.map(job, PERT) for r in rows]
    D = pd.DataFrame(out); D.to_csv(OUT / "faz4_duyarlilik.csv", index=False)
    pd.set_option("display.width", 250)
    S = D.groupby("pert", sort=False).agg(gain_S_median_pp=("gain_S_pp", "median"), gain_S_max_pp=("gain_S_pp", "max"),
                                          RS_feasible_nowin=("loss_RS_nowin", lambda x: int(x.notna().sum())),
                                          unaware_win_total=("win_unaware", "sum"), S_win_total=("win_S", "sum"))
    print(S.round(2).to_string())

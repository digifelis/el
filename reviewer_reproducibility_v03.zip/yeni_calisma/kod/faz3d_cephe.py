"""Aşama 3d: senaryo bazında parametre ızgarası ile kayıp–güç kısıtı sınırı (oracle ayarlı).
Her senaryo ve mod için ızgara: c_dis × c_ch × g_soh × T_der. T_set=25 (soğutma en agresif), Kp/Ki sabit.
Soru: eşit kontrolcü-kaynaklı güç kısıtında SoH/R farkındalığı yaşlanmayı ne kadar azaltıyor ve gerilim penceresi ihlalini ne yapıyor?
Çıktı: sonuclar/faz3d_grid.csv, sonuclar/faz3d_summary.csv"""
import itertools, sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from evbms import Controller, simulate
from faz3c_pareto import TRAIN, TEST, ref, short_phys
from optimize import OUT

CD = [0.8, 1.2, 1.6, 2.0, 2.5, 3.0, 3.5, 4.0]
CC = [0.3, 0.6, 1.0, 1.5]
G = [0.0, 0.5, 1.0, 1.5, 2.0]
TD = [38.0, 45.0]
SUITE = [(n, s, p, "train") for n, s, p in TRAIN] + [(n, s, p, "test") for n, s, p in TEST]


def run_one(i):
    name, scen, params, split = SUITE[i]
    f, sp = ref(name, scen, params), short_phys(name, scen, params)
    rows = []
    for mode in ("unaware", "aware_S", "aware_RS"):
        gs = [0.0] if mode == "unaware" else G
        for cd, cc, g, td in itertools.product(CD, CC, gs, TD):
            c = Controller(mode=mode, c_dis=cd, c_ch=cc, g_soh=g, T_der=td, T_set=25.0, Kp=0.05, Ki=0.005)
            r = simulate(c, scen, params)
            rows.append(dict(scenario=name, split=split, mode=mode, c_dis=cd, c_ch=cc, g=g, T_der=td,
                             loss_rel=r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12),
                             kWh_rel=r["kWh_per_100km"] / f["kWh_per_100km"],
                             short_ind=100 * max(0.0, r["shortfall_frac"] - sp), outwindow_s=r["n_violations"],
                             Tmax=r["Tmax_C"], t_derate=r["t_derating_s"]))
    return rows


if __name__ == "__main__":
    with ProcessPoolExecutor() as ex:
        out = [r for rows in ex.map(run_one, range(len(SUITE))) for r in rows]
    D = pd.DataFrame(out)
    D.to_csv(OUT / "faz3d_grid.csv", index=False)
    S = []
    for (sc, split), g in D.groupby(["scenario", "split"]):
        for eps in (0.5, 1.0, 2.0, 5.0):
            row = dict(scenario=sc, split=split, eps=eps)
            for mode in ("unaware", "aware_S", "aware_RS"):
                m = g[(g["mode"] == mode) & (g.short_ind <= eps)]
                m0 = m[m.outwindow_s == 0]
                row[f"{mode}_loss"] = m.loss_rel.min() if len(m) else np.nan
                row[f"{mode}_loss_nowin"] = m0.loss_rel.min() if len(m0) else np.nan
                row[f"{mode}_win_at_best"] = m.loc[m.loss_rel.idxmin(), "outwindow_s"] if len(m) else np.nan
            S.append(row)
    S = pd.DataFrame(S); S.to_csv(OUT / "faz3d_summary.csv", index=False)
    pd.set_option("display.width", 250)
    for eps in (1.0, 2.0, 5.0):
        print(f"\n== eps = {eps}% kontrolcü-kaynaklı güç kısıtı")
        print(S[S.eps == eps].drop(columns="eps").round(3).to_string(index=False))

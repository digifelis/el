function newName = insert_law(m)
%INSERT_LAW Resmi MathWorks EV modelinin kopyasına SoH/direnç-farkında akım limiti yasasını ekler.
% VCU Input içinde Bus Selector4'ün DischargeCurrentLimit/ChargeCurrentLimit çıkışları arasına bir MATLAB Function bloğu girer.
% lawMode: 0 resmi BMS (geçiş), 1 fixed, 2 unaware, 3 aware_S, 4 aware_RS  (DENKLEMLER.md ile aynı)
newName = m;
if getSimulinkBlockHandle([m '/Controllers/VCU Input/SoHLimitLaw']) > 0, return; end   % zaten eklenmiş
sub = [newName '/Controllers/VCU Input'];
bs4 = [sub '/Bus Selector4'];
ph = get_param(bs4,'PortHandles');
fcn = [sub '/SoHLimitLaw'];
if getSimulinkBlockHandle(fcn) > 0, delete_block(fcn); end
add_block('simulink/User-Defined Functions/MATLAB Function', fcn);
pos = get_param(bs4,'Position');
set_param(fcn,'Position', [pos(3)+80, pos(2), pos(3)+260, pos(2)+160]);

code = fileread(fullfile(fileparts(mfilename('fullpath')), 'soh_limit_law.m'));
rt = sfroot; chart = rt.find('-isa','Stateflow.EMChart','Path',fcn);
chart.Script = code;
% parametre verileri (taban çalışma alanından çözülür)
pnames = {'ev_lawMode','ev_soh_est','ev_T_est_C','ev_c_dis','ev_c_ch','ev_g_soh','ev_T_der','ev_T_crit','ev_kR_nom','ev_Ns','ev_Np','ev_Q0','ev_Vmin','ev_Vmax','ev_socmin','ev_socmax','ev_socBp','ev_tBp','ev_Rtab','ev_ocvTab'};
for i = 1:numel(pnames)
    d = Stateflow.Data(chart); d.Name = pnames{i}; d.Scope = 'Parameter';
end
fph = get_param(fcn,'PortHandles');
% Bus Selector4 çıkışları: 1 SOC_CC, 2 DischargeCurrentLimit, 3 ChargeCurrentLimit
ln1 = get_param(ph.Outport(1),'Line');     % SOC bir yere gidiyor (DTC); fonksiyona ayrıca dal
ln2 = get_param(ph.Outport(2),'Line'); dst2 = get_param(ln2,'DstPortHandle'); delete_line(ln2);
ln3 = get_param(ph.Outport(3),'Line'); dst3 = get_param(ln3,'DstPortHandle'); delete_line(ln3);
add_line(sub, ph.Outport(1), fph.Inport(1), 'autorouting','on');
add_line(sub, ph.Outport(2), fph.Inport(2), 'autorouting','on');
add_line(sub, ph.Outport(3), fph.Inport(3), 'autorouting','on');
add_line(sub, fph.Outport(1), dst2, 'autorouting','on');
add_line(sub, fph.Outport(2), dst3, 'autorouting','on');
% kayıt: çıkış 1,2 limitler (DTC'ye); 3,4,5 geçiş çıkışları sonlandırıcıya
names = {'LimDis','LimCh','LimDis0','LimCh0','SocIn'};
for i = 1:5
    if i > 2
        tb = [sub '/TermLaw' num2str(i)];
        if getSimulinkBlockHandle(tb) > 0, delete_block(tb); end
        add_block('simulink/Sinks/Terminator', tb, 'Position', [pos(3)+330, pos(2)+(i-3)*30, pos(3)+350, pos(2)+(i-3)*30+20]);
        tph = get_param(tb,'PortHandles');
        add_line(sub, fph.Outport(i), tph.Inport(1), 'autorouting','on');
    end
    ln = get_param(fph.Outport(i),'Line');
    set_param(ln,'Name',names{i});
    set_param(fph.Outport(i),'DataLogging','on'); set_param(fph.Outport(i),'DataLoggingNameMode','Custom');
    set_param(fph.Outport(i),'DataLoggingName',names{i});
end
fprintf('MODEL_BUILT %s\n', newName);
set_param(newName,'Dirty','off');   % kalıcı kaydı önle
end

addpath(fileparts(mfilename('fullpath')));
out = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), 'sonuclar', 'faz5b_bms_hata.csv');
S = {'US06',0,0.25,0.7; 'US06',25,0.9,0.7};
V = {'SoH_est=0.65',0.65,1.5; 'SoH_est=0.75',0.75,1.5; 'kR_nom=0.75',0.7,0.75; 'kR_nom=3.0',0.7,3.0};
rows = table();
for i = 1:size(S,1)
  for k = 1:size(V,1)
    cfg = struct('cycle',S{i,1},'stop',3000,'lawMode',4,'T0C',S{i,2},'soc0',S{i,3},'soh_plant',S{i,4},'soh_est',V{k,2}, ...
                 'kR_plant',1.5,'kR_nom',V{k,3},'c_dis',2.0,'c_ch',1.0,'g_soh',1.0,'T_der',40);
    R = pt_run(cfg);
    tt = R.BattVolt.t; Vc = R.BattVolt.y / R.Ns; vref = interp1(R.cycle(:,1), R.cycle(:,2), R.xdot.t, 'linear', 'extrap');
    err = R.xdot.y - vref;
    row = table(string(S{i,1}), S{i,2}, S{i,4}, string(V{k,1}), sqrt(mean(err.^2)), min(Vc), sum(diff(tt).*(Vc(1:end-1) < 3.2 | Vc(1:end-1) > 4.15)), max(R.BattCurr.y), ...
      'VariableNames', {'cycle','T0C','SoH','bms_error','speed_RMSE_mps','Vcell_min','t_outside_window_s','I_max_A'});
    rows = [rows; row]; writetable(rows, out);
    fprintf('DONE %s T0=%g %s\n', S{i,1}, S{i,2}, V{k,1});
    try, set_param('ConfiguredEv1EmVirtualVehicle','Dirty','off'); catch, end
  end
end
try, set_param('ConfiguredEv1EmVirtualVehicle','Dirty','off'); bdclose all; catch, end
disp('MATRIX2_FINISHED');

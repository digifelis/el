addpath(fileparts(mfilename('fullpath')));
out = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), 'sonuclar', 'faz5_kapali_cevrim.csv');
S = {  % cycle, T0C, soc0, SoH
 'WLTP',25,0.9,1.0; 'UDDS',25,0.9,1.0; 'US06',25,0.9,1.0; 'US06',25,0.9,0.7; 'WLTP',0,0.3,0.7; 'US06',0,0.25,0.7 };
modes = [0 2 4];  names = {'official_BMS','unaware','aware_RS'};
rows = table();
for i = 1:size(S,1)
  for k = 1:numel(modes)
    cfg = struct('cycle',S{i,1},'stop',3000,'lawMode',modes(k),'T0C',S{i,2},'soc0',S{i,3},'soh_plant',S{i,4},'soh_est',S{i,4}, ...
                 'kR_plant',1.5,'kR_nom',1.5,'c_dis',2.0,'c_ch',1.0,'g_soh',1.0,'T_der',40);
    try
      R = pt_run(cfg);
      tt = R.BattVolt.t; Vc = R.BattVolt.y / R.Ns;
      I = R.BattCurr.y; t = R.BattCurr.t;
      vref = interp1(R.cycle(:,1), R.cycle(:,2), R.xdot.t, 'linear', 'extrap');
      err = R.xdot.y - vref;
      row = table(string(S{i,1}), S{i,2}, S{i,3}, S{i,4}, string(names{k}), ...
        sqrt(mean(err.^2)), max(abs(err)), min(Vc), max(Vc), sum(diff(tt).*(Vc(1:end-1) < 3.2 | Vc(1:end-1) > 4.15)), ...
        min(I), max(I), trapz(t, abs(I))/3600, R.BattSoc.y(end), R.wall_s, ...
        'VariableNames', {'cycle','T0C','soc0','SoH','mode','speed_RMSE_mps','speed_maxerr_mps','Vcell_min','Vcell_max','t_outside_window_s','I_min_A','I_max_A','Ah_throughput','soc_end_pct','wall_s'});
    catch ME
      row = table(string(S{i,1}), S{i,2}, S{i,3}, S{i,4}, string(names{k}), NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN, ...
        'VariableNames', {'cycle','T0C','soc0','SoH','mode','speed_RMSE_mps','speed_maxerr_mps','Vcell_min','Vcell_max','t_outside_window_s','I_min_A','I_max_A','Ah_throughput','soc_end_pct','wall_s'});
      fprintf('FAIL %s %s: %s\n', S{i,1}, names{k}, strtok(ME.message, newline));
    end
    rows = [rows; row]; writetable(rows, out);
    fprintf('DONE %d/%d %s T0=%g SoH=%g %s\n', (i-1)*numel(modes)+k, size(S,1)*numel(modes), S{i,1}, S{i,2}, S{i,4}, names{k});
    try, set_param('ConfiguredEv1EmVirtualVehicle','Dirty','off'); catch, end
  end
end
try, set_param('ConfiguredEv1EmVirtualVehicle','Dirty','off'); bdclose all; catch, end
disp('MATRIX_FINISHED');

function R = pt_run(cfg)
%PT_RUN Powertrain EV modelinde (SoH-limit kopyası) tek koşu.
% cfg: cycle ('WLTP'|'UDDS'|'US06'), stop (s), lawMode 0-4, soh_plant, kR_plant, T0C, soc0 (kesir),
%      soh_est, kR_nom, c_dis, c_ch, g_soh, T_der, T_crit, Vmin, Vmax
appRoot = getenv('EVBMS_PT_MODEL_ROOT');
assert(~isempty(appRoot), 'Set EVBMS_PT_MODEL_ROOT to a COPY of your generated model project.');
persistent opened
if isempty(opened) || ~bdIsLoaded('ConfiguredEv1EmVirtualVehicle')
    try, p = currentProject; if ~isempty(p), close(p); end, catch, end
    openProject(fullfile(appRoot,'VirtualVehicle','VirtualVehicle','VirtualVehicle.prj'));
    Simulink.fileGenControl('set','CacheFolder',fullfile(appRoot,'b','cache'),'CodeGenFolder',fullfile(appRoot,'b','codegen'),'createDir',true);
    mdl = dir(fullfile(appRoot,'**','ConfiguredEv1EmVirtualVehicle.slx')); addpath(mdl(1).folder);
    dict = fullfile(appRoot,'VirtualVehicle','VehicleData','Dictionaries'); if isfolder(dict), addpath(dict); end
    load_system('ConfiguredEv1EmVirtualVehicle'); if isempty(getenv('PT_NOINSERT')), insert_law('ConfiguredEv1EmVirtualVehicle'); end, opened = true;
end
m = 'ConfiguredEv1EmVirtualVehicle';
dcs = [m '/Scenarios/Reference Generator/Drive Cycle/Drive Cycle Source'];
bat = [m '/Vehicle/ConfiguredSimulinkPlantModel/Battery/BatteryMapped/Lithium Ion Battery Pack'];
mv_ = get_param(dcs,'MaskObject'); p_ = mv_.getParameter('cycleVar'); %#ok<NASGU>  % maskeyi başlatır (baseline ile aynı davranış)

% adlı hatları günlüğe al (bellekte)
lg = ["BattCurr","BattVolt","BattSoc","xdot"];
LN = find_system(m,'FindAll','on','Type','Line');
for i=1:numel(LN)
  ln_ = string(get_param(LN(i),'Name')); tk = regexprep(ln_,'[<>]','');
  if any(tk == lg)
    try, set_param(LN(i),'DataLogging','on'); set_param(LN(i),'DataLoggingNameMode','Custom'); set_param(LN(i),'DataLoggingName',char(tk)); catch, end
  end
end
dataRoot = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), 'veri');
vdir = [fullfile(dataRoot, 'drive_cycles') filesep];
switch cfg.cycle
  case 'WLTP', T = readmatrix([vdir 'WLTP_Driving_cycle_reference.csv']); cyc = [T(:,1), T(:,2)/3.6];
  case 'UDDS', T = readmatrix([vdir 'EPA_UDDS_raw.txt'],'NumHeaderLines',2); cyc = [T(:,1), T(:,2)*0.44704];
  case 'US06', T = readmatrix([vdir 'EPA_US06_raw.txt'],'NumHeaderLines',2); cyc = [T(:,1), T(:,2)*0.44704];
end
cyc = cyc(isfinite(cyc(:,1)) & isfinite(cyc(:,2)),:);
stop = min(cfg.stop, cyc(end,1));
d = @(f,def) getf(cfg,f,def);
PT = load(fullfile(dataRoot,'pt_plant_tables.mat'));
Ns = PT.PlntBattNumCellSer; Np = PT.PlntBattNumCellPar; Q0 = PT.PlntBattCapInitAh;
Rtab = PT.PlntBattIntrnRes; socBp = PT.PlntBattSocBpt; tBp = PT.PlntBattTempBpt; ocv = PT.PlntBattOpenCircVTbl;
in = Simulink.SimulationInput(m);
assignin('base','cycleWS',cyc);   % maske taban çalışma alanından okuyor
in = in.setVariable('cycleWS', cyc);
in = in.setBlockParameter(dcs,'cycleVar','Workspace variable');
in = in.setBlockParameter(dcs,'wsVar','cycleWS');
in = in.setBlockParameter(dcs,'srcUnit','m/s');
in = in.setBlockParameter(dcs,'tfinal',sprintf('%g seconds', stop));
% yaşlı plant: kapasite ve direnç
if ~d('skipBat',0), in = in.setVariable('soh_plant', d('soh_plant',1.0)); in = in.setVariable('kR_plant', d('kR_plant',1.5)); end
if ~d('skipBat',0)
  in = in.setBlockParameter(bat,'BattCapInit','PlntBattCapInitAh*soh_plant');
  in = in.setBlockParameter(bat,'RInt','PlntBattIntrnRes''*(1+kR_plant*(1-soh_plant))');
end
if ~d('skipDict',0)
  in = in.setVariable('PlntBattSocInit', Simulink.Parameter(d('soc0',0.6)));
  in = in.setVariable('PlntBattTempInitDegC', Simulink.Parameter(d('T0C',25)));
end
% yasa parametreleri
P = struct('lawMode',d('lawMode',0),'soh_est',d('soh_est',d('soh_plant',1.0)),'T_est_C',d('T0C',25),'c_dis',d('c_dis',2.0),'c_ch',d('c_ch',1.0), ...
  'g_soh',d('g_soh',1.0),'T_der',d('T_der',40),'T_crit',d('T_crit',60),'kR_nom',d('kR_nom',1.5),'Ns',Ns,'Np',Np,'Q0',Q0, ...
  'Vmin',d('Vmin',3.2),'Vmax',d('Vmax',4.15),'socmin',0.10,'socmax',0.95,'socBp',socBp,'tBp',tBp,'Rtab',Rtab,'ocvTab',ocv);
if ~d('skipP',0), fn = fieldnames(P); for i=1:numel(fn), in = in.setVariable(['ev_' fn{i}], P.(fn{i})); end, end
in = in.setModelParameter('StopTime',sprintf('%g',stop),'SignalLogging','on','SignalLoggingName','logsout','ReturnWorkspaceOutputs','on');
disp(['DBG cyc ' class(cyc) ' ' mat2str(size(cyc)) ' first=' mat2str(cyc(1,:)) ' last=' mat2str(cyc(end,:)) ' stop=' num2str(stop)]);
tic; out = sim(in); R.wall_s = toc;
set_param(m,'Dirty','off');
L = out.get('logsout'); R.cfg = cfg; R.stop = stop;
for nm = {'BattCurr','BattVolt','BattSoc','xdot','LimDis','LimCh','LimDis0','LimCh0','SocIn'}
  try, e = L.get(nm{1}); if isempty(e), e = L.get(['<' nm{1} '>']); end, v = e.Values; R.(nm{1}) = struct('t', v.Time(:), 'y', double(squeeze(v.Data))); catch, end
end
R.cycle = cyc; R.Ns = Ns; R.Np = Np; R.Q0 = Q0;
end
function v = getf(s,f,def), if isfield(s,f), v = s.(f); else, v = def; end, end

> Original author setup note, retained for provenance. For this portable package, follow `MATLAB_REPRODUCTION.md` at the package root and use `run_matlab.py`; absolute paths no longer need manual editing.

# Powertrain Blockset referans modeli: yeniden oluşturma (model dosyası paylaşılmaz)

`ConfiguredEv1EmVirtualVehicle.slx` ve çevresindeki dosyalar "Copyright The MathWorks, Inc." başlıklıdır ve MathWorks lisans anlaşması kapsamında sağlanır. Bu nedenle **yeniden dağıtılmaz**; bu depoda yalnızca bizim yazdığımız betikler (`soh_limit_law.m`, `insert_law.m`, `pt_run.m`, `pt_matrix*.m`) bulunur. Okuyucu modeli kendi lisanslı MATLAB kurulumunda şöyle üretir.

**Gereken ürünler:** MATLAB R2025b (25.2), Simulink, Powertrain Blockset (Virtual Vehicle Composer için), Simulink Coder gerekmez (model referansı benzetim hedefi otomatik derlenir).

**Yapılandırma (Virtual Vehicle Composer, "Configure Virtual Vehicle" → Electric, 1 EM):**
- Araç sınıfı: elektrikli, tek motor, ön çekiş (Drivetrain: Front Wheel Drive, Electric Motors: 1EM, Electric Machine 1: Electric Vehicle 1EM – Mapped Motor).
- Energy Storage: Mapped Battery (Electric Vehicle 1EM), Battery Management System: Battery Management System.
- VCU: EV 1EM with BMS (`EvPowertrainControllerBMS`), Driver: Longitudinal Driver, Body: Vehicle Body 3DOF Longitudinal, Brake Control: Open Loop, Engine: No Engine / No Engine Controller, Differential: Open / No Control, DC-DC: HVDCPassThrough.
- Test plan: Drive Cycle (Scenario.sldd), Cycle = FTP75 (sonra `Drive Cycle Source` bloğunda 'Workspace variable' seçilip `cycleWS` kullanılır; `pt_run.m` bunu yapar).
- Çıktı: `ConfiguredEv1EmVirtualVehicle.slx` (Composer "Build" ile).
- Tam yapılandırma kaydı kullanılan MathWorks dosyasında `ConfiguredVirtualVehicle.m` içindedir (FeatureVariantSelectedMap). Bu dosya da MathWorks'ün olduğundan paylaşılmadı. Yukarıdaki liste ondan çıkarılmış özettir.

**Betikleri çalıştırma:** model projesini MATLAB'da açın, `pt_matrix.m` (18 koşu) ve `pt_matrix2.m` (BMS hata duyarlılığı) çalıştırılmadan önce `pt_run.m` içindeki model yolunu kendi yolunuza ayarlayın. `insert_law.m` modeli yalnızca bellekte değiştirir; `pt_run.m` kayıt sonunda `Dirty` bayrağını kapatır. **Not:** `matlab -batch` çıkışında kirli model kendiliğinden kaydedilebilir, bu yüzden orijinal dosyanın bir kopyasını (md5) saklayın.

**Makalede beyan:** "The reference vehicle model is a MathWorks Powertrain Blockset example configured with Virtual Vehicle Composer (R2025b) and is not redistributed; only our scripts are provided."

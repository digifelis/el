function [Idis, Ich, Idis0_o, Ich0_o, soc_o] = soh_limit_law(soc_in, Idis0, Ich0)
%#codegen
% Denklemler: yeni_calisma/DENKLEMLER.md (L1-L7, R). Python karşılığı: kod/evbms.py
% Parametreler (Stateflow parametre verisi): ev_lawMode ev_soh_est ev_T_est_C ev_c_dis ev_c_ch ev_g_soh ev_T_der ev_T_crit ev_kR_nom ev_Ns ev_Np ev_Q0 ev_Vmin ev_Vmax ev_socmin ev_socmax ev_socBp ev_tBp ev_Rtab ev_ocvTab
soc = double(soc_in);
if soc > 1.5
    soc = soc / 100;
end
Idis = double(Idis0);
Ich = double(Ich0);
Idis0_o = double(Idis0);
Ich0_o = double(Ich0);
soc_o = soc;
if ev_lawMode == 0
    return;
end
Rg = 8.314462618;
soh_use = 1.0;
if ev_lawMode >= 3
    soh_use = min(1.0, max(0.3, ev_soh_est));
end
Qnom = ev_Np * ev_Q0;
if ev_lawMode == 1
    sS = 1.0; dT = 1.0;
else
    sS = 1.0 - ev_g_soh * (1.0 - soh_use);                                   % (L1)
    dT = min(1.0, max(0.0, (ev_T_crit - ev_T_est_C) / (ev_T_crit - ev_T_der)));       % (L2)
end
taper = min(1.0, max(0.0, (ev_socmax - soc) / 0.10));
Idis_c = ev_c_dis * Qnom * sS * dT;                                          % (L3)
Ich_c = ev_c_ch * Qnom * sS * dT * taper;                                    % (L4)
Idis_m = Idis_c;
Ich_m = Ich_c;
if ev_lawMode >= 2
    soc_q = min(max(soc, ev_socBp(1)), ev_socBp(end));
    T_q = min(max(ev_T_est_C + 273.15, ev_tBp(1)), ev_tBp(end));
    Rcell = interp2(ev_tBp, ev_socBp, ev_Rtab, T_q, soc_q);                         % plant tablosu: SoC x T [Ohm/hücre]
    if ev_lawMode == 4
        Rcell = Rcell * (1.0 + ev_kR_nom * (1.0 - soh_use));                  % (R): BMS direnç tahmini
    end
    Rp = Rcell * ev_Ns / ev_Np;
    Voc = ev_Ns * interp1(ev_socBp, ev_ocvTab, soc_q);
    Idis_V = max(0.0, (Voc - ev_Ns * ev_Vmin) / Rp);                             % (L5)
    Ich_V = max(0.0, (ev_Ns * ev_Vmax - Voc) / Rp);
    Idis_m = min(Idis_c, Idis_V);                                          % (L6)
    Ich_m = min(Ich_c, Ich_V);
end
if soc <= ev_socmin
    Idis_m = 0.0;
end
if soc >= ev_socmax
    Ich_m = 0.0;
end
Idis = -Idis_m;     % resmi BMS işareti: deşarj limiti negatif, şarj limiti pozitif
Ich = Ich_m;
end

"""Denklem–kod eşlik testleri. Çalıştırma: python yeni_calisma/kod/tests/test_evbms.py

Her test, DENKLEMLER.md'deki ifadeyi simülatörden BAĞIMSIZ olarak yeniden hesaplar ve iz (trace) çıktısıyla karşılaştırır.
"""
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import evbms as m
from evbms import Controller, Params, Scenario, simulate

P = Params()
RG = m.R_GAS


def R_cell(soc, T, soh):
    base = np.interp(soc, m.R_SOC, m.R_VAL)
    return base * np.exp(P.E_R_J_mol / RG * (1 / (T + 273.15) - 1 / (P.T_ref_R_C + 273.15))) * (1 + P.kR_true * (1 - soh))


def test_current_never_exceeds_law():
    """(L1)-(L7): akım, bağımsız hesaplanan sınırların dışına çıkmaz ve sınıra dayandığı an vardır."""
    ctrl = Controller(mode="aware_RS", c_dis=1.2, c_ch=0.6, g_soh=1.0, T_der=40)
    sc = Scenario(cycle="US06", n_rep=2, T_amb_C=30, SoH0=0.75, soc0=0.6)
    r = simulate(ctrl, sc, P, trace=True)
    tr = r["trace"]
    I, T, soc_end = tr["I"], tr["T"], tr["soc"]
    # soc[k] iz değeri k adımı SONRASI: önceki adım durumu soc_prev
    soc_prev = np.concatenate([[sc.soc0], soc_end[:-1]])
    Qp = P.Np * P.Q0_cell_Ah
    sS = 1 - ctrl.g_soh * (1 - sc.SoH0)
    dT = np.clip((P.T_crit_C - T) / (P.T_crit_C - ctrl.T_der), 0, 1)
    Voc = P.Ns * np.interp(soc_prev, m.OCV_SOC, m.OCV_V)
    Rhat = R_cell(soc_prev, T, sc.SoH0) * P.Ns / P.Np          # kR_nom = kR_true
    Idis = np.minimum(ctrl.c_dis * Qp * sS * dT, np.maximum(0, (Voc - P.Ns * P.V_min_cell) / Rhat))
    taper = np.clip((P.soc_max - soc_prev) / 0.10, 0, 1)
    Ich = np.minimum(ctrl.c_ch * Qp * sS * dT * taper, np.maximum(0, (P.Ns * P.V_max_cell - Voc) / Rhat))
    Idis = np.where(soc_prev <= P.soc_min, 0, Idis)
    Ich = np.where(soc_prev >= P.soc_max, 0, Ich)
    assert np.all(I <= Idis + 1e-6), "deşarj sınırı aşıldı"
    assert np.all(-I <= Ich + 1e-6), "şarj sınırı aşıldı"
    assert np.any(np.isclose(I, Idis, atol=1e-6) & (Idis > 1.0)), "deşarj sınırına hiç dayanmadı (test anlamsız)"
    print("ok  limit yasası (L1-L7)")


def test_soc_coulomb():
    """(S): SoC değişimi = -∫I dt / (Np Q0 SoH 3600)."""
    ctrl = Controller(mode="unaware", c_dis=3, c_ch=1.5)
    sc = Scenario(cycle="WLTP", SoH0=0.8, soc0=0.9)
    r = simulate(ctrl, sc, P, trace=True)
    I = r["trace"]["I"]
    expected = sc.soc0 - I.sum() * P.dt / (P.Np * P.Q0_cell_Ah * 0.8 * 3600)
    assert abs(r["soc_end"] - expected) < 1e-9, (r["soc_end"], expected)
    print("ok  Coulomb sayımı (S)")


def test_aging_formula():
    """(A1): kayıp, iz verisinden bağımsız hesaplanır."""
    ctrl = Controller(mode="unaware", c_dis=3, c_ch=1.5)
    sc = Scenario(cycle="UDDS", T_amb_C=35, SoH0=0.9)
    r = simulate(ctrl, sc, P, trace=True)
    I, T = r["trace"]["I"], r["trace"]["T"]
    Icell = np.abs(I) / P.Np
    fT = np.exp(P.Ea_age_J_mol / RG * (1 / (P.T_ref_age_C + 273.15) - 1 / (T + 273.15)))
    fC = 1 + P.gamma_C * np.maximum(0, Icell / P.Q0_cell_Ah - P.C_ref)
    loss = np.sum(P.k_efc_pct * (Icell * P.dt / 3600 / (2 * P.Q0_cell_Ah)) * fT * fC)
    assert abs(loss - r["loss_pct"]) < 1e-9 * max(1, loss), (loss, r["loss_pct"])
    print("ok  yaşlanma (A1)")


def test_thermal_energy_balance():
    """(T1): pasif durumda (u=0, T_set çok yüksek) ısınma = ∫I²Rp dt / C_pack - kayıp terimi, kaba kontrol."""
    ctrl = Controller(mode="unaware", c_dis=3, c_ch=1.5, T_set=200.0)
    sc = Scenario(cycle="WLTP", T_amb_C=25, SoH0=1.0)
    r = simulate(ctrl, sc, P, trace=True)
    tr = r["trace"]
    soc_prev = np.concatenate([[sc.soc0], tr["soc"][:-1]])
    Rp = np.array([R_cell(s, t, 1.0) for s, t in zip(soc_prev, tr["T"])]) * P.Ns / P.Np
    heat = np.sum(tr["I"] ** 2 * Rp) * P.dt
    Cp = P.C_cell_J_K * P.Ns * P.Np * P.thermal_mass_factor
    UA0 = P.UA0_cell_W_K * P.Ns * P.Np
    loss = np.sum(UA0 * (tr["T"] - 25.0)) * P.dt
    dT_expected = (heat - loss) / Cp
    dT_sim = r["T_end_C"] - 25.0
    assert abs(dT_expected - dT_sim) < 0.05 * max(dT_sim, 0.1), (dT_expected, dT_sim)
    print("ok  termal denge (T1)")


def test_regen_never_exceeds_share():
    """(Q): rejen enerjisi, frenleme enerjisi × φ_max × η_rg değerini aşamaz."""
    ctrl = Controller(mode="unaware", c_dis=3, c_ch=4)
    r = simulate(ctrl, Scenario(cycle="WLTP"), P)
    v = m._CYCLES["WLTP"]
    a = np.gradient(v)
    Pw = (P.mass_kg * a + P.mass_kg * 9.81 * P.Crr + 0.5 * 1.225 * P.CdA_m2 * v * v) * v
    E_brake = -Pw[Pw < 0].sum() / 3.6e6
    assert r["E_regen_kWh"] <= E_brake * P.regen_share * P.eta_regen + 1e-6, (r["E_regen_kWh"], E_brake)
    print("ok  rejen sınırı (Q)")


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("tüm testler geçti")

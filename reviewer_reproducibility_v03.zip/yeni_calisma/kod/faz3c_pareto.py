"""Aşama 3c (kontrolcü kaynaklı güç kısıtı): ε-kısıtlı eşit-performans karşılaştırması.

Her (mod, ε) için DE ile optimize: kısıt HER eğitim senaryosunda ayrı ayrı uygulanır (ortalamada değil):
    shortfall_s ≤ ε   (çekiş enerjisinin karşılanamayan payı)
Eğitim kümesi SoH %60–100, 5–40 °C ve WLTP/UDDS'i kapsar; test kümesi US06 ve uç sıcaklıkları içerir (eğitimde yok).
Çıktılar: sonuclar/faz3b_vectors.csv, sonuclar/faz3b_test.csv, sonuclar/faz3b_summary.csv
"""
from functools import partial
from pathlib import Path
import sys, time
import numpy as np, pandas as pd
from scipy.optimize import differential_evolution

sys.path.insert(0, str(Path(__file__).resolve().parent))
from evbms import Controller, Params, Scenario, simulate
from optimize import vec_to_ctrl, BOUNDS, LIQUID, AIR, NOMINAL, OUT

LAM_E = 0.5
TRAIN = [
    ("WLTP_25C_SoH100", Scenario(cycle="WLTP", T_amb_C=25, SoH0=1.0, soc0=0.9), LIQUID),
    ("UDDS_25C_SoH80", Scenario(cycle="UDDS", T_amb_C=25, SoH0=0.8, soc0=0.9), LIQUID),
    ("WLTP_25C_SoH60", Scenario(cycle="WLTP", T_amb_C=25, SoH0=0.6, soc0=0.8), LIQUID),
    ("UDDS_10C_SoH70", Scenario(cycle="UDDS", T_amb_C=10, SoH0=0.7, soc0=0.4), LIQUID),
    ("WLTPx2_35C_SoH90_air", Scenario(cycle="WLTP", n_rep=2, T_amb_C=35, SoH0=0.9, soc0=0.7), AIR),
    ("UDDSx2_40C_SoH65_air", Scenario(cycle="UDDS", n_rep=2, T_amb_C=40, SoH0=0.65, soc0=0.8), AIR),
    ("WLTP_5C_SoH80", Scenario(cycle="WLTP", T_amb_C=5, SoH0=0.8, soc0=0.35), LIQUID),
    ("UDDS_30C_SoH90", Scenario(cycle="UDDS", T_amb_C=30, SoH0=0.9, soc0=0.9), LIQUID),
]
TEST = [
    ("US06_25C_SoH90", Scenario(cycle="US06", T_amb_C=25, SoH0=0.9, soc0=0.9), LIQUID),
    ("US06_25C_SoH65", Scenario(cycle="US06", T_amb_C=25, SoH0=0.65, soc0=0.9), LIQUID),
    ("US06_0C_SoH70_lowSoC", Scenario(cycle="US06", T_amb_C=0, SoH0=0.7, soc0=0.25), LIQUID),
    ("WLTP_-10C_SoH60", Scenario(cycle="WLTP", T_amb_C=-10, SoH0=0.6, soc0=0.3), LIQUID),
    ("WLTP_0C_SoH75_lowSoC", Scenario(cycle="WLTP", T_amb_C=0, SoH0=0.75, soc0=0.3), LIQUID),
    ("US06x4_45C_SoH70_air", Scenario(cycle="US06", n_rep=4, T_amb_C=45, SoH0=0.7, soc0=0.95), AIR),
    ("UDDSx4_45C_SoH80_air", Scenario(cycle="UDDS", n_rep=4, T_amb_C=45, SoH0=0.8, soc0=0.9), AIR),
    ("WLTPx2_40C_SoH60_air", Scenario(cycle="WLTP", n_rep=2, T_amb_C=40, SoH0=0.6, soc0=0.9), AIR),
    ("US06x2_35C_SoH85_air", Scenario(cycle="US06", n_rep=2, T_amb_C=35, SoH0=0.85, soc0=0.9), AIR),
]
_REF = {}
_PHYS = {}
PHYS = Controller(mode="fixed", c_dis=50.0, c_ch=50.0)


def short_phys(name, scen, params):
    """Fiziksel referans: BMS akım sınırı yok. Kontrolcüden bağımsız, paketin veremediği güç payı."""
    if name not in _PHYS:
        _PHYS[name] = simulate(PHYS, scen, params)["shortfall_frac"]
    return _PHYS[name]


def ref(name, scen, params):
    if name not in _REF:
        _REF[name] = simulate(NOMINAL, scen, params)
    return _REF[name]


def cost(x, mode, eps):
    ctrl = vec_to_ctrl(mode, x)
    J, pen = 0.0, 0.0
    for name, scen, params in TRAIN:
        r, f = simulate(ctrl, scen, params), ref(name, scen, params)
        J += r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12) + LAM_E * r["kWh_per_100km"] / f["kWh_per_100km"]
        pen += 100.0 * max(0.0, (r["shortfall_frac"] - short_phys(name, scen, params)) - eps)
        pen += 0.02 * min(r["n_violations"], 300)
        pen += 0.5 * max(0.0, r["Tmax_C"] - params.T_safe_C)
    return J / len(TRAIN) + pen


def row(mode, eps, ctrl, name, scen, params, split):
    r, f = simulate(ctrl, scen, params), ref(name, scen, params)
    return dict(mode=mode, eps=eps, split=split, scenario=name,
                loss_rel=r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12),
                kWh_rel=r["kWh_per_100km"] / f["kWh_per_100km"], shortfall_pct=100 * r["shortfall_frac"], short_ind_pct=100 * max(0.0, r["shortfall_frac"] - short_phys(name, scen, params)),
                outwindow_s=r["n_violations"], Tmax_C=r["Tmax_C"], t_derate_s=r["t_derating_s"],
                loss_per100km=r["loss_pct_per_100km"], kWh100=r["kWh_per_100km"], Vmin=r["Vcell_min_V"])


def main():
    t0 = time.time()
    EPS = [0.005, 0.01, 0.02, 0.05, 0.10]
    vecs, rows = [], []
    for name, scen, params in TRAIN + TEST:
        rows.append(row("fixed", np.nan, NOMINAL, name, scen, params, "train" if (name, scen, params) in TRAIN else "test"))
    for mode in ("unaware", "aware_S", "aware_RS"):
        for eps in EPS:
            res = differential_evolution(partial(cost, mode=mode, eps=eps), BOUNDS, maxiter=50, popsize=12, seed=7,
                                         tol=1e-7, polish=False, updating="deferred", workers=-1)
            ctrl = vec_to_ctrl(mode, res.x)
            vecs.append(dict(mode=mode, eps=eps, J=res.fun, nfev=res.nfev,
                             **dict(zip(["c_dis", "c_ch", "g_soh", "T_der", "T_set", "Kp", "log10Ki"], res.x))))
            for name, scen, params in TRAIN:
                rows.append(row(mode, eps, ctrl, name, scen, params, "train"))
            for name, scen, params in TEST:
                rows.append(row(mode, eps, ctrl, name, scen, params, "test"))
            print(f"{mode:9s} eps={eps:.3f} J={res.fun:.4f} nfev={res.nfev} t={time.time()-t0:.0f}s", flush=True)
            pd.DataFrame(vecs).to_csv(OUT / "faz3c_vectors.csv", index=False)
            pd.DataFrame(rows).to_csv(OUT / "faz3c_test.csv", index=False)
    D = pd.DataFrame(rows)
    S = []
    for (mode, eps, split), g in D.groupby(["mode", "eps", "split"], dropna=False):
        lim = eps if not np.isnan(eps) else 0.02
        S.append(dict(mode=mode, eps=eps, split=split, loss_rel_mean=g.loss_rel.mean(), kWh_rel_mean=g.kWh_rel.mean(),
                      shortfall_mean=g.short_ind_pct.mean(), shortfall_max=g.short_ind_pct.max(),
                      n_viol_eps=int((g.short_ind_pct > 100 * lim + 1e-9).sum()), n=len(g), outwindow_total_s=g.outwindow_s.sum()))
    pd.DataFrame(S).to_csv(OUT / "faz3c_summary.csv", index=False)
    print(pd.DataFrame(S).round(3).to_string(index=False))


if __name__ == "__main__":
    main()

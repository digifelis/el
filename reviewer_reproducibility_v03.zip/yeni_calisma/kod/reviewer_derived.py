"""Packaging adapter: regenerate three CSV summaries previously exported interactively.

Uses the original model, original scenario lists and original exhaustive-grid outputs.
No fitting or changes to the underlying research model.
"""
from dataclasses import replace
import pandas as pd
from evbms import simulate
from faz3c_pareto import TRAIN, TEST, ref, short_phys
from optimize import NOMINAL, OUT, AIR

D=pd.concat([pd.read_csv(OUT/'faz3d_grid.csv'),pd.read_csv(OUT/'faz6_grid.csv')])
scenarios=[];cooling=[];oracle=[]
for i,(name,sc,p) in enumerate(TRAIN+TEST):
    r=ref(name,sc,p);sp=short_phys(name,sc,p)
    scenarios.append(dict(name=name,split='tuning' if i<len(TRAIN) else 'held-out',cycle=sc.cycle+(f'×{sc.n_rep}' if sc.n_rep>1 else ''),T=sc.T_amb_C,SoH=sc.SoH0,soc0=sc.soc0,
        cool='air' if p==AIR else 'liquid',km=r['dist_km'],phys_short=100*sp))
    cm=simulate(replace(NOMINAL,T_set=25.,Kp=.05,Ki=.005),sc,p)
    cooling.append(dict(scn=name,loss_rel=cm['loss_pct_per_100km']/r['loss_pct_per_100km'],short_ind=100*max(0.,cm['shortfall_frac']-sp),
        Tmax_f=r['Tmax_C'],Tmax_cm=cm['Tmax_C'],E_cool_f=r['E_cool_kWh'],E_cool_cm=cm['E_cool_kWh'],kWh_rel=cm['kWh_per_100km']/r['kWh_per_100km']))
    row={'scn':name};wins={}
    for mode,key in [('unaware','unaw'),('myopic','myop'),('aware_S','S'),('aware_RS','RS')]:
        g=D[(D.scenario==name)&(D['mode']==mode)&(D.short_ind<=2.)]
        if len(g):
            v=g.loc[g.loss_rel.idxmin()]
            row['loss_'+key]=v.loss_rel;wins['win_'+key]=v.outwindow_s
        else:row['loss_'+key]=float('nan');wins['win_'+key]=float('nan')
    row.update(wins);oracle.append(row)
pd.DataFrame(scenarios).to_csv(OUT/'tab_scenarios.csv',index=False)
pd.DataFrame(cooling).to_csv(OUT/'fixed_cooling_matched.csv',index=False)
pd.DataFrame(oracle).to_csv(OUT/'tab_oracle_eps2.csv',index=False)

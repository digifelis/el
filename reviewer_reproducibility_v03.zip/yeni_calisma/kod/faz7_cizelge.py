"""Aşama 7: kural tabanlı rejim çizelgelemesi. Rejim = ortam sıcaklığı sınıfı (soğuk <=10 °C, ılıman, sıcak >=35 °C).
Her rejim için, EĞİTİM senaryolarında ε ve pencere kısıtını sağlayan en düşük ortalama kayıplı ızgara noktası seçilir
(kısıt sağlanamazsa en az ihlalli). Seçilen sabit yapılandırma TEST senaryolarında değerlendirilir.
Karşılaştırma: tek global yapılandırma (aynı kural, tüm eğitim). Kaynak: faz3d_grid.csv (oracle ızgara, aynı senaryolar)."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from faz3d_cephe import SUITE
from optimize import OUT

EPS = 2.0
cls = {n: ("soguk" if s.T_amb_C <= 10 else "sicak" if s.T_amb_C >= 35 else "ilimli") for n, s, p, sp in SUITE}
D = pd.concat([pd.read_csv(OUT / "faz3d_grid.csv"), pd.read_csv(OUT / "faz6_grid.csv")])
D["rejim"] = D.scenario.map(cls)
KEY = ["c_dis", "c_ch", "g", "T_der"]


def pick(sub):
    """Yapılandırma başına: en kötü kısıt ihlali ve ortalama kayıp. Tüm senaryoda uyumlu olanlar arasında min kayıp."""
    agg = sub.groupby(KEY).agg(loss=("loss_rel", "mean"), sh=("short_ind", "max"), win=("outwindow_s", "max")).reset_index()
    ok = agg[(agg.sh <= EPS) & (agg.win == 0)]
    if len(ok):
        return ok.loc[ok.loss.idxmin()], True
    agg["ihlal"] = np.maximum(0, agg.sh - EPS) + agg.win / 10
    return agg.loc[(agg.ihlal + 0.01 * agg.loss).idxmin()], False


rows, chosen = [], []
for mode in ("unaware", "aware_S", "aware_RS", "myopic"):
    G = D[D["mode"] == mode]
    tr, te = G[G.split == "train"], G[G.split == "test"]
    glob, okg = pick(tr)
    for rj in ("soguk", "ilimli", "sicak"):
        sel, ok = pick(tr[tr.rejim == rj])
        chosen.append(dict(mode=mode, rejim=rj, uyumlu_egitim=ok, **{k: sel[k] for k in KEY}))
    for sc, g in te.groupby("scenario"):
        rj = cls[sc]
        r = chosen_ = next(c for c in chosen if c["mode"] == mode and c["rejim"] == rj)
        for tag, cfg in (("rejim", r), ("global", glob)):
            q = g
            for k in KEY:
                q = q[np.isclose(q[k], cfg[k])]
            if len(q):
                q = q.iloc[0]
                rows.append(dict(mode=mode, tur=tag, scenario=sc, rejim=rj, loss_rel=q.loss_rel, short_ind=q.short_ind, outwindow_s=q.outwindow_s))
R = pd.DataFrame(rows); R.to_csv(OUT / "faz7_test.csv", index=False)
pd.DataFrame(chosen).to_csv(OUT / "faz7_secilen.csv", index=False)
S = R.groupby(["mode", "tur"]).agg(loss=("loss_rel", "mean"), short_mean=("short_ind", "mean"), short_max=("short_ind", "max"),
                                   n_short_viol=("short_ind", lambda x: int((x > EPS).sum())),
                                   n_win_viol=("outwindow_s", lambda x: int((x > 0).sum())), n=("loss_rel", "size")).round(3)
pd.set_option("display.width", 200)
print(pd.DataFrame(chosen).round(2).to_string(index=False)); print(); print(S)

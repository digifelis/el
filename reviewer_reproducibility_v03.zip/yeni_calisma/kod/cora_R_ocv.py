"""CORA paket verisinden R(SoC, T) ve OCV(SoC) çıkarır (hücre başına).

Paket 12S3P: R_hücre = R_paket * 3 / 12, V_hücre = V_paket / 12.
Çıktılar:
  veri/cora_R_soc_T.csv   SoC x sıcaklık ızgarasında medyan hücre direnci
  veri/cora_ocv_soc.csv   OCV(SoC), dinlenme örneklerinden
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "matlab_simulink_project" / "external_validation" / "CORA_WLTP"
OUTD = ROOT / "yeni_calisma" / "veri"
NS, NP = 12, 3

I_COL = "Current_Actual_Battery [A]"
V_COL = "Voltage_Actual_Battery [V]"
SOC_COL = "SoC_Actual_Battery [percent]"
R_COL = "Resistance_Actual_Battery_IT5101 [Ohm]"
TOP = [f"Temperature_Cell_Top_P{p}S{s} [degC]" for p in (1, 2, 3) for s in range(1, 13)]
BOT = [f"Temperature_Cell_Bottom_P{p}S{s} [degC]" for p in (1, 2, 3) for s in range(1, 13)]


def main():
    files = sorted(SRC.glob("Qtzl_Cycle_*.parquet"))
    files = [f for f in files if "partial" not in f.name]
    # ~80 dosya, yaşam boyunca eşit aralıklı
    idx = np.unique(np.linspace(0, len(files) - 1, 80).round().astype(int))
    rows, rest = [], []
    for i in idx:
        d = pd.read_parquet(files[i], columns=["Semicycle", I_COL, V_COL, SOC_COL, R_COL] + TOP + BOT)
        d = d.iloc[::5]  # ~1,6 s adım
        T = d[TOP + BOT]
        d["Tcell"] = T.where((T > -20) & (T < 100)).mean(axis=1)  # arızalı (≈652 °C) sensörler hariç
        d["R_cell"] = d[R_COL] * NP / NS
        d["V_cell"] = d[V_COL] / NS
        rows.append(d[["Semicycle", SOC_COL, "Tcell", "R_cell", I_COL]].rename(columns={SOC_COL: "soc"}))
        r = d[(d[I_COL].abs() < 0.2) & (d["Semicycle"].str.contains("Stand"))]
        rest.append(r[[SOC_COL, "V_cell", "Tcell"]].rename(columns={SOC_COL: "soc"}))
    D = pd.concat(rows)
    D = D[(D.R_cell > 0.005) & (D.R_cell < 0.2)]
    soc_edges = np.arange(0, 101, 10)
    t_edges = np.array([20, 24, 26, 28, 30, 35, 45])
    D["soc_bin"] = pd.cut(D.soc, soc_edges, include_lowest=True)
    D["t_bin"] = pd.cut(D.Tcell, t_edges)
    tab = (D.groupby(["soc_bin", "t_bin"], observed=True)
             .agg(n=("R_cell", "size"), R_cell_median_mohm=("R_cell", lambda x: 1e3 * x.median()),
                  R_cell_p25_mohm=("R_cell", lambda x: 1e3 * x.quantile(.25)),
                  R_cell_p75_mohm=("R_cell", lambda x: 1e3 * x.quantile(.75)))
             .reset_index())
    tab = tab[tab.n >= 200]
    tab.to_csv(OUTD / "cora_R_soc_T.csv", index=False)

    Rst = pd.concat(rest)
    Rst["soc_bin"] = pd.cut(Rst.soc, np.arange(0, 101, 5), include_lowest=True)
    ocv = Rst.groupby("soc_bin", observed=True).agg(n=("V_cell", "size"), soc=("soc", "mean"),
                                                    ocv_cell_V=("V_cell", "median")).reset_index(drop=True)
    ocv[ocv.n >= 100].to_csv(OUTD / "cora_ocv_soc.csv", index=False)
    print(tab.to_string(index=False))
    print(ocv[ocv.n >= 100].round(3).to_string(index=False))
    print("toplam örnek:", len(D), "dinlenme:", len(Rst))


if __name__ == "__main__":
    main()

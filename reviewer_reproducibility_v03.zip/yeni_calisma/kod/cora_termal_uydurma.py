"""CORA WLTP döngülerinden hücre başına termal parametreleri (C_th, UA) uydurur.

Hücre ısı üretimi: (I_paket/3)^2 * R_hücre. R_hücre = IT5101 ölçümünün SoC-bölgesi medyanı DEĞİL,
SABİT kalibrasyon değeri (test döngüsünün kendi ölçümü kullanılmaz: önceki doğrulamadaki sızıntıyı önlemek için).
Sıcaklık: yalnızca geçerli sensörlerin ortalaması. İlk 1800 s (bir WLTP turu).
Eğitim/test ayrımı: döngü numarasına göre her 3. döngü test.
Çıktı: sonuclar/cora_termal_fit.csv
"""
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "matlab_simulink_project" / "external_validation" / "CORA_WLTP"
NS, NP = 12, 3
R_CELL = 12.0e-3  # Ω, cora_R_soc_T.csv medyanı (SoC 0-80 %)
TT = [f"Temperature_Cell_{pos}_P{p}S{s} [degC]" for p in (1, 2, 3) for s in range(1, 13) for pos in ("Top", "Bottom")]


def load(path):
    d = pd.read_parquet(path, columns=["Semicycle", "Timestamp", "Current_Actual_Battery [A]",
                                       "Temperature_IN_Chamber [degC]"] + TT)
    d = d[d.Semicycle == "WLTP"]
    t = (pd.to_datetime(d.Timestamp) - pd.to_datetime(d.Timestamp.iloc[0])).dt.total_seconds().to_numpy()
    m = t <= 1800
    T = d[TT].where((d[TT] > -20) & (d[TT] < 100)).mean(axis=1).to_numpy()
    return t[m], d["Current_Actual_Battery [A]"].to_numpy()[m], d["Temperature_IN_Chamber [degC]"].to_numpy()[m], T[m]


def simulate(t, I, Tamb, T0, C, UA):
    T = np.empty_like(t); T[0] = T0
    for k in range(len(t) - 1):
        dt = t[k + 1] - t[k]
        q = (I[k] / NP) ** 2 * R_CELL
        T[k + 1] = T[k] + dt * (q - UA * (T[k] - Tamb[k])) / C
    return T


def main():
    files = sorted(f for f in SRC.glob("Qtzl_Cycle_*_WLTP.parquet"))
    cyc = [int(f.name.split("_")[2]) for f in files]
    sel = np.unique(np.linspace(0, len(files) - 1, 30).round().astype(int))
    data = []
    for i in sel:
        t, I, Ta, T = load(files[i])
        ok = np.isfinite(T) & np.isfinite(I)
        data.append((cyc[i], t[ok], I[ok], Ta[ok], T[ok]))
    train = [x for j, x in enumerate(data) if j % 3 != 2]
    test = [x for j, x in enumerate(data) if j % 3 == 2]

    def res(p, S):
        C, UA = np.exp(p)
        return np.concatenate([simulate(t, I, Ta, T[0], C, UA) - T for _, t, I, Ta, T in S])

    sol = least_squares(res, np.log([120.0, 0.05]), args=(train,))
    C, UA = np.exp(sol.x)
    rows = []
    for c, t, I, Ta, T in test:
        p = simulate(t, I, Ta, T[0], C, UA)
        persist = np.full_like(T, T[0])  # "sıcaklık sabit kalır" referans tahmini
        rows.append(dict(cycle=c, rmse_model=np.sqrt(np.mean((p - T) ** 2)),
                         rmse_persistence=np.sqrt(np.mean((persist - T) ** 2)),
                         dT_measured=T.max() - T[0], dT_model=p.max() - p[0], T0=T[0], Tamb=Ta.mean()))
    out = pd.DataFrame(rows)
    out.to_csv(ROOT / "yeni_calisma/sonuclar/cora_termal_fit_test.csv", index=False)
    pd.DataFrame([dict(C_cell_J_per_K=C, UA_cell_W_per_K=UA, n_train=len(train), n_test=len(test), R_cell_mohm=R_CELL * 1e3)]
                 ).to_csv(ROOT / "yeni_calisma/sonuclar/cora_termal_fit.csv", index=False)
    print(f"C_hücre = {C:.1f} J/K, UA_hücre = {UA:.4f} W/K  (eğitim {len(train)}, test {len(test)})")
    print(out.round(3).to_string(index=False))
    print("ortalama RMSE model %.3f  persistence %.3f" % (out.rmse_model.mean(), out.rmse_persistence.mean()))


if __name__ == "__main__":
    main()

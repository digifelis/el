"""Aşama 6: miyop (ECMS tarzı) marjinal-maliyet sınırlayıcı baseline'ı, faz3d ile aynı kontrolcü-kaynaklı güç kısıtı ölçüsünde.
Izgara: c_dis × c_ch × mu × T_der (mu = marjinal yaşlanma maliyeti ağırlığı, evbms mod 'myopic').
Çıktı: sonuclar/faz6_grid.csv, sonuclar/faz6_summary.csv (faz3d_grid.csv ile birleştirilmiş karşılaştırma)"""
import itertools, sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from evbms import Controller, simulate
from faz3c_pareto import ref, short_phys
from faz3d_cephe import SUITE, CD, CC, TD
from optimize import OUT

MU = [0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4]


def run_one(i):
    name, scen, params, split = SUITE[i]
    f, sp = ref(name, scen, params), short_phys(name, scen, params)
    rows = []
    for cd, cc, mu, td in itertools.product(CD, CC, MU, TD):
        c = Controller(mode="myopic", c_dis=cd, c_ch=cc, g_soh=mu, T_der=td, T_set=25.0, Kp=0.05, Ki=0.005)
        r = simulate(c, scen, params)
        rows.append(dict(scenario=name, split=split, mode="myopic", c_dis=cd, c_ch=cc, g=mu, T_der=td,
                         loss_rel=r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12),
                         kWh_rel=r["kWh_per_100km"] / f["kWh_per_100km"],
                         short_ind=100 * max(0.0, r["shortfall_frac"] - sp), outwindow_s=r["n_violations"],
                         Tmax=r["Tmax_C"], t_derate=r["t_derating_s"]))
    return rows


if __name__ == "__main__":
    with ProcessPoolExecutor() as ex:
        out = [r for rows in ex.map(run_one, range(len(SUITE))) for r in rows]
    M = pd.DataFrame(out); M.to_csv(OUT / "faz6_grid.csv", index=False)
    D = pd.concat([pd.read_csv(OUT / "faz3d_grid.csv"), M])
    S = []
    for (sc, split), g in D.groupby(["scenario", "split"]):
        for eps in (1.0, 2.0, 5.0):
            row = dict(scenario=sc, split=split, eps=eps)
            for mode in ("unaware", "aware_S", "aware_RS", "myopic"):
                m = g[(g["mode"] == mode) & (g.short_ind <= eps)]
                m0 = m[m.outwindow_s == 0]
                row[f"{mode}_loss"] = m.loss_rel.min() if len(m) else np.nan
                row[f"{mode}_nowin"] = m0.loss_rel.min() if len(m0) else np.nan
            S.append(row)
    S = pd.DataFrame(S); S.to_csv(OUT / "faz6_summary.csv", index=False)
    pd.set_option("display.width", 250)
    for eps in (2.0,):
        print(S[S.eps == eps].drop(columns="eps").round(3).to_string(index=False))
    print("\nOrtalama (eps=2): ", S[S.eps == 2.0].drop(columns=["scenario", "split", "eps"]).mean().round(3).to_dict())

"""Dirençli ve SoH-farkındalıklı akım sınırlama: referans simülatör.

Tek gerçeklik kaynağı. Makaledeki her denklem burada bire bir karşılığıyla bulunur
(denklem numaraları DENKLEMLER.md'de). Değişiklik yapılırsa makale denklemleri de güncellenmeli;
tests/test_evbms.py denklem-kod eşliğini kontrol eder.

Birimler: SI, sıcaklık °C, akım A (deşarj pozitif), güç W (pozitif = bataryadan çekilen).
Hücre: CORA 18650 benzeri NMC/NCA (veri/cora_*.csv).
"""
from dataclasses import dataclass, field, asdict
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "veri"
R_GAS = 8.314462618


# --------------------------------------------------------------------------- veri
def _load_tables():
    ocv = pd.read_csv(DATA / "cora_ocv_curve.csv")
    soc = np.concatenate([[0.0], ocv.soc.to_numpy(), [100.0]])
    v = np.concatenate([[ocv.ocv_cell_V.iloc[0] - 0.08], ocv.ocv_cell_V.to_numpy(), [ocv.ocv_cell_V.iloc[-1] + 0.04]])
    v = np.maximum.accumulate(v)  # tekdüze OCV
    return soc / 100.0, v


OCV_SOC, OCV_V = _load_tables()
# R_ref(SoC) hücre başına [Ω], T_ref = 27 °C, taze hücre. Kaynak: veri/cora_R_soc_T.csv (26-28 °C kutusu).
R_SOC = np.array([0.0, 0.3, 0.6, 0.8, 0.9, 1.0])
R_VAL = np.array([11.8, 12.0, 12.1, 12.4, 13.2, 14.2]) * 1e-3


def load_cycle(name: str) -> np.ndarray:
    """Hız profili [m/s], 1 s adım."""
    d = DATA / "drive_cycles"
    if name == "WLTP":
        v = pd.read_csv(d / "WLTP_Driving_cycle_reference.csv").iloc[:, 1].to_numpy(float) / 3.6
    elif name in ("UDDS", "US06"):
        f = "EPA_UDDS_raw.txt" if name == "UDDS" else "EPA_US06_raw.txt"
        rows = [ln.split() for ln in (d / f).read_text(errors="ignore").splitlines()[2:] if ln.strip()]
        v = np.array([float(r[1]) for r in rows if len(r) >= 2]) * 0.44704
    else:
        raise ValueError(name)
    return v


# --------------------------------------------------------------------------- parametreler
@dataclass
class Params:
    # araç
    mass_kg: float = 1800.0
    CdA_m2: float = 0.23 * 2.22
    Crr: float = 0.009
    eta_drive: float = 0.90      # tahrik zinciri verimi (deşarj yönü)
    eta_regen: float = 0.90      # tahrik zinciri verimi (rejen yönü)
    regen_share: float = 0.70    # frenlemenin elektrikli sürücüye verilen azami payı (φ_max)
    P_aux_W: float = 500.0       # sabit yardımcı yük
    # paket
    Ns: int = 96
    Np: int = 22                 # CORA WLTP tepe C-oranına (≈2.5C) göre boyutlandırıldı: ≈ 19.6 kWh kompakt EV paketi
    Q0_cell_Ah: float = 2.54     # CORA kapasite testi ortalaması 7.61 Ah / 3
    V_min_cell: float = 3.2      # BMS penceresi
    V_max_cell: float = 4.15
    V_hard_min: float = 3.0      # fiziksel kesme
    V_hard_max: float = 4.2
    soc_min: float = 0.10
    soc_max: float = 0.95
    # direnç
    kR_true: float = 1.5         # R = R0 (1 + kR (1-SoH)); VARSAYIM, literatürden doğrulanacak; duyarlılık taranır
    E_R_J_mol: float = 20e3      # R'nin sıcaklık aktivasyon enerjisi; VARSAYIM
    T_ref_R_C: float = 27.0
    # termal (CORA uydurması, hücre başına etkin)
    C_cell_J_K: float = 22.3
    thermal_mass_factor: float = 1.0
    UA0_cell_W_K: float = 0.0010
    UA_cool_pack_W_K: float = 400.0   # soğutma devresi azami ek iletkenliği (VARSAYIM)
    dT_chill_C: float = 15.0          # azami soğutucu sıvı sıcaklık düşüşü (VARSAYIM)
    P_cool_max_W: float = 2500.0      # azami soğutma elektrik gücü (VARSAYIM)
    T_crit_C: float = 60.0
    T_safe_C: float = 50.0
    # yaşlanma (Lu Dataset #3, NCR18650BD, 20 °C: ≈ 0.037 %/EFC; sonuclar/lu_fade_fit.csv)
    k_efc_pct: float = 0.0372
    Ea_age_J_mol: float = 30e3   # VARSAYIM, taranır
    T_ref_age_C: float = 20.0
    gamma_C: float = 0.30        # C-oranı çarpanı katsayısı; VARSAYIM, taranır
    C_ref: float = 1.0
    gamma_dis_C: float = -1.0    # deşarj yönü için ayrı γ; <0 ise gamma_C kullanılır (şarj/rejen yönü her zaman gamma_C)
    dt: float = 1.0


@dataclass
class Controller:
    """Karar vektörü + yapı bayrakları."""
    mode: str = "aware_RS"       # fixed | unaware | aware_S | aware_RS
    c_dis: float = 2.0           # C-oranı sınırı (deşarj)
    c_ch: float = 1.0            # C-oranı sınırı (şarj / rejen)
    g_soh: float = 1.0           # SoH azaltma kazancı
    T_der: float = 40.0          # derating başlangıç sıcaklığı
    T_set: float = 35.0          # soğutma PI hedefi
    Kp: float = 0.15             # 1/°C
    Ki: float = 0.002            # 1/(°C s)
    u_max: float = 1.0


@dataclass
class Scenario:
    cycle: str = "WLTP"
    n_rep: int = 1
    T_amb_C: float = 25.0
    SoH0: float = 1.0
    soc0: float = 0.90
    T0_C: float | None = None    # None = ortam
    soh_est_err: float = 0.0     # BMS SoH tahmin hatası (SoH birimi, kesir)
    kR_nom: float = 1.5          # BMS'in bildiği kR (varsayılan: gerçekle aynı)


MODES = {"fixed": 0, "unaware": 1, "aware_S": 2, "aware_RS": 3, "myopic": 4, "mpc": 5}


# --------------------------------------------------------------------------- çekirdek
@njit(cache=True)
def _interp(x, xp, fp):
    return np.interp(x, xp, fp)


@njit(cache=True)
def _R_cell(soc, T, soh, kR, E_R, T_ref, rsoc, rval):
    """Eq. (R): R_hücre = R_ref(SoC) * exp(E_R/R_g * (1/T - 1/T_ref)) * (1 + kR (1 - SoH))."""
    base = np.interp(soc, rsoc, rval)
    fT = np.exp(E_R / 8.314462618 * (1.0 / (T + 273.15) - 1.0 / (T_ref + 273.15)))
    return base * fT * (1.0 + kR * (1.0 - soh))



@njit(cache=True)
def _mpc_lambda(v, k, n, H, kappa, soc, T, Voc, Rp, Rest, Idis_nom, Ich_nom, Ns, Np, Q0, Qp_true, Qp_nom, Vmin, Vmax,
                mass, CdA, Crr, eta_dr, eta_rg, phi_max, Paux, kefc, Ea, Tref_age, gamma, gamma_dis, Cref, dt):
    """Alçalan ufuklu (H adım, 9 düzeyli) indirgenmiş MPC: sabit akım-sınırı çarpanı lambda seçer.
    Tahmin modeli: Voc, R (BMS tahmini), T ufukta sabit; talep önizlemesi biliniyor. Maliyet = normalize yaşlanma + kappa * normalize güç açığı."""
    A0 = kefc * Cref * dt / 7200.0
    E0 = Voc * Qp_nom * Cref * dt
    best = 1e30
    lam_best = 1.0
    fTa = np.exp(Ea / 8.314462618 * (1.0 / (Tref_age + 273.15) - 1.0 / (T + 273.15)))
    for li in range(9):
        lam = li / 8.0
        s_ = soc
        cost = 0.0
        for j in range(H):
            kk = min(n - 1, k + j)
            vk = v[kk]
            if kk > 0 and kk < n - 1:
                ak = (v[kk + 1] - v[kk - 1]) / (2.0 * dt)
            elif kk == 0 and n > 1:
                ak = (v[1] - v[0]) / dt
            else:
                ak = 0.0
            Pw = (mass * ak + mass * 9.81 * Crr + 0.5 * 1.225 * CdA * vk * vk) * vk
            if Pw >= 0.0:
                Pt = Pw / eta_dr + Paux
            else:
                phi = phi_max * min(1.0, max(0.0, (vk - 2.0) / 3.0))
                Pt = Paux + Pw * phi * eta_rg
            vo = Voc
            disc = vo * vo - 4.0 * Rp * Pt
            if disc < 0.0:
                Ireq = vo / (2.0 * Rp)
            else:
                Ireq = (vo - np.sqrt(disc)) / (2.0 * Rp)
            Idm = lam * Idis_nom
            Icm = lam * Ich_nom
            Idv = max(0.0, (vo - Ns * Vmin) / Rest)
            Icv = max(0.0, (Ns * Vmax - vo) / Rest)
            Idm = min(Idm, Idv)
            Icm = min(Icm, Icv)
            I = max(min(Ireq, Idm), -Icm)
            Vt = vo - I * Rp
            if Pw >= 0.0:
                Pd = max(0.0, Vt * I - Paux) * eta_dr
                sh = max(0.0, Pw - Pd) * dt
            else:
                sh = 0.0
            Icell = abs(I) / Np
            Cr = Icell / Q0
            fC = 1.0 + (gamma_dis if I >= 0.0 else gamma) * max(0.0, Cr - Cref)
            ag = kefc * (Icell * dt / 3600.0 / (2.0 * Q0)) * fTa * fC
            cost += ag / A0 + kappa * sh / E0
        if cost < best:
            best = cost
            lam_best = lam
    return lam_best

@njit(cache=True)
def _sim(v, P, C, S, ocv_soc, ocv_v, rsoc, rval, mode, trace):
    # P: [mass, CdA, Crr, eta_dr, eta_rg, phi, Paux, Ns, Np, Q0, Vmin, Vmax, Vhmin, Vhmax, socmin, socmax,
    #     kR, E_R, Tref_R, Ccell, tmf, UA0cell, UAcool, dTchill, Pcool, Tcrit, Tsafe,
    #     kefc, Ea, Tref_age, gamma, Cref, dt]
    # C: [c_dis, c_ch, g, T_der, T_set, Kp, Ki, u_max]
    # S: [T_amb, SoH0, soc0, T0, soh_err, kR_nom]
    mass, CdA, Crr, eta_dr, eta_rg, phi_max, Paux = P[0], P[1], P[2], P[3], P[4], P[5], P[6]
    Ns, Np, Q0 = P[7], P[8], P[9]
    Vmin, Vmax, Vhmin, Vhmax, socmin, socmax = P[10], P[11], P[12], P[13], P[14], P[15]
    kR, E_R, Tref_R = P[16], P[17], P[18]
    Ccell, tmf, UA0cell, UAcool, dTchill, Pcool_max, Tcrit, Tsafe = P[19], P[20], P[21], P[22], P[23], P[24], P[25], P[26]
    kefc, Ea, Tref_age, gamma, Cref, dt = P[27], P[28], P[29], P[30], P[31], P[32]
    gamma_dis = P[33]
    c_dis, c_ch, g, T_der, T_set, Kp, Ki, u_max = C[0], C[1], C[2], C[3], C[4], C[5], C[6], C[7]
    T_amb, SoH0, soc0, T0, soh_err, kR_nom = S[0], S[1], S[2], S[3], S[4], S[5]

    n = v.shape[0]
    Cpack = Ccell * Ns * Np * tmf
    UA0 = UA0cell * Ns * Np
    soc = soc0
    T = T0
    integ = 0.0
    u = 0.0

    E_batt = 0.0      # J, net (deşarj +, şarj -)
    E_dis = 0.0
    E_reg = 0.0       # J geri kazanılan (pozitif)
    E_cool = 0.0
    E_req = 0.0       # J istenen tekerlek çekiş enerjisi
    E_short = 0.0     # J karşılanamayan çekiş enerjisi
    E_brake_fric = 0.0
    dist = 0.0
    loss = 0.0        # % kapasite kaybı (tahmin)
    Ah_cell = 0.0
    Tmax = T
    t_above = 0.0
    t_derate = 0.0
    Vcell_min = 9.0
    I_rms2 = 0.0
    n_viol = 0
    Pdis_cap_min = 1e12
    Tbuf = np.empty(n) if trace else np.empty(1)
    Ibuf = np.empty(n) if trace else np.empty(1)
    Sbuf = np.empty(n) if trace else np.empty(1)
    Ubuf = np.empty(n) if trace else np.empty(1)
    Dbuf = np.empty(n) if trace else np.empty(1)

    for k in range(n):
        vk = v[k]
        ak = 0.0
        if k > 0 and k < n - 1:
            ak = (v[k + 1] - v[k - 1]) / (2.0 * dt)
        elif k == 0 and n > 1:
            ak = (v[1] - v[0]) / dt
        Pw = (mass * ak + mass * 9.81 * Crr + 0.5 * 1.225 * CdA * vk * vk) * vk
        dist += vk * dt

        # --- gerçek plant
        Rc = _R_cell(soc, T, SoH0, kR, E_R, Tref_R, rsoc, rval)
        Rp = Rc * Ns / Np
        Voc = Ns * np.interp(soc, ocv_soc, ocv_v)
        Qp_true = Np * Q0 * SoH0

        # --- BMS tahminleri
        soh_e = min(1.0, max(0.3, SoH0 + soh_err))
        if mode >= 2:
            soh_use = soh_e
        else:
            soh_use = 1.0
        if mode >= 3:
            R_est = _R_cell(soc, T, soh_use, kR_nom, E_R, Tref_R, rsoc, rval) * Ns / Np
        else:
            R_est = _R_cell(soc, T, 1.0, kR_nom, E_R, Tref_R, rsoc, rval) * Ns / Np
        Qp_nom = Np * Q0          # C-oranı sınırları taze (nominal) kapasiteye göre; SoH etkisi yalnız s_SoH ile

        # --- BMS akım sınırları  (Eq. L1-L5)
        if mode == 0:
            sS = 1.0
            dT = 1.0
        elif mode == 4 or mode == 5:
            sS = 1.0                                                           # miyop maliyet sınırlayıcıda SoH ölçeği yok
            dT = min(1.0, max(0.0, (Tcrit - T) / (Tcrit - T_der)))
        else:
            sS = 1.0 - g * (1.0 - soh_use)                                     # Eq. (L1)
            dT = min(1.0, max(0.0, (Tcrit - T) / (Tcrit - T_der)))              # Eq. (L2)
        taper = min(1.0, max(0.0, (socmax - soc) / 0.10))
        Idis_c = c_dis * Qp_nom * sS * dT                                       # Eq. (L3)
        Ich_c = c_ch * Qp_nom * sS * dT * taper                                 # Eq. (L4)
        if mode >= 1:
            Idis_V = max(0.0, (Voc - Ns * Vmin) / R_est)                         # Eq. (L5)
            Ich_V = max(0.0, (Ns * Vmax - Voc) / R_est)
            Idis_max = min(Idis_c, Idis_V)
            Ich_max = min(Ich_c, Ich_V)
        else:
            Idis_max = Idis_c
            Ich_max = Ich_c
        if mode == 4 and g > 0.0:
            # Miyop (ECMS tarzı) sınırlayıcı: anlık marjinal yaşlanma maliyeti = marjinal güç faydası.
            # mu*fT*(1+gamma*(2c-1)) = 1 - 2 c K,  c = I/(Np Q0),  K = Np Q0 Rp / Voc   (DENKLEMLER.md, B1)
            fTa = np.exp(Ea / 8.314462618 * (1.0 / (Tref_age + 273.15) - 1.0 / (T + 273.15)))
            xm = g * fTa
            Kc = Qp_nom * R_est / max(Voc, 1.0)
            c_star = (1.0 - xm * (1.0 - gamma)) / (2.0 * xm * gamma + 2.0 * Kc)
            if c_star <= Cref:
                c_star = min(Cref, max(0.0, (1.0 - xm) / (2.0 * Kc)))
            I_age = max(0.0, c_star) * Qp_nom
            Idis_max = min(Idis_max, I_age)
            Ich_max = min(Ich_max, I_age)
        if mode == 5:
            lam = _mpc_lambda(v, k, n, 12, g, soc, T, Voc, Rp, R_est, Idis_c, Ich_c, Ns, Np, Q0, Qp_true, Qp_nom, Vmin, Vmax,
                              mass, CdA, Crr, eta_dr, eta_rg, phi_max, Paux, kefc, Ea, Tref_age, gamma, gamma_dis, Cref, dt)
            Idis_max = min(Idis_max, lam * Idis_c)
            Ich_max = min(Ich_max, lam * Ich_c)
        if soc <= socmin:
            Idis_max = 0.0
        if soc >= socmax:
            Ich_max = 0.0

        # --- güç talebi
        Pcool_prev = Pcool_max * u * u * u
        if Pw >= 0.0:
            P_term = Pw / eta_dr + Paux + Pcool_prev
            E_req += Pw * dt
        else:
            phi = phi_max * min(1.0, max(0.0, (vk - 2.0) / 3.0))
            P_term = Paux + Pcool_prev + Pw * phi * eta_rg                     # Pw<0 -> şarj katkısı
        # akım: P = (Voc - I Rp) I
        disc = Voc * Voc - 4.0 * Rp * P_term
        if disc < 0.0:
            I_req = Voc / (2.0 * Rp)
        else:
            I_req = (Voc - np.sqrt(disc)) / (2.0 * Rp)
        I = min(I_req, Idis_max)
        I = max(I, -Ich_max)
        # fiziksel kesme (plant)
        I_hard_dis = max(0.0, (Voc - Ns * Vhmin) / Rp)
        I_hard_ch = max(0.0, (Ns * Vhmax - Voc) / Rp)
        if I > I_hard_dis:
            I = I_hard_dis
        if I < -I_hard_ch:
            I = -I_hard_ch
        Vterm = Voc - I * Rp
        Vc = Vterm / Ns
        if Vc < Vcell_min:
            Vcell_min = Vc
        if Vc < Vmin - 1e-9 or Vc > Vmax + 1e-9:
            n_viol += 1
        Pdel = Vterm * I                                                         # bataryanın verdiği terminal gücü
        # --- teslim edilen çekiş / rejen
        if Pw >= 0.0:
            Pw_del = max(0.0, (Pdel - Paux - Pcool_prev)) * eta_dr
            if Pw_del < Pw:
                E_short += (Pw - Pw_del) * dt
        else:
            Pw_regen = max(0.0, -(Pdel - Paux - Pcool_prev)) / eta_rg            # tekerlekten alınan güç
            Pw_fric = -Pw - Pw_regen
            if Pw_fric > 0.0:
                E_brake_fric += Pw_fric * dt
            if Pdel < 0.0:
                E_reg += (-Pdel) * dt
        E_batt += Pdel * dt
        if Pdel > 0:
            E_dis += Pdel * dt

        # --- ısı ve soğutma (PI)  Eq. (T1-T3)
        e = T - T_set
        u_unsat = Kp * e + Ki * integ
        u_new = min(u_max, max(0.0, u_unsat))
        if u_new == u_unsat or (u_unsat > u_max and e < 0) or (u_unsat < 0 and e > 0):
            integ += e * dt
        u = u_new
        P_cool = Pcool_max * u * u * u
        E_cool += P_cool * dt
        Tsink = T_amb - dTchill * u
        Qgen = I * I * Rp
        Qrem = (UA0 + UAcool * u) * (T - Tsink)
        T_next = T + dt * (Qgen - Qrem) / Cpack
        if T > Tmax:
            Tmax = T
        if T > T_der:
            t_above += dt
        if dT < 1.0:
            t_derate += dt
        I_rms2 += I * I

        # --- yaşlanma (kapasite kaybı tahmini)  Eq. (A1)
        Icell = abs(I) / Np
        Ccell_rate = Icell / Q0
        fT_age = np.exp(Ea / 8.314462618 * (1.0 / (Tref_age + 273.15) - 1.0 / (T + 273.15)))
        fC = 1.0 + (gamma_dis if I >= 0.0 else gamma) * max(0.0, Ccell_rate - Cref)
        dAh = Icell * dt / 3600.0
        Ah_cell += dAh
        loss += kefc * (dAh / (2.0 * Q0)) * fT_age * fC

        soc = soc - I * dt / (Qp_true * 3600.0)
        if trace:
            Tbuf[k] = T
            Ibuf[k] = I
            Sbuf[k] = soc
            Ubuf[k] = u
            Dbuf[k] = dT
        T = T_next

    out = np.empty(20)
    out[0] = E_batt / 3.6e6
    out[1] = dist / 1000.0
    out[2] = E_reg / 3.6e6
    out[3] = E_cool / 3.6e6
    out[4] = loss
    out[5] = Tmax
    out[6] = t_above
    out[7] = t_derate
    out[8] = Vcell_min
    out[9] = E_short / max(E_req, 1.0)
    out[10] = soc
    out[11] = np.sqrt(I_rms2 / n)
    out[12] = n_viol
    out[13] = E_req / 3.6e6
    out[14] = Ah_cell
    out[15] = E_brake_fric / 3.6e6
    out[16] = T
    out[17] = E_dis / 3.6e6
    return out, Tbuf, Ibuf, Sbuf, Ubuf, Dbuf


def _pvec(p: Params) -> np.ndarray:
    return np.array([p.mass_kg, p.CdA_m2, p.Crr, p.eta_drive, p.eta_regen, p.regen_share, p.P_aux_W,
                     p.Ns, p.Np, p.Q0_cell_Ah, p.V_min_cell, p.V_max_cell, p.V_hard_min, p.V_hard_max,
                     p.soc_min, p.soc_max, p.kR_true, p.E_R_J_mol, p.T_ref_R_C, p.C_cell_J_K,
                     p.thermal_mass_factor, p.UA0_cell_W_K, p.UA_cool_pack_W_K, p.dT_chill_C,
                     p.P_cool_max_W, p.T_crit_C, p.T_safe_C, p.k_efc_pct, p.Ea_age_J_mol,
                     p.T_ref_age_C, p.gamma_C, p.C_ref, p.dt,
                     p.gamma_C if p.gamma_dis_C < 0 else p.gamma_dis_C], dtype=np.float64)


NAMES = ["E_batt_kWh", "dist_km", "E_regen_kWh", "E_cool_kWh", "loss_pct", "Tmax_C", "t_above_Tder_s",
         "t_derating_s", "Vcell_min_V", "shortfall_frac", "soc_end", "I_rms_A", "n_violations",
         "E_traction_req_kWh", "Ah_cell", "E_fric_brake_kWh", "T_end_C", "E_discharge_kWh"]

_CYCLES: dict = {}


def simulate(ctrl: Controller, scen: Scenario = Scenario(), params: Params = Params(), trace: bool = False):
    if scen.cycle not in _CYCLES:
        _CYCLES[scen.cycle] = load_cycle(scen.cycle)
    v = np.tile(_CYCLES[scen.cycle], scen.n_rep)
    T0 = scen.T_amb_C if scen.T0_C is None else scen.T0_C
    C = np.array([ctrl.c_dis, ctrl.c_ch, ctrl.g_soh, ctrl.T_der, ctrl.T_set, ctrl.Kp, ctrl.Ki, ctrl.u_max])
    S = np.array([scen.T_amb_C, scen.SoH0, scen.soc0, T0, scen.soh_est_err, scen.kR_nom])
    out, Tb, Ib, Sb, Ub, Db = _sim(v, _pvec(params), C, S, OCV_SOC, OCV_V, R_SOC, R_VAL, MODES[ctrl.mode], trace)
    res = dict(zip(NAMES, out[:len(NAMES)]))
    res["kWh_per_100km"] = res["E_batt_kWh"] / max(res["dist_km"], 1e-9) * 100.0
    res["loss_pct_per_100km"] = res["loss_pct"] / max(res["dist_km"], 1e-9) * 100.0
    if trace:
        res["trace"] = dict(T=Tb, I=Ib, soc=Sb, u=Ub, dT=Db, v=v)
    return res

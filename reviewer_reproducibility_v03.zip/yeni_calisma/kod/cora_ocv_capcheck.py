"""OCV(SoC) eğrisi: düşük akımlı (≈C/4) kapasite kontrol deşarjından, IR düzeltmeli.
V_oc = V_term + |I_hücre| * R_hücre (deşarj akımı negatif). SoC aralıkları %2.
Çıktı: veri/cora_ocv_curve.csv"""
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "matlab_simulink_project" / "external_validation" / "CORA_WLTP"
NS, NP, R_CELL = 12, 3, 12.0e-3
files = sorted(f for f in SRC.glob("Qtzl_Cycle_*_Capacity_check.parquet"))
files = [files[i] for i in np.unique(np.linspace(0, len(files) - 1, 25).round().astype(int))]
acc = []
for f in files:
    d = pd.read_parquet(f, columns=["Semicycle", "Current_Actual_Battery [A]", "Voltage_Actual_Battery [V]", "SoC_Actual_Battery [percent]"])
    d = d[(d.Semicycle == "Capacity check Discharge") & (d["Current_Actual_Battery [A]"] < -0.5)].iloc[::10]
    I = d["Current_Actual_Battery [A]"] / NP
    acc.append(pd.DataFrame({"soc": d["SoC_Actual_Battery [percent]"], "voc": d["Voltage_Actual_Battery [V]"] / NS - I * R_CELL}))
D = pd.concat(acc)
D["bin"] = (D.soc // 2) * 2 + 1
o = D.groupby("bin").agg(n=("voc", "size"), ocv_cell_V=("voc", "median")).reset_index().rename(columns={"bin": "soc"})
o = o[o.n >= 50]
o.to_csv(ROOT / "yeni_calisma/veri/cora_ocv_curve.csv", index=False)
print(o.round(3).to_string(index=False))

"""Aşama 3: kontrolcü modlarının eşit bütçeli, kısıtlı optimizasyonu ve eğitim/test ayrımı.

Amaç (eğitim senaryoları üzerinde ortalama):
    min  J = mean_s [ loss_s / loss_ref_s + lam_E * kWh100_s / kWh100_ref_s ]
    s.t. kısıt cezası: güç kısıtı (shortfall) ≤ eps_short, gerilim penceresi ihlali = 0, Tmax ≤ T_safe
Referans (ref): aynı senaryoda `fixed` mod nominal limitlerle (c_dis=2, c_ch=1).
Her mod aynı karar uzayında ve aynı DE bütçesinde optimize edilir; `fixed` optimize edilmez (OEM nominal limit).
Çıktılar: sonuclar/faz3_best_vectors.csv, sonuclar/faz3_test_metrics.csv
"""
from pathlib import Path
import sys
import time
import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution

sys.path.insert(0, str(Path(__file__).resolve().parent))
from evbms import Controller, Params, Scenario, simulate

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "sonuclar"

EPS_SHORT = 0.02
LAM_E = 0.5
LIQUID = Params()
AIR = Params(dT_chill_C=0.0, UA_cool_pack_W_K=60.0, P_cool_max_W=400.0)

# (ad, Scenario, Params)
TRAIN = [
    ("WLTP_25C_SoH100", Scenario(cycle="WLTP", T_amb_C=25, SoH0=1.0, soc0=0.9), LIQUID),
    ("UDDS_25C_SoH80", Scenario(cycle="UDDS", T_amb_C=25, SoH0=0.8, soc0=0.9), LIQUID),
    ("WLTP_35C_SoH90_air", Scenario(cycle="WLTP", n_rep=2, T_amb_C=35, SoH0=0.9, soc0=0.7), AIR),
    ("UDDS_10C_SoH80", Scenario(cycle="UDDS", T_amb_C=10, SoH0=0.8, soc0=0.5), LIQUID),
]
TEST = [
    ("US06_25C_SoH90", Scenario(cycle="US06", T_amb_C=25, SoH0=0.9, soc0=0.9), LIQUID),
    ("WLTP_0C_SoH70_lowSoC", Scenario(cycle="WLTP", T_amb_C=0, SoH0=0.7, soc0=0.3), LIQUID),
    ("US06_0C_SoH70_lowSoC", Scenario(cycle="US06", T_amb_C=0, SoH0=0.7, soc0=0.25), LIQUID),
    ("US06x4_45C_SoH70_air", Scenario(cycle="US06", n_rep=4, T_amb_C=45, SoH0=0.7, soc0=0.95), AIR),
    ("UDDSx4_45C_SoH80_air", Scenario(cycle="UDDS", n_rep=4, T_amb_C=45, SoH0=0.8, soc0=0.9), AIR),
    ("WLTPx2_40C_SoH60_air", Scenario(cycle="WLTP", n_rep=2, T_amb_C=40, SoH0=0.6, soc0=0.9), AIR),
    ("WLTP_-10C_SoH60", Scenario(cycle="WLTP", T_amb_C=-10, SoH0=0.6, soc0=0.3), LIQUID),
    ("UDDS_25C_SoH60", Scenario(cycle="UDDS", T_amb_C=25, SoH0=0.6, soc0=0.9), LIQUID),
]
NOMINAL = Controller(mode="fixed", c_dis=2.0, c_ch=1.0)

BOUNDS = [(0.5, 4.0), (0.2, 2.0), (0.0, 2.0), (35.0, 55.0), (25.0, 45.0), (0.01, 1.0), (-4.0, -2.0)]  # Ki = 10**x


def vec_to_ctrl(mode, x):
    return Controller(mode=mode, c_dis=x[0], c_ch=x[1], g_soh=x[2], T_der=x[3], T_set=x[4], Kp=x[5], Ki=10 ** x[6])


_REF_CACHE = {}


def reference(name, scen, params):
    if name not in _REF_CACHE:
        _REF_CACHE[name] = simulate(NOMINAL, scen, params)
    return _REF_CACHE[name]


def cost(mode, x, suite):
    ctrl = vec_to_ctrl(mode, x)
    J, pen = 0.0, 0.0
    for name, scen, params in suite:
        r = simulate(ctrl, scen, params)
        ref = reference(name, scen, params)
        J += r["loss_pct_per_100km"] / max(ref["loss_pct_per_100km"], 1e-12) + LAM_E * r["kWh_per_100km"] / max(ref["kWh_per_100km"], 1e-9)
        pen += max(0.0, r["shortfall_frac"] - EPS_SHORT) * 50.0
        pen += min(r["n_violations"], 300) * 0.05
        pen += max(0.0, r["Tmax_C"] - params.T_safe_C) * 0.5
    return J / len(suite) + pen / len(suite)


def metrics_row(mode, tag, ctrl, name, scen, params):
    r = simulate(ctrl, scen, params)
    ref = reference(name, scen, params)
    return dict(mode=mode, tag=tag, scenario=name,
                loss_per100km=r["loss_pct_per_100km"], loss_rel_fixed=r["loss_pct_per_100km"] / max(ref["loss_pct_per_100km"], 1e-12),
                kWh100=r["kWh_per_100km"], kWh100_rel_fixed=r["kWh_per_100km"] / ref["kWh_per_100km"],
                shortfall_pct=100 * r["shortfall_frac"], outwindow_s=r["n_violations"], Tmax_C=r["Tmax_C"],
                Tend_C=r["T_end_C"], t_derate_s=r["t_derating_s"], E_regen_kWh=r["E_regen_kWh"], E_cool_kWh=r["E_cool_kWh"],
                Vcell_min=r["Vcell_min_V"])


def main(maxiter=60, popsize=12, seeds=(1, 2, 3)):
    t0 = time.time()
    best_rows, test_rows = [], []
    # ayarsız referanslar
    for name, scen, params in TRAIN + TEST:
        test_rows.append(metrics_row("fixed", "nominal", NOMINAL, name, scen, params))
    for mode in ("unaware", "aware_S", "aware_RS"):
        best = None
        for seed in seeds:
            res = differential_evolution(lambda x: cost(mode, x, TRAIN), BOUNDS, maxiter=maxiter, popsize=popsize,
                                         seed=seed, tol=1e-7, polish=False, updating="immediate")
            best_rows.append(dict(mode=mode, seed=seed, J_train=res.fun, nfev=res.nfev,
                                  **dict(zip(["c_dis", "c_ch", "g_soh", "T_der", "T_set", "Kp", "log10Ki"], res.x))))
            if best is None or res.fun < best[0]:
                best = (res.fun, res.x)
            print(f"{mode:9s} seed {seed}  J_train={res.fun:.4f}  nfev={res.nfev}  t={time.time()-t0:.0f}s", flush=True)
        ctrl = vec_to_ctrl(mode, best[1])
        for name, scen, params in TRAIN + TEST:
            test_rows.append(metrics_row(mode, "optimized", ctrl, name, scen, params))
    pd.DataFrame(best_rows).to_csv(OUT / "faz3_best_vectors.csv", index=False)
    T = pd.DataFrame(test_rows)
    T["split"] = T.scenario.map({n: "train" for n, _, _ in TRAIN} | {n: "test" for n, _, _ in TEST})
    T.to_csv(OUT / "faz3_test_metrics.csv", index=False)
    pd.set_option("display.width", 220)
    print(T[T.split == "test"].pivot(index="scenario", columns="mode",
                                      values=["loss_rel_fixed", "shortfall_pct", "outwindow_s", "Tmax_C"]).round(3).to_string())


if __name__ == "__main__":
    main()

"""Lu et al. Dataset #3/#5: döngü bazlı kapasite ve SoH eğrilerini CSV'ye yazar ve güç yasası uydurur.
Kapasite = gerilim ızgarasının son noktasındaki kümülatif şarj kapasitesi. SoH = Q_k / Q_1 (ilk geçerli döngü).
Çıktı: veri/lu_soh_trajectories.csv, sonuclar/lu_fade_fit.csv"""
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import curve_fit

ROOT = Path(__file__).resolve().parents[2]
D = ROOT / "Battery Degradation Datasets (Two Types of Lithium-ion Batteries)"
rows = []
for fn, ds, chem, tc in [("Dataset#3.xlsx", "Dataset3", "NCR18650BD", 20), ("Dataset#5.xlsx", "Dataset5", "IFP20100140A", 45)]:
    xl = pd.ExcelFile(D / fn)
    for sh in xl.sheet_names:
        raw = pd.read_excel(D / fn, sheet_name=sh, header=None)
        q = pd.to_numeric(raw.iloc[2:, 1:].iloc[:, -1], errors="coerce").dropna().to_numpy()
        for k, qq in enumerate(q, 1):
            rows.append(dict(dataset=ds, chem=chem, T_C=tc, cell=sh, cycle=k, Q_Ah=qq, SoH=100 * qq / q[0]))
T = pd.DataFrame(rows)
T.to_csv(ROOT / "yeni_calisma/veri/lu_soh_trajectories.csv", index=False)

fits = []
for (ds, cell), g in T.groupby(["dataset", "cell"]):
    n, loss = g.cycle.to_numpy(float), 100 - g.SoH.to_numpy()
    f = lambda n, a, z: a * n ** z
    (a, z), _ = curve_fit(f, n, loss, p0=[0.02, 1.0], maxfev=20000)
    r = loss - f(n, a, z)
    # doğrusal karşılaştırma
    b1 = np.polyfit(n, loss, 1)
    r1 = loss - np.polyval(b1, n)
    fits.append(dict(dataset=ds, cell=cell, n_cycles=int(n[-1]), final_loss_pct=loss[-1], a=a, z=z,
                     rmse_power=np.sqrt(np.mean(r ** 2)), rmse_linear=np.sqrt(np.mean(r1 ** 2)),
                     loss_per_cycle_linear=b1[0]))
F = pd.DataFrame(fits)
F.to_csv(ROOT / "yeni_calisma/sonuclar/lu_fade_fit.csv", index=False)
print(F.round(4).to_string(index=False))

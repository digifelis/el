"""Paket modelinin terminal gerilim hatası: V_hücre = OCV(SoC) − I_hücre·R(SoC,T), ölçülen SoC/T/I ile (tek adım, durum geri beslemesi yok).
R(SoC,T) ve OCV, cora_R_ocv.py'nin kullandığı 80 dosyadan çıkarıldı; burada o 80 dosyanın DIŞINDAKİ çevrimler kullanılıyor (R/OCV için dışarıda bırakılmış).
Not: SoC ölçülen değerdir (modelin SoC dinamiği sınanmıyor). Çıktı: sonuclar/cora_gerilim_dogrulama.csv"""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from evbms import OCV_SOC, OCV_V, R_SOC, R_VAL, _R_cell
from cora_R_ocv import SRC, I_COL, V_COL, SOC_COL, TOP, BOT, NS, NP

files = [f for f in sorted(SRC.glob("Qtzl_Cycle_*.parquet")) if "partial" not in f.name]
used = set(np.unique(np.linspace(0, len(files) - 1, 80).round().astype(int)))
held = [i for i in range(len(files)) if i not in used]
pick = [held[j] for j in np.linspace(0, len(held) - 1, 12).round().astype(int)]
rows = []
for i in pick:
    d = pd.read_parquet(files[i], columns=["Semicycle", I_COL, V_COL, SOC_COL] + TOP + BOT).iloc[::5]
    T = d[TOP + BOT]; d["T"] = T.where((T > -20) & (T < 100)).mean(axis=1)
    for sem, g in d.groupby(d.Semicycle.str.replace(r"\d+", "", regex=True)):
        g = g.dropna(subset=["T", SOC_COL])
        g = g[(g[SOC_COL] > 5) & (g[SOC_COL] < 100) & (g[I_COL].abs() > 0.2)]
        if len(g) < 200: continue
        soc = g[SOC_COL].to_numpy() / 100; Tt = g["T"].to_numpy(); I = -g[I_COL].to_numpy() / NP  # deşarj + (veride deşarj negatif)
        R = np.array([_R_cell(s, t, 1.0, 1.5, 20e3, 27.0, R_SOC, R_VAL) for s, t in zip(soc, Tt)])
        Vm = g[V_COL].to_numpy() / NS
        Vp = np.interp(soc, OCV_SOC, OCV_V) - I * R
        e = Vp - Vm
        rows.append(dict(file=files[i].name, semicycle=sem, n=len(g), rmse_mV=1e3 * np.sqrt(np.mean(e**2)), bias_mV=1e3 * e.mean(),
                         nrmse_pct=100 * np.sqrt(np.mean(e**2)) / (Vm.max() - Vm.min()), mape_pct=100 * np.mean(np.abs(e) / Vm)))
D = pd.DataFrame(rows); D.to_csv(Path(__file__).resolve().parents[1] / "sonuclar" / "cora_gerilim_dogrulama.csv", index=False)
pd.set_option("display.width", 200)
print(D.groupby("semicycle")[["n", "rmse_mV", "bias_mV", "nrmse_pct", "mape_pct"]].agg({"n": "sum", "rmse_mV": "median", "bias_mV": "median", "nrmse_pct": "median", "mape_pct": "median"}).round(2))
print("tüm:", D[["rmse_mV", "bias_mV", "nrmse_pct", "mape_pct"]].median().round(2).to_dict(), "çevrim:", len(pick))

"""CORA paket verisinden döngü bazlı özet çıkarır (kapasite, direnç, sıcaklık).

Çıktı: yeni_calisma/veri/cora_cycle_summary.csv
Akım işareti bu veri setinde: deşarj negatif, şarj pozitif.
"""
from pathlib import Path
import re
import sys
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "matlab_simulink_project" / "external_validation" / "CORA_WLTP"
OUT = ROOT / "yeni_calisma" / "veri" / "cora_cycle_summary.csv"

I_COL = "Current_Actual_Battery [A]"
V_COL = "Voltage_Actual_Battery [V]"
SOC_COL = "SoC_Actual_Battery [percent]"
TCH_COL = "Temperature_IN_Chamber [degC]"
R_COL = "Resistance_Actual_Battery_IT5101 [Ohm]"
TS_COL = "Timestamp"


def summarize(path: Path) -> dict:
    m = re.match(r"Qtzl_Cycle_(\d+)_(.+?)(_partial_data)?\.parquet", path.name)
    cycle, kind, partial = int(m.group(1)), m.group(2), bool(m.group(3))
    schema = pq.read_schema(path).names
    tcols = [c for c in schema if c.startswith("Temperature_Cell_")]
    cols = ["Semicycle", TS_COL, I_COL, V_COL, SOC_COL, TCH_COL, R_COL] + tcols
    d = pd.read_parquet(path, columns=cols)
    t = (pd.to_datetime(d[TS_COL]) - pd.to_datetime(d[TS_COL].iloc[0])).dt.total_seconds().to_numpy()
    dt = np.diff(t, prepend=t[0])
    I = d[I_COL].to_numpy()
    d["Tcell"] = d[tcols].mean(axis=1)

    row = dict(cycle=cycle, kind=kind, partial=partial, rows=len(d),
               t_chamber_C=float(d[TCH_COL].median()))

    dis = d["Semicycle"].str.contains("Discharge") & (I < 0)
    chg = d["Semicycle"].str.contains("Charge") & (I > 0)
    row["Q_dis_Ah"] = float(np.sum(-I[dis] * dt[dis]) / 3600) if dis.any() else np.nan
    row["Q_chg_Ah"] = float(np.sum(I[chg] * dt[chg]) / 3600) if chg.any() else np.nan

    w = d["Semicycle"] == "WLTP"
    if w.any():
        Iw, tw = I[w.to_numpy()], dt[w.to_numpy()]
        row["wltp_Ah_dis"] = float(np.sum(-Iw[Iw < 0] * tw[Iw < 0]) / 3600)
        row["wltp_Ah_reg"] = float(np.sum(Iw[Iw > 0] * tw[Iw > 0]) / 3600)
        row["wltp_I_min_A"] = float(Iw.min())
        row["wltp_I_max_A"] = float(Iw.max())
        row["wltp_soc_start"] = float(d.loc[w, SOC_COL].iloc[0])
        row["wltp_soc_end"] = float(d.loc[w, SOC_COL].iloc[-1])
        row["wltp_T_start_C"] = float(d.loc[w, "Tcell"].iloc[0])
        row["wltp_T_max_C"] = float(d.loc[w, "Tcell"].max())
        row["wltp_dT_C"] = row["wltp_T_max_C"] - row["wltp_T_start_C"]

    # IT5101 direnç: SoC aralıklarında medyan (soğutma/dinlenme dışı, tüm semicycle)
    for lo, hi in [(20, 40), (40, 60), (60, 80), (80, 100)]:
        s = (d[SOC_COL] >= lo) & (d[SOC_COL] < hi)
        row[f"R_it5101_soc{lo}_{hi}_ohm"] = float(d.loc[s, R_COL].median()) if s.sum() > 50 else np.nan

    # Akım adımlarından DC direnci: ardışık örnekte |dI| > 3 A iken dV/dI
    V = d[V_COL].to_numpy()
    dI, dV = np.diff(I), np.diff(V)
    step = np.abs(dI) > 3.0
    row["R_step_n"] = int(step.sum())
    row["R_step_median_ohm"] = float(np.median(-dV[step] / -dI[step])) if step.sum() > 20 else np.nan
    return row


def main():
    files = sorted(p for p in SRC.glob("Qtzl_Cycle_*.parquet"))
    rows = []
    for i, p in enumerate(files, 1):
        try:
            rows.append(summarize(p))
        except Exception as e:  # tek dosya hatası tüm işi durdurmasın
            print("HATA", p.name, e, file=sys.stderr)
        if i % 40 == 0:
            print(i, "/", len(files), flush=True)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).sort_values("cycle").to_csv(OUT, index=False)
    print("yazıldı:", OUT, len(rows))


if __name__ == "__main__":
    main()

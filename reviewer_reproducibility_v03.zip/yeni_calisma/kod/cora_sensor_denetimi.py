"""CORA hücre sıcaklık sensörlerinde arızalı (aralık dışı) değerleri tarar.
Çıktı: veri/cora_sensor_audit.csv (dosya başına arızalı sensör listesi, sahte ve gerçek ortalama)."""
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "matlab_simulink_project" / "external_validation" / "CORA_WLTP"
cols = [f"Temperature_Cell_{pos}_P{p}S{s} [degC]" for p in (1, 2, 3) for s in range(1, 13) for pos in ("Top", "Bottom")]
rows = []
files = sorted(f for f in SRC.glob("Qtzl_Cycle_*.parquet"))
for f in files:
    d = pd.read_parquet(f, columns=["Semicycle"] + cols)
    d = d[d.Semicycle.isin(["WLTP", "Capacity check Discharge", "Capacity check Charge", "Constant Charge", "Stand by"])].iloc[::20]
    T = d[cols]
    bad = [c.replace("Temperature_Cell_", "").replace(" [degC]", "") for c in cols
           if ((T[c] > 100) | (T[c] < -20)).mean() > 0.01]
    naive = T.mean(axis=1)
    good = T.where((T > -20) & (T < 100)).mean(axis=1)
    rows.append(dict(file=f.name, n_bad=len(bad), bad=";".join(bad),
                     naive_mean_C=naive.mean(), valid_mean_C=good.mean(), bias_C=(naive - good).mean()))
out = pd.DataFrame(rows)
out.to_csv(ROOT / "yeni_calisma" / "veri" / "cora_sensor_audit.csv", index=False)
print("dosya:", len(out), " arızalı sensörlü:", (out.n_bad > 0).sum())
print(out.bad.value_counts().head(8).to_string())
print("ortalama sapma (naive - valid) arızalı dosyalarda: %.2f °C (min %.1f, max %.1f)" % (
    out[out.n_bad > 0].bias_C.mean(), out.bias_C.min(), out.bias_C.max()))

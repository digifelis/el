from pathlib import Path
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
RES = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"; FIG = Path(__file__).resolve().parents[2] / "sekiller" / "v3"
plt.rcParams.update({"font.size": 8, "axes.grid": True, "grid.alpha": 0.3, "savefig.dpi": 300})
D = pd.read_csv(RES / "pareto_front.csv"); feas = D.fPerf == 0
fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.0))
sc = ax[0].scatter(D.Tmax - 25.0, D.loss100 / 0.0233 if False else D.fAge, c=np.minimum(D.shortfall_pct, 40), s=22, cmap="viridis", edgecolor=np.where(feas, "r", "none"))
ax[0].set_xlabel("Temperature rise T_max − T_amb (°C)"); ax[0].set_ylabel("Relative aging proxy (fixed = 1)")
cb = fig.colorbar(sc, ax=ax[0]); cb.set_label("Power shortfall (%, capped at 40)")
sc2 = ax[1].scatter(D.coolWh, D.shortfall_pct, c=D.Tmax - 25.0, s=22, cmap="plasma", edgecolor=np.where(feas, "r", "none"))
ax[1].set_xlabel("Cooling energy (Wh)"); ax[1].set_ylabel("Power shortfall (%)"); ax[1].set_yscale("symlog", linthresh=2)
cb2 = fig.colorbar(sc2, ax=ax[1]); cb2.set_label("Temperature rise (°C)")
ax[1].axhline(2.0, color="r", ls="--", lw=0.8); ax[1].text(D.coolWh.max() * 0.5, 2.3, "ε = 2 %", color="r", fontsize=7)
fig.tight_layout(); fig.savefig(FIG / "fig09_pareto.png"); fig.savefig(FIG / "fig09_pareto.pdf")
print(D.describe().round(3).T[["min","max"]].head(20))

"""Tablo IX, XIV-A/B, XV; Şekil 8, 10, 11 (bench_*.csv girdisi)."""
from itertools import combinations
from pathlib import Path
import numpy as np, pandas as pd, matplotlib
from scipy.stats import binomtest
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RES = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
FIG = Path(__file__).resolve().parents[2] / "sekiller" / "v3"
plt.rcParams.update({"font.size": 8, "axes.grid": True, "grid.alpha": 0.3, "savefig.dpi": 300})
R = pd.read_csv(RES / "bench_runs.csv"); V = pd.read_csv(RES / "bench_vectors.csv"); CV = pd.read_csv(RES / "bench_conv.csv")
ALG = ["GWO", "GOA", "PSO", "GA", "Hybrid SFO-GOA", "SFO"]
ALG = [a for a in ALG if a in R.algo.unique()]
J = {a: R[R.algo == a].sort_values("run").J.to_numpy() for a in ALG}
M = np.vstack([J[a] for a in ALG])
ranks = pd.DataFrame(M).rank(axis=0).mean(axis=1).to_numpy()
t9 = pd.DataFrame([dict(method=a, mean=J[a].mean(), sd=J[a].std(ddof=1), median=np.median(J[a]), iqr=np.subtract(*np.percentile(J[a], [75, 25])),
                        min=J[a].min(), rank=ranks[i], nfe=R[R.algo == a].nfe.mean()) for i, a in enumerate(ALG)]).sort_values("mean")
t9.to_csv(RES / "tab9_optimizer.csv", index=False); print(t9.round(5).to_string(index=False))

rows = []
for a, b in combinations(ALG, 2):
    x, y = J[a], J[b]
    wa, wb = int((x < y).sum()), int((x > y).sum())
    p = binomtest(wa, wa + wb, 0.5).pvalue if wa + wb else 1.0
    gt = (x[:, None] > y[None, :]).mean(); lt = (x[:, None] < y[None, :]).mean()
    rows.append(dict(A=a, B=b, winA=wa, winB=wb, p=p, cliff=gt - lt, A12=lt + 0.5 * (1 - gt - lt)))
P = pd.DataFrame(rows).sort_values("p").reset_index(drop=True)
m = len(P); adj = np.maximum.accumulate([min(1.0, (m - i) * p) for i, p in enumerate(P.p)])
P["holm_p"] = adj; P.to_csv(RES / "tab15_pairs.csv", index=False); print(P.round(5).to_string(index=False))

# en iyi vektörler
best = []
for a in ALG:
    rr = R[R.algo == a].sort_values("J").iloc[0]
    v = V[(V.algo == a) & (V.run == rr.run)].iloc[0]
    best.append(dict(method=a, **{k: v[k] for k in ["c_dis", "c_ch", "g_SoH", "T_der", "T_set", "Kp", "log10Ki"]}, J=rr.J))
pd.DataFrame(best).to_csv(RES / "tab14_best.csv", index=False)

# Şekil 8 ve 10
def box(ax, col, ylabel, scale=1.0):
    data = [R[R.algo == a][col].to_numpy() * scale for a in ALG]
    ax.boxplot(data, tick_labels=[a.replace("Hybrid ", "") for a in ALG], showmeans=True, meanprops=dict(marker="D", markerfacecolor="w", markeredgecolor="k", markersize=4))
    ax.set_ylabel(ylabel); ax.tick_params(axis="x", rotation=45, labelsize=7)
fig, ax = plt.subplots(figsize=(3.6, 3.0)); box(ax, "J", "Weighted objective J"); fig.tight_layout()
fig.savefig(FIG / "fig08_dist.png"); fig.savefig(FIG / "fig08_dist.pdf"); plt.close(fig)
fig, ax = plt.subplots(1, 3, figsize=(8.4, 3.2))
box(ax[0], "J", "Weighted objective J"); box(ax[1], "Tmax", "Maximum temperature (°C)"); box(ax[2], "loss100", "Aging proxy (% per 100 km)")
fig.tight_layout(); fig.savefig(FIG / "fig10_dist3.png"); fig.savefig(FIG / "fig10_dist3.pdf"); plt.close(fig)

# Şekil 11 yakınsama (kümülatif NFE)
def nfe_axis(a, n):
    k = np.arange(1, n + 1)
    if a == "Hybrid SFO-GOA":
        return np.where(k <= 20, 24 + 24 * k, 528 + 24 * (k - 20))
    if a == "GA":
        return 24 + 23 * k
    return 24 + 24 * k
fig, ax = plt.subplots(figsize=(3.8, 3.0))
for a in ALG:
    g = CV[CV.algo == a].pivot(index="it", columns="run", values="best")
    x = nfe_axis(a, len(g)); mu, sd = g.mean(1).to_numpy(), g.std(1).to_numpy()
    ax.plot(x, mu, label=a.replace("Hybrid ", "")); ax.fill_between(x, mu - sd, mu + sd, alpha=0.15)
ax.set_xlabel("Cumulative function evaluations"); ax.set_ylabel("Best-so-far J"); ax.legend(frameon=False, fontsize=7)
fig.tight_layout(); fig.savefig(FIG / "fig11_conv.png"); fig.savefig(FIG / "fig11_conv.pdf"); plt.close(fig)

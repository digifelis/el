"""Şekil 1, 2, 3, 12: mimari, doğrulama merdiveni, iki aşamalı optimizasyon akışı, kontrolcü mantığı (matplotlib)."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = Path(__file__).resolve().parents[2] / "sekiller" / "v3"
plt.rcParams.update({"font.size": 8, "savefig.dpi": 300})
C = dict(online="#dbe9f6", plant="#fde9d0", offline="#e3f1df", valid="#efe1f3", edge="#333333")


def box(ax, x, y, w, h, text, fc, fs=8, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.05", fc=fc, ec=C["edge"], lw=0.8))
    t = ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal")
    fig = ax.figure
    fig.canvas.draw()
    inv = ax.transData.inverted()
    while True:   # metni kutuya sığdır
        bb = t.get_window_extent(fig.canvas.get_renderer())
        (x0, y0), (x1, y1) = inv.transform((bb.x0, bb.y0)), inv.transform((bb.x1, bb.y1))
        if (x1 - x0) <= w * 0.96 and (y1 - y0) <= h * 0.92 or t.get_fontsize() <= 4.5:
            break
        t.set_fontsize(t.get_fontsize() - 0.25)


def arrow(ax, p, q, dashed=False, text=None, off=(0, 0.08), rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=9, lw=0.9, color=C["edge"], ls="--" if dashed else "-", connectionstyle=f"arc3,rad={rad}"))
    if text:
        ax.text((p[0] + q[0]) / 2 + off[0], (p[1] + q[1]) / 2 + off[1], text, ha="center", va="bottom", fontsize=7, style="italic")


def new(w=7.2, h=3.6):
    fig, ax = plt.subplots(figsize=(w, h)); ax.set_xlim(0, 10); ax.set_ylim(0, 5); ax.axis("off"); return fig, ax


def save(fig, n):
    fig.savefig(OUT / f"{n}.png", bbox_inches="tight"); fig.savefig(OUT / f"{n}.pdf", bbox_inches="tight"); plt.close(fig)


# ---- Fig 1: architecture
fig, ax = new(7.2, 3.9)
box(ax, 0.1, 3.7, 2.0, 0.9, "Drive cycle\n(WLTP, UDDS, US06)\nspeed trace", C["online"])
box(ax, 2.6, 3.7, 1.9, 0.9, "Road-load power\nP_w = (m a + F_r + F_a) v", C["online"])
box(ax, 5.0, 3.7, 2.2, 0.9, "BMS current-limit law\nSoH_est, R̂(SoC,T,SoH_est)\nEqs. (12)–(17)", C["online"], bold=True)
box(ax, 7.7, 3.7, 2.2, 0.9, "Cooling controller\nPI on T_cell − T_set", C["online"])
box(ax, 2.6, 1.9, 4.6, 1.0, "Pack plant (96S22P)\nOCV–R(SoC,T,SoH) equivalent circuit · lumped thermal model\nSoC counting · aging proxy", C["plant"], bold=True)
box(ax, 0.1, 0.1, 2.9, 1.1, "Offline tuning\n(hybrid SFO-GOA, GWO, PSO, GA,\nNSGA-II, MPC baseline)", C["offline"])
box(ax, 3.4, 0.1, 3.0, 1.1, "External calibration\nCORA pack: R(SoC,T), OCV, thermal\nholdouts (voltage, temperature)", C["valid"])
box(ax, 6.8, 0.1, 3.1, 1.1, "Closed-loop reference EV\nMathWorks Powertrain Blockset\n(law inserted in memory)", C["valid"])
arrow(ax, (2.1, 4.15), (2.6, 4.15)); arrow(ax, (4.5, 4.15), (5.0, 4.15))
arrow(ax, (5.9, 3.7), (5.4, 2.9), text="I_applied", off=(-0.85, 0.0))
arrow(ax, (6.5, 2.9), (6.0, 3.7), dashed=True, text="T, SoC, V_oc", off=(0.45, -0.3))
arrow(ax, (8.3, 3.7), (7.0, 2.9), text="u_cool", off=(1.0, 0.15))
arrow(ax, (7.2, 2.5), (7.9, 3.7), dashed=True, text="T_cell", off=(1.0, -0.5))
arrow(ax, (1.5, 1.2), (3.2, 1.9), dashed=True, text="parameters", off=(-0.5, 0.05)); arrow(ax, (4.9, 1.2), (4.9, 1.9), dashed=True)
arrow(ax, (8.3, 1.2), (6.6, 1.9), dashed=True)
save(fig, "fig01_architecture")

# ---- Fig 2: validation ladder
fig, ax = new(7.2, 3.2)
levels = [("1", "Reduced-order simulator", "17 drive scenarios; relative comparisons,\nparameter sweeps, ablations", C["offline"]),
          ("2", "Parity and unit tests", "Independent re-implementation;\nenergy, SoC and thermal balance checks", C["online"]),
          ("3", "External pack data (CORA)", "R(SoC,T), OCV; holdout cycles for voltage;\nthermal fit, held-out cycles", C["valid"]),
          ("4", "Reference plant (Powertrain Blockset)", "Closed loop: speed tracking, window violations,\npeak current, knowledge-error sweeps", C["plant"])]
for i, (n, t, d, col) in enumerate(levels):
    x = 0.2 + i * 0.35; y = 0.3 + i * 1.1; w = 9.4 - i * 0.7
    box(ax, x, y, w, 0.95, f"Level {n}: {t}\n{d}", col, fs=8, bold=False)
ax.annotate("", xy=(9.7, 4.6), xytext=(9.7, 0.4), arrowprops=dict(arrowstyle="-|>", lw=1.2))
ax.text(9.85, 2.5, "Increasing independence from the model", rotation=90, va="center", fontsize=7.5)
ax.text(0.2, 4.85, "No level is a physical vehicle, HIL, or abuse test", fontsize=7.5, style="italic")
save(fig, "fig02_ladder")

# ---- Fig 3: two-stage optimization
fig, ax = new(7.2, 2.7)
box(ax, 0.1, 3.0, 1.6, 1.3, "Random\ninitial\npopulation\n(24)", C["offline"])
box(ax, 2.1, 3.0, 2.3, 1.3, "Stage 1: SFO\n20 iterations\narm motion / hunting\n(exploration)", C["offline"], bold=True)
box(ax, 4.8, 3.0, 2.1, 1.3, "Best vector\nGaussian cloud\n(radius 0.18 × range)", C["online"])
box(ax, 7.3, 3.0, 2.5, 1.3, "Stage 2: GOA-style\nrefinement, 20 iterations\n(exploitation)", C["offline"], bold=True)
box(ax, 7.3, 0.6, 2.5, 1.2, "Best decision vector\nJ, T_max, shortfall", C["plant"])
box(ax, 2.1, 0.6, 4.8, 1.2, "Budget: 24 + 24·20 + 24 + 24·20 = 1008 evaluations per run\n(single-phase methods: 24·42 = 1008)", C["valid"])
for p, q in (((1.7, 3.65), (2.1, 3.65)), ((4.4, 3.65), (4.8, 3.65)), ((6.9, 3.65), (7.3, 3.65)), ((8.55, 3.0), (8.55, 1.8))):
    arrow(ax, p, q)
save(fig, "fig03_workflow")

# ---- Fig 12: controller logic
fig, ax = new(7.2, 4.4)
box(ax, 0.1, 3.9, 2.0, 0.8, "Measurements\nSoC, T_cell, V_oc, I_req", C["online"])
box(ax, 0.1, 2.6, 2.0, 0.9, "SoH_est, k_R,nom\n(BMS knowledge)", C["valid"])
box(ax, 2.6, 3.9, 2.4, 0.8, "s_SoH = 1 − g (1 − SoH_est)\nd_T = (T_crit − T)/(T_crit − T_der)", C["online"])
box(ax, 2.4, 2.5, 2.8, 1.1, "cell R̂ = R_ref(SoC) e^{E_R/R_g (1/T−1/T_ref)}\n· [1 + k_R,nom (1 − SoH_est)]\nR̂_p = R̂ N_s/N_p", C["online"])
box(ax, 5.5, 3.9, 2.2, 0.8, "I_dis,C = c_dis N_pQ0 s_SoH d_T\nI_ch,C = c_ch N_pQ0 s_SoH d_T τ", C["online"])
box(ax, 5.5, 2.6, 2.2, 0.9, "I_dis,V = (V_oc − N_s V_min)/R̂_p\nI_ch,V = (N_s V_max − V_oc)/R̂_p", C["online"])
box(ax, 4.0, 1.0, 3.2, 1.0, "I_applied = min{ I_dis,max,\nmax[ −I_ch,max, I_req ] }", C["plant"], bold=True)
box(ax, 8.1, 1.0, 1.8, 1.0, "Pack plant\n(true R, true SoH)", C["plant"])
box(ax, 0.1, 0.1, 3.4, 0.9, "Cooling PI: u = Kp e + Ki ∫e,\ne = T − T_set, 0 ≤ u ≤ 1", C["online"])
for p, q in (((2.1, 4.3), (2.6, 4.3)), ((5.0, 4.3), (5.5, 4.3)), ((2.1, 3.05), (2.6, 3.05)), ((5.0, 3.05), (5.5, 3.05)),
             ((6.2, 2.6), (6.0, 2.0)), ((7.2, 1.5), (8.1, 1.5))):
    arrow(ax, p, q)
arrow(ax, (7.7, 3.9), (7.1, 2.0), rad=-0.25)
arrow(ax, (9.0, 1.0), (3.5, 0.55), dashed=True, text="T_cell", off=(0, 0.05))
ax.text(5.0, 4.85, "Modes: fixed (C-rate only) · unaware (voltage bound, fresh R̂, g = 0) · aware_S (+ SoH scaling) · aware_RS (+ R̂ with SoH_est)", ha="center", fontsize=7)
save(fig, "fig12_logic")
print("ok")

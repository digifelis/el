"""Tablo XII ve Şekil 9: dört amaçlı NSGA-II (pop 48, 40 nesil), WLTP 25 °C SoH 0,80, aware_RS limit yasası.
Amaçlar (normalize): sıcaklık artışı/30, soğutma enerjisi/250 Wh, yaşlanma vekili (sabit limitleyiciye göre oran), performans (f_perf).
"""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from objective import LB, UB, NAMES, vec_to_ctrl, SCEN, PAR, NOMINAL, EPS
from evbms import simulate

OUT = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
REF = simulate(NOMINAL, SCEN, PAR)


def objs(x):
    r = simulate(vec_to_ctrl(x), SCEN, PAR)
    fP = max(0.0, r["shortfall_frac"] - EPS) / EPS + min(r["n_violations"], 300) / 60.0 + max(0.0, r["Tmax_C"] - PAR.T_safe_C) / 5.0
    f = np.array([(r["Tmax_C"] - SCEN.T_amb_C) / 30.0, r["E_cool_kWh"] * 1000.0 / 250.0,
                  r["loss_pct_per_100km"] / REF["loss_pct_per_100km"], fP])
    return f, r


def fast_sort(F):
    n = len(F)
    S = [[] for _ in range(n)]; cnt = np.zeros(n, int); fronts = [[]]
    for p in range(n):
        for q in range(n):
            if np.all(F[p] <= F[q]) and np.any(F[p] < F[q]):
                S[p].append(q)
            elif np.all(F[q] <= F[p]) and np.any(F[q] < F[p]):
                cnt[p] += 1
        if cnt[p] == 0:
            fronts[0].append(p)
    i = 0
    while fronts[i]:
        nxt = []
        for p in fronts[i]:
            for q in S[p]:
                cnt[q] -= 1
                if cnt[q] == 0:
                    nxt.append(q)
        i += 1; fronts.append(nxt)
    return fronts[:-1]


def crowd(F, idx):
    d = np.zeros(len(idx))
    for m in range(F.shape[1]):
        o = np.argsort(F[idx, m]); d[o[0]] = d[o[-1]] = np.inf
        span = F[idx[o[-1]], m] - F[idx[o[0]], m]
        if span <= 0:
            continue
        for a in range(1, len(idx) - 1):
            d[o[a]] += (F[idx[o[a + 1]], m] - F[idx[o[a - 1]], m]) / span
    return d


def sbx_poly(p1, p2, rng, eta_c=15, eta_m=20, pm=1 / 7):
    c1, c2 = p1.copy(), p2.copy()
    for i in range(len(p1)):
        if rng.random() < 0.9:
            u = rng.random()
            b = (2 * u) ** (1 / (eta_c + 1)) if u <= 0.5 else (1 / (2 * (1 - u))) ** (1 / (eta_c + 1))
            c1[i] = 0.5 * ((1 + b) * p1[i] + (1 - b) * p2[i]); c2[i] = 0.5 * ((1 - b) * p1[i] + (1 + b) * p2[i])
    for c in (c1, c2):
        for i in range(len(c)):
            if rng.random() < pm:
                u = rng.random(); d = (2 * u) ** (1 / (eta_m + 1)) - 1 if u < 0.5 else 1 - (2 * (1 - u)) ** (1 / (eta_m + 1))
                c[i] += d * (UB[i] - LB[i])
    return np.clip(c1, LB, UB), np.clip(c2, LB, UB)


def hv_mc(F, ref, n=100000, seed=4242):
    rng = np.random.default_rng(seed)
    lo = F.min(0)
    S = lo + rng.random((n, F.shape[1])) * (ref - lo)
    dom = np.zeros(n, bool)
    for f in F:
        dom |= np.all(S >= f, axis=1)
    return np.prod(ref - lo) * dom.mean()


def main(npop=48, gens=40, seed=42):
    rng = np.random.default_rng(seed)
    X = LB + rng.random((npop, len(LB))) * (UB - LB)
    F = np.array([objs(x)[0] for x in X]); nfe = npop
    for g in range(gens):
        fr = fast_sort(F); rank = np.zeros(npop, int); cd = np.zeros(npop)
        for r_, f in enumerate(fr):
            rank[f] = r_; cd[f] = crowd(F, np.array(f))
        def tour():
            a, b = rng.integers(0, npop, 2)
            return a if (rank[a] < rank[b] or (rank[a] == rank[b] and cd[a] > cd[b])) else b
        ch = []
        while len(ch) < npop:
            c1, c2 = sbx_poly(X[tour()], X[tour()], rng); ch += [c1, c2]
        Xc = np.array(ch[:npop]); Fc = np.array([objs(x)[0] for x in Xc]); nfe += npop
        XA, FA = np.vstack([X, Xc]), np.vstack([F, Fc])
        sel = []
        for f in fast_sort(FA):
            if len(sel) + len(f) <= npop:
                sel += f
            else:
                d = crowd(FA, np.array(f)); sel += [f[i] for i in np.argsort(-d)[:npop - len(sel)]]
                break
        X, F = XA[sel], FA[sel]
    f0 = fast_sort(F)[0]
    rows = []
    for i in f0:
        f, r = objs(X[i])
        rows.append(dict(id=i, **dict(zip(NAMES, X[i])), fT=f[0], fCool=f[1], fAge=f[2], fPerf=f[3], Tmax=r["Tmax_C"],
                         Tend=r["T_end_C"], coolWh=1000 * r["E_cool_kWh"], loss100=r["loss_pct_per_100km"],
                         shortfall_pct=100 * r["shortfall_frac"], viol=r["n_violations"], kWh100=r["kWh_per_100km"]))
    D = pd.DataFrame(rows)
    D.to_csv(OUT / "pareto_front.csv", index=False)
    Fm = D[["fT", "fCool", "fAge", "fPerf"]].to_numpy()
    ref = 1.10 * Fm.max(0) + 1e-12
    hv = hv_mc(Fm, ref)
    feas = D[(D.fPerf == 0)]
    Ff = feas[["fT", "fCool", "fAge"]].to_numpy()          # diz noktası: ε-uygun çözümler arasında, 3 amaç
    nrm = (Ff - Ff.min(0)) / np.maximum(Ff.max(0) - Ff.min(0), 1e-12)
    knee = int(D.index.get_loc(feas.index[int(np.argmin(np.sqrt((nrm ** 2).sum(1))))]))
    sel = {"knee_feasible": knee, "min_T": int(np.argmin(Fm[:, 0])), "min_cool": int(np.argmin(Fm[:, 1])),
           "min_age": int(np.argmin(Fm[:, 2])), "min_perf": int(np.argmin(Fm[:, 3]))}
    comp = D.iloc[list(sel.values())].copy(); comp.insert(0, "selection", list(sel.keys()))
    comp.to_csv(OUT / "pareto_compromise.csv", index=False)
    pd.DataFrame([dict(n_front=len(D), npop=npop, gens=gens, nfe=nfe, hv=hv, n_feasible=len(feas),
                       med_T=D.Tmax.median(), med_cool=D.coolWh.median(), med_loss=D.loss100.median())]).to_csv(OUT / "pareto_summary.csv", index=False)
    print(comp.round(3).to_string()); print("HV", hv, "n", len(D), "nfe", nfe, "feasible", len(feas))


if __name__ == "__main__":
    main()

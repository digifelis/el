"""Tablo IX, Şekil 8, Şekil 10-11, Tablo XIV-A/B, Tablo XV girdileri: 6 algoritma x 30 koşu, 1008 değerlendirme."""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from algos import ALGOS
from objective import make_objective, LB, UB, NAMES, vec_to_ctrl, terms, SCEN, PAR, NOMINAL
from evbms import simulate

OUT = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
OUT.mkdir(exist_ok=True)
NPOP, N_RUN = 24, 30


def main():
    rows, vecs, convs = [], [], []
    for name, fn in ALGOS.items():
        itmax = 40 if name == "Hybrid SFO-GOA" else 41
        for run in range(N_RUN):
            cnt = [0]
            J, ref = make_objective(counter=cnt)
            rng = np.random.default_rng(1000 + run)
            t = time.time()
            X, F, hist = fn(J, LB, UB, NPOP, itmax, rng)
            b = int(np.argmin(F)); x = X[b]
            r = simulate(vec_to_ctrl(x), SCEN, PAR)
            fT, fE, fA, fP = terms(r, ref, SCEN.T_amb_C)
            rows.append(dict(algo=name, run=run, J=F[b], nfe=cnt[0], time_s=time.time() - t, fT=fT, fE=fE, fAge=fA, fPerf=fP,
                             Tmax=r["Tmax_C"], shortfall_pct=100 * r["shortfall_frac"], kWh100=r["kWh_per_100km"],
                             loss100=r["loss_pct_per_100km"]))
            vecs.append(dict(algo=name, run=run, **dict(zip(NAMES, x))))
            for k, h in enumerate(hist):
                convs.append(dict(algo=name, run=run, it=k + 1, best=h))
        print(name, "tamam", flush=True)
    pd.DataFrame(rows).to_csv(OUT / "bench_runs.csv", index=False)
    pd.DataFrame(vecs).to_csv(OUT / "bench_vectors.csv", index=False)
    pd.DataFrame(convs).to_csv(OUT / "bench_conv.csv", index=False)
    d = pd.DataFrame(rows)
    print(d.groupby("algo").J.agg(["mean", "std", "median", "min", "max"]).round(4))
    print(d.groupby("algo").nfe.mean())


if __name__ == "__main__":
    main()

"""Hakem 1 (devam): SoH bilgisinin gerçek değeri = tek parametre setinin farklı SoH durumlarına uyarlanması.
Her çevrim (25 °C, SoC0 0,9, sıvı soğutma) için SoH in {1,0.9,0.8,0.7,0.6}. Tek (c_dis,c_ch,[g]) seti tüm SoH'lerde eps=%2 kısıtını sağlamalı;
hedef: SoH üzerinden ortalama göreli yaşlanma. unaware (g=0) ile aware_S (g serbest) ince ızgarada karşılaştırılır.
Çıktı: sonuclar/v3/rev_soh_tek_set.csv"""
import itertools, sys
from pathlib import Path
import numpy as np, pandas as pd
K = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(K))
from evbms import Controller, Params, Scenario, simulate
from faz3c_pareto import ref, short_phys

OUT = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
SOH = [1.0, 0.9, 0.8, 0.7, 0.6]
CD = np.round(np.arange(0.2, 4.01, 0.1), 2)
CC = [0.1, 0.3, 0.6, 1.0]
GS = [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
EPS = 2.0
rows = []
for cyc in ("WLTP", "UDDS", "US06"):
    suite = [(f"{cyc}_25C_SoH{int(s*100)}_tek", Scenario(cycle=cyc, T_amb_C=25.0, SoH0=s, soc0=0.9), Params()) for s in SOH]
    refs = [(ref(n, sc, p), short_phys(n, sc, p)) for n, sc, p in suite]
    for mode, gs in (("unaware", [0.0]), ("aware_S", GS)):
        best = (np.inf, None)
        for cd, cc, g in itertools.product(CD, CC, gs):
            los, ok = [], True
            for (n, sc, p), (f, sp) in zip(suite, refs):
                r = simulate(Controller(mode=mode, c_dis=cd, c_ch=cc, g_soh=g, T_der=38.0, T_set=25.0, Kp=0.05, Ki=0.005), sc, p)
                if 100 * max(0.0, r["shortfall_frac"] - sp) > EPS:
                    ok = False; break
                los.append(r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12))
            if ok and np.mean(los) < best[0]:
                best = (np.mean(los), dict(c_dis=cd, c_ch=cc, g=g, per_soh=[round(x, 4) for x in los]))
        rows.append(dict(cycle=cyc, mode=mode, mean_loss=best[0], **(best[1] or {})))
        print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv(OUT / "rev_soh_tek_set.csv", index=False)

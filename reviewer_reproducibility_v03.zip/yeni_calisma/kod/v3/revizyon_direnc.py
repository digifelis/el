"""Hakem 2: toplam direnç hatası R̂/R taraması (k_R,nom'dan türetilir). Yapılandırma: doğru bilgiyle bulunan en iyi aware_RS (eps=%2, pencere dışı 0 varsa o).
Çıktı: sonuclar/v3/rev_direnc_orani.csv"""
import sys
from pathlib import Path
import numpy as np, pandas as pd
K = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(K))
from evbms import Controller, Scenario, simulate
from faz3c_pareto import TRAIN, TEST, ref, short_phys
from optimize import OUT as OLD
import dataclasses

OUT = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
G = pd.concat([pd.read_csv(OLD / "faz3d_grid.csv"), pd.read_csv(OLD / "faz6_grid.csv")])
NAMES = ["WLTP_-10C_SoH60", "WLTP_0C_SoH75_lowSoC", "WLTP_5C_SoH80", "US06_0C_SoH70_lowSoC"]
RATIOS = [0.5, 0.7, 0.8, 0.9, 0.92, 0.94, 0.96, 0.98, 1.0, 1.05, 1.1, 1.25, 1.5, 2.0]
rows = []
for name, scen, par in TRAIN + TEST:
    if name not in NAMES:
        continue
    f, sp = ref(name, scen, par), short_phys(name, scen, par)
    g = G[(G.scenario == name) & (G["mode"] == "aware_RS") & (G.short_ind <= 2.0)]
    g0 = g[g.outwindow_s == 0]
    if len(g0):
        b, tag = g0.loc[g0.loss_rel.idxmin()], "window-free solution"
    else:
        gg = G[(G.scenario == name) & (G["mode"] == "aware_RS")]
        b, tag = gg.loc[gg.outwindow_s.idxmin()], "min-window config (no eps-feasible window-free)"
    S, kR = scen.SoH0, 1.5
    for rho in RATIOS:
        kn = (rho * (1 + kR * (1 - S)) - 1) / (1 - S)
        sc = dataclasses.replace(scen, kR_nom=kn)
        r = simulate(Controller(mode="aware_RS", c_dis=b.c_dis, c_ch=b.c_ch, g_soh=b.g, T_der=b.T_der, T_set=25.0, Kp=0.05, Ki=0.005), sc, par)
        rows.append(dict(scenario=name, config=tag, c_dis=b.c_dis, c_ch=b.c_ch, g=b.g, T_der=b.T_der, ratio=rho, kR_nom=kn, window_s=r["n_violations"], Vmin=r["Vcell_min_V"],
                         short_ind=100 * max(0.0, r["shortfall_frac"] - sp),
                         loss_rel=r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12)))
D = pd.DataFrame(rows); D.to_csv(OUT / "rev_direnc_orani.csv", index=False)
pd.set_option("display.width", 250)
print(D.round(3).to_string(index=False))

"""Tablo VI ve Şekil 4-7: Lu veri kümesi #3 ve #5 (hücre bazında, normalize SoH; havuzlama yok)."""
from pathlib import Path
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[3]
D = ROOT / "Battery Degradation Datasets (Two Types of Lithium-ion Batteries)"
OUT = Path(__file__).resolve().parents[2] / "sekiller" / "v3"
RES = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "savefig.dpi": 300})
DS = [("Dataset#3.xlsx", "Dataset #3", "NCR18650BD, 20 °C", "#1f77b4"), ("Dataset#5.xlsx", "Dataset #5", "IFP20100140A, 45 °C", "#d62728")]

rows, curves = [], {}
for fn, name, desc, col in DS:
    xl = pd.ExcelFile(D / fn)
    for sh in xl.sheet_names:
        raw = pd.read_excel(D / fn, sheet_name=sh, header=None)
        volt = np.array([float(str(v).replace("V", "")) for v in raw.iloc[1, 1:].to_numpy()])
        M = raw.iloc[2:, 1:].apply(pd.to_numeric, errors="coerce").to_numpy()
        q = M[:, -1]; ok = np.isfinite(q) & (q > 0)
        Mq, qq = M[ok], q[ok]
        soh = 100 * qq / qq[0]
        curves[(name, sh)] = (volt, Mq, soh, qq)
        rows.append(dict(dataset=name, cell=sh, cycles=len(qq), Q_first=qq[0], Q_last=qq[-1], SoH_final=soh[-1], SoH_min=soh.min(),
                         V_lo=volt[0], V_hi=volt[-1]))
T = pd.DataFrame(rows); T.to_csv(RES / "tab6_lu.csv", index=False)
print(T.round(3).to_string(index=False))
for name, g in T.groupby("dataset"):
    print(name, "SoH final mean±sd", round(g.SoH_final.mean(), 2), round(g.SoH_final.std(), 2), "Q first/last mean", round(g.Q_first.mean(), 3), round(g.Q_last.mean(), 3))

# Fig 4 SoH trajectories
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True)
for a, (fn, name, desc, col) in zip(ax, DS):
    for sh, ls in zip(("Cell01", "Cell02", "Cell03"), ("-", "--", ":")):
        v, M, soh, q = curves[(name, sh)]
        a.plot(np.arange(1, len(soh) + 1), soh, ls, color=col, label=sh)
    a.set_title(f"{name} ({desc})"); a.set_xlabel("Cycle"); a.legend(frameon=False)
ax[0].set_ylabel("Capacity-based SoH (%)")
fig.tight_layout(); fig.savefig(OUT / "fig04_soh.png"); fig.savefig(OUT / "fig04_soh.pdf"); plt.close(fig)

# Fig 5 first vs final capacity
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
for a, (fn, name, desc, col) in zip(ax, DS):
    g = T[T.dataset == name]; x = np.arange(len(g))
    a.bar(x - 0.18, g.Q_first, 0.36, color=col, alpha=0.9, label="First cycle")
    a.bar(x + 0.18, g.Q_last, 0.36, color=col, alpha=0.45, hatch="//", label="Last cycle")
    a.set_xticks(x); a.set_xticklabels(g.cell); a.set_ylabel("Capacity (Ah)"); a.set_title(f"{name}"); a.legend(frameon=False, loc="lower right")
fig.tight_layout(); fig.savefig(OUT / "fig05_cap.png"); fig.savefig(OUT / "fig05_cap.pdf"); plt.close(fig)

# Fig 6 capacity-voltage profiles
fig, ax = plt.subplots(2, 3, figsize=(7.2, 4.4))
for r_, (fn, name, desc, col) in enumerate(DS):
    for c_, sh in enumerate(("Cell01", "Cell02", "Cell03")):
        v, M, soh, q = curves[(name, sh)]; n = len(M)
        for idx, lab, al in ((0, "Early", 1.0), (n // 2, "Mid", 0.65), (n - 1, "Late", 0.35)):
            ax[r_, c_].plot(M[idx], v, color=col, alpha=al, label=f"{lab} (cycle {idx + 1})")
        ax[r_, c_].set_title(f"{name}, {sh}", fontsize=8)
        if c_ == 0: ax[r_, c_].set_ylabel("Voltage (V)")
        if r_ == 1: ax[r_, c_].set_xlabel("Cumulative charge (Ah)")
        ax[r_, c_].legend(frameon=False, fontsize=6)
fig.tight_layout(); fig.savefig(OUT / "fig06_cv.png"); fig.savefig(OUT / "fig06_cv.pdf"); plt.close(fig)

# Fig 7 final SoH distribution
fig, ax = plt.subplots(figsize=(3.6, 2.9))
for i, (fn, name, desc, col) in enumerate(DS):
    g = T[T.dataset == name].SoH_final.to_numpy()
    ax.boxplot(g, positions=[i], widths=0.4, showmeans=True, medianprops=dict(color="k"))
    ax.scatter(np.full(len(g), i) + np.linspace(-0.08, 0.08, len(g)), g, color=col, zorder=3, s=18)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Dataset #3", "Dataset #5"]); ax.set_ylabel("Final SoH (%)")
fig.tight_layout(); fig.savefig(OUT / "fig07_final.png"); fig.savefig(OUT / "fig07_final.pdf"); plt.close(fig)

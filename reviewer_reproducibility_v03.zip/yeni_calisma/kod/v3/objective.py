"""Skaler ağırlıklı amaç J (WLTP, 25 °C, SoH 0,80 referans senaryosu) ve karar vektörü tanımı.

J = w_T f_T + w_E f_E + w_age f_age + w_perf f_perf; her terim aynı senaryodaki sabit nominal limitleyiciye (c_dis=2, c_ch=1) göre normalize.
f_T   = (T_max - T_amb) / (T_max,ref - T_amb)
f_E   = kWh/100 km / kWh/100 km_ref
f_age = kayıp vekili/km / kayıp vekili/km_ref
f_perf= max(0, s-eps)/eps + n_ihlal/60 + max(0, T_max - T_safe)/5   (s: güç açığı kesri, eps = 0,02)
"""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from evbms import Controller, Params, Scenario, simulate

W = dict(T=0.20, E=0.25, age=0.35, perf=0.20)
EPS = 0.02
LB = np.array([0.5, 0.2, 0.0, 35.0, 25.0, 0.01, -4.0])
UB = np.array([4.0, 2.0, 2.0, 55.0, 45.0, 1.0, -2.0])
NAMES = ["c_dis", "c_ch", "g_SoH", "T_der", "T_set", "Kp", "log10Ki"]
NOMINAL = Controller(mode="fixed", c_dis=2.0, c_ch=1.0)
SCEN = Scenario(cycle="WLTP", T_amb_C=25.0, SoH0=0.8, soc0=0.9)
PAR = Params()


def vec_to_ctrl(x, mode="aware_RS"):
    return Controller(mode=mode, c_dis=x[0], c_ch=x[1], g_soh=x[2], T_der=x[3], T_set=x[4], Kp=x[5], Ki=10 ** x[6])


def terms(r, ref, T_amb, par=PAR):
    fT = (r["Tmax_C"] - T_amb + 0.5) / (ref["Tmax_C"] - T_amb + 0.5)
    fE = r["kWh_per_100km"] / ref["kWh_per_100km"]
    fA = r["loss_pct_per_100km"] / max(ref["loss_pct_per_100km"], 1e-12)
    fP = max(0.0, r["shortfall_frac"] - EPS) / EPS + min(r["n_violations"], 300) / 60.0 + max(0.0, r["Tmax_C"] - par.T_safe_C) / 5.0
    return fT, fE, fA, fP


def make_objective(scen=SCEN, par=PAR, mode="aware_RS", counter=None):
    ref = simulate(NOMINAL, scen, par)

    def J(x):
        if counter is not None:
            counter[0] += 1
        r = simulate(vec_to_ctrl(x, mode), scen, par)
        fT, fE, fA, fP = terms(r, ref, scen.T_amb_C, par)
        return W["T"] * fT + W["E"] * fE + W["age"] * fA + W["perf"] * fP
    return J, ref

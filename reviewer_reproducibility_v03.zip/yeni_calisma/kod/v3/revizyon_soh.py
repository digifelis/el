"""Hakem 1: SoH ölçeklemesi, etkin C-rate parametresine indirgenebilir mi?
(a) Her senaryoda ızgaradaki en iyi aware_S yapılandırmasını eşdeğer unaware (c*s) ile yeniden koştur.
(b) Aynı etkin aralığı kapsayan ince bir unaware ızgarasıyla oracle'ı yeniden hesapla.
Çıktı: sonuclar/v3/rev_soh_esdeger.csv, rev_soh_ince.csv"""
import itertools, sys
from pathlib import Path
import numpy as np, pandas as pd
K = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(K))
from evbms import Controller, simulate
from faz3c_pareto import TRAIN, TEST, ref, short_phys
from optimize import OUT as OLD

OUT = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
SUITE = [(n, s, p) for n, s, p in TRAIN + TEST]
G = pd.concat([pd.read_csv(OLD / "faz3d_grid.csv"), pd.read_csv(OLD / "faz6_grid.csv")])
CD = np.round(np.arange(0.2, 4.01, 0.1), 2)
CC = [0.1, 0.2, 0.3, 0.45, 0.6, 0.8, 1.0, 1.25, 1.5]
TD = [38.0, 45.0]
EPS = 2.0


def ev(ctrl, scen, par, f, sp):
    r = simulate(ctrl, scen, par)
    return dict(loss_rel=r["loss_pct_per_100km"] / max(f["loss_pct_per_100km"], 1e-12),
                short_ind=100 * max(0.0, r["shortfall_frac"] - sp), win=r["n_violations"])


eq, fine = [], []
for name, scen, par in SUITE:
    f, sp = ref(name, scen, par), short_phys(name, scen, par)
    g = G[(G.scenario == name) & (G["mode"] == "aware_S") & (G.short_ind <= EPS)]
    old_u = G[(G.scenario == name) & (G["mode"] == "unaware") & (G.short_ind <= EPS)]
    if len(g):
        b = g.loc[g.loss_rel.idxmin()]
        s = 1 - b.g * (1 - scen.SoH0)
        a = ev(Controller(mode="aware_S", c_dis=b.c_dis, c_ch=b.c_ch, g_soh=b.g, T_der=b.T_der, T_set=25.0, Kp=0.05, Ki=0.005), scen, par, f, sp)
        u = ev(Controller(mode="unaware", c_dis=b.c_dis * s, c_ch=b.c_ch * s, g_soh=0.0, T_der=b.T_der, T_set=25.0, Kp=0.05, Ki=0.005), scen, par, f, sp)
        eq.append(dict(scenario=name, s_SoH=s, c_dis_eff=b.c_dis * s, c_ch_eff=b.c_ch * s, aware_loss=a["loss_rel"], equiv_unaware_loss=u["loss_rel"],
                       diff=a["loss_rel"] - u["loss_rel"], aware_short=a["short_ind"], equiv_short=u["short_ind"], aware_win=a["win"], equiv_win=u["win"]))
    best = (np.inf, None)
    for cd, cc, td in itertools.product(CD, CC, TD):
        r = ev(Controller(mode="unaware", c_dis=cd, c_ch=cc, g_soh=0.0, T_der=td, T_set=25.0, Kp=0.05, Ki=0.005), scen, par, f, sp)
        if r["short_ind"] <= EPS and r["loss_rel"] < best[0]:
            best = (r["loss_rel"], dict(c_dis=cd, c_ch=cc, T_der=td, win=r["win"]))
    fine.append(dict(scenario=name, unaware_coarse=old_u.loss_rel.min() if len(old_u) else np.nan,
                     aware_S_coarse=g.loss_rel.min() if len(g) else np.nan,
                     unaware_fine=best[0] if best[1] else np.nan, **(best[1] or {})))
    print(name, flush=True)
E = pd.DataFrame(eq); F = pd.DataFrame(fine)
E.to_csv(OUT / "rev_soh_esdeger.csv", index=False); F.to_csv(OUT / "rev_soh_ince.csv", index=False)
F["gain_coarse"] = 100 * (F.unaware_coarse - F.aware_S_coarse)
F["gain_fine"] = 100 * (F.unaware_fine - F.aware_S_coarse)
pd.set_option("display.width", 250)
print(E.round(4).to_string(index=False)); print(F.round(3).to_string(index=False))
print("coarse gain median/max", F.gain_coarse.median(), F.gain_coarse.max(), "| fine-unaware gain median/max", F.gain_fine.median(), F.gain_fine.max())

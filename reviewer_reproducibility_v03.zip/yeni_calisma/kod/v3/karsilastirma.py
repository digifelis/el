"""Tablo VII (kontrol stratejisi karşılaştırması), Tablo VIII (rejen ablasyonu), Tablo X (duyarlılık/ablasyon).
Her ayarlı mod: hibrit SFO-GOA, 24 aday, 1008 NFE, 5 yeniden başlatmanın en iyisi (aynı bütçe, aynı amaç J)."""
import sys, dataclasses
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import objective as ob
from algos import hybrid
from evbms import Controller, Params, Scenario, simulate

OUT = Path(__file__).resolve().parents[2] / "sonuclar" / "v3"
RESTARTS = 5


def bounds(mode):
    lb, ub = ob.LB.copy(), ob.UB.copy()
    if mode == "mpc":
        lb[2], ub[2] = 1.0, 60.0
        lb[0], ub[0] = 1.0, 4.0
    return lb, ub


def tune(mode, scen, par, w=None, lb=None, ub=None, seed0=0):
    saved = dict(ob.W)
    if w:
        ob.W.update(w)
    try:
        J, ref = ob.make_objective(scen, par, mode)
        b_lb, b_ub = bounds(mode)
        lb = b_lb if lb is None else lb; ub = b_ub if ub is None else ub
        best = (1e9, None)
        for s in range(RESTARTS):
            X, F, _ = hybrid(J, lb, ub, 24, 40, np.random.default_rng(seed0 + s))
            i = int(np.argmin(F))
            if F[i] < best[0]:
                best = (F[i], X[i].copy())
        return best[1], best[0], ref
    finally:
        ob.W.clear(); ob.W.update(saved)


def row(tag, mode, x, scen, par, ref, **extra):
    ctrl = ob.NOMINAL if mode == "fixed" else ob.vec_to_ctrl(x, mode)
    r = simulate(ctrl, scen, par)
    fT, fE, fA, fP = ob.terms(r, ref, scen.T_amb_C, par)
    J = sum(ob.W[k] * v for k, v in zip(("T", "E", "age", "perf"), (fT, fE, fA, fP)))
    return dict(tag=tag, mode=mode, J=J, fT=fT, fE=fE, fAge=fA, fPerf=fP, Tmax=r["Tmax_C"], loss100=r["loss_pct_per_100km"],
                loss_rel=r["loss_pct_per_100km"] / max(ref["loss_pct_per_100km"], 1e-12),
                shortfall_pct=100 * r["shortfall_frac"], viol_s=r["n_violations"], regen_Wh=1000 * r["E_regen_kWh"],
                coolWh=1000 * r["E_cool_kWh"], kWh100=r["kWh_per_100km"], Vmin=r["Vcell_min_V"], **extra)


def table7():
    rows = []
    for cyc in ("WLTP", "UDDS", "US06"):
        scen = Scenario(cycle=cyc, T_amb_C=25.0, SoH0=0.8, soc0=0.9)
        ref = simulate(ob.NOMINAL, scen, ob.PAR)
        rows.append(row(cyc, "fixed", None, scen, ob.PAR, ref, cycle=cyc))
        for mode in ("unaware", "aware_S", "aware_RS", "mpc"):
            x, J, _ = tune(mode, scen, ob.PAR)
            rows.append(row(cyc, mode, x, scen, ob.PAR, ref, cycle=cyc, **dict(zip(ob.NAMES, x))))
            print(cyc, mode, round(J, 4), flush=True)
    pd.DataFrame(rows).to_csv(OUT / "tab7_kontrol.csv", index=False)


def table8():
    scen = Scenario(cycle="UDDS", T_amb_C=25.0, SoH0=0.8, soc0=0.9)
    rows = []
    for tag, phi, fix_ch in (("disabled", 0.0, False), ("fixed", 0.7, True), ("optimized", 0.7, False)):
        par = dataclasses.replace(ob.PAR, regen_share=phi)
        lb, ub = ob.LB.copy(), ob.UB.copy()
        if fix_ch:
            lb[1] = ub[1] = 1.0
        ref = simulate(ob.NOMINAL, scen, ob.PAR)
        x, J, _ = tune("aware_RS", scen, par, lb=lb, ub=ub)
        rows.append(row(tag, "aware_RS", x, scen, par, ref, **dict(zip(ob.NAMES, x))))
        print("regen", tag, round(J, 4), flush=True)
    pd.DataFrame(rows).to_csv(OUT / "tab8_rejen.csv", index=False)


def table10():
    rows = []
    base_scen = Scenario(cycle="WLTP", T_amb_C=25.0, SoH0=0.8, soc0=0.9)

    def run(check, level, scen=base_scen, par=ob.PAR, mode="aware_RS", w=None, lb=None, ub=None):
        ref = simulate(ob.NOMINAL, scen, par)
        x, J, _ = tune(mode, scen, par, w=w, lb=lb, ub=ub)
        saved = dict(ob.W)
        if w:
            ob.W.update(w)
        d = row(check, mode, x, scen, par, ref, level=level, **dict(zip(ob.NAMES, x)))
        ob.W.clear(); ob.W.update(saved)
        rows.append(d); print(check, level, round(d["J"], 4), flush=True)

    for T in (10, 25, 45):
        run("ambient", f"{T} °C", scen=dataclasses.replace(base_scen, T_amb_C=float(T)))
    for s in (1.0, 0.9, 0.8, 0.7):
        run("SoH", f"{int(s*100)} %", scen=dataclasses.replace(base_scen, SoH0=s))
    for f in (0.8, 1.2):
        run("C_th", f"x{f}", par=dataclasses.replace(ob.PAR, C_cell_J_K=ob.PAR.C_cell_J_K * f))
        run("UA_cool", f"x{f}", par=dataclasses.replace(ob.PAR, UA_cool_pack_W_K=ob.PAR.UA_cool_pack_W_K * f))
    for kr in (0.5, 3.0):
        run("k_R,true", f"{kr}", par=dataclasses.replace(ob.PAR, kR_true=kr))
    lb, ub = ob.LB.copy(), ob.UB.copy(); lb[0] = ub[0] = 0.5
    run("fixed c_dis", "0.5 C", lb=lb, ub=ub)
    lb, ub = ob.LB.copy(), ob.UB.copy(); lb[0] = ub[0] = 3.0
    run("fixed c_dis", "3.0 C", lb=lb, ub=ub)
    run("no performance term", "w_perf = 0", w=dict(perf=0.0, T=0.25, E=0.3, age=0.45))
    lb, ub = ob.LB.copy(), ob.UB.copy(); lb[2] = ub[2] = 0.0
    run("no SoH gain", "g = 0", lb=lb, ub=ub)
    lb, ub = ob.LB.copy(), ob.UB.copy(); lb[3] = ub[3] = 55.0
    run("no thermal derating", "T_der = 55 °C", lb=lb, ub=ub)
    pd.DataFrame(rows).to_csv(OUT / "tab10_duyarlilik.csv", index=False)


if __name__ == "__main__":
    which = sys.argv[1:] or ["7", "8", "10"]
    if "7" in which: table7()
    if "8" in which: table8()
    if "10" in which: table10()

"""Eşit değerlendirme bütçeli metasezgisel algoritmalar (SFO, GOA, hibrit SFO-GOA, GWO, PSO, GA).

Güncelleme kuralları, önceki çalışmanın (matlab_simulink_project/*_optimize.m) kurallarıyla aynıdır;
yalnızca Python'a taşınmıştır. Hepsi: nPop adaylı, maxIt yinelemeli, açgözlü yer değiştirme (GA hariç: elitizm).
"""
import numpy as np


def _clip(X, lb, ub):
    return np.minimum(np.maximum(X, lb), ub)


def _init(f, lb, ub, n, rng):
    X = lb + rng.random((n, len(lb))) * (ub - lb)
    F = np.array([f(x) for x in X])
    return X, F


def sfo(f, lb, ub, n, it_max, rng, X=None, F=None, it_offset=0, it_total=None):
    if X is None:
        X, F = _init(f, lb, ub, n, rng)
    tot = it_total or it_max
    hist = []
    for it in range(it_max):
        expl = 1.0 - (it + it_offset) / tot
        b = np.argmin(F)
        best = X[b].copy()
        for i in range(n):
            if rng.random() < 0.55:
                step = (2 * rng.random(len(lb)) - 1) * expl * (ub - lb) * 0.18
                xn = X[i] + step
            else:
                xn = X[i] + rng.random(len(lb)) * (best - X[i])
            xn = _clip(xn, lb, ub)
            fn = f(xn)
            if fn < F[i]:
                X[i], F[i] = xn, fn
        hist.append(F.min())
    return X, F, hist


def goa(f, lb, ub, n, it_max, rng):
    X, F = _init(f, lb, ub, n, rng)
    hist = []
    for it in range(it_max):
        b = np.argmin(F)
        best = X[b].copy()
        gain = 2.0 * (1.0 - it / it_max)
        for i in range(n):
            press = rng.random(len(lb)) * np.sign(X[i] - best)
            sprint = gain * rng.standard_normal(len(lb)) * (ub - lb) * 0.08
            attr = rng.random(len(lb)) * (best - X[i]) * 0.65
            xn = _clip(X[i] + attr - press * sprint, lb, ub)
            fn = f(xn)
            if fn < F[i]:
                X[i], F[i] = xn, fn
        hist.append(F.min())
    return X, F, hist


def hybrid(f, lb, ub, n, it_max, rng):
    h = it_max // 2
    X, F, h1 = sfo(f, lb, ub, n, h, rng)
    b = np.argmin(F)
    best = X[b].copy()
    X = _clip(best + rng.standard_normal((n, len(lb))) * 0.18 * (ub - lb) / 2.0, lb, ub)
    X[0] = best
    F = np.array([f(x) for x in X])
    hist = list(h1)
    for it in range(h):
        b = np.argmin(F)
        bx = X[b].copy()
        for i in range(n):
            xn = X[i] + 0.75 * rng.random(len(lb)) * (bx - X[i]) \
                + 1.5 * (1 - it / h) * rng.standard_normal(len(lb)) * (ub - lb) * 0.045
            xn = _clip(xn, lb, ub)
            fn = f(xn)
            if fn < F[i]:
                X[i], F[i] = xn, fn
        hist.append(F.min())
    return X, F, hist


def gwo(f, lb, ub, n, it_max, rng):
    X, F = _init(f, lb, ub, n, rng)
    hist = []
    for it in range(it_max):
        idx = np.argsort(F)[:3]
        lead = X[idx].copy()
        a = 2.0 - 2.0 * it / it_max
        for i in range(n):
            acc = np.zeros(len(lb))
            for L in lead:
                A = 2 * a * rng.random(len(lb)) - a
                Cc = 2 * rng.random(len(lb))
                acc += L - A * np.abs(Cc * L - X[i])
            xn = _clip(acc / 3.0, lb, ub)
            fn = f(xn)
            if fn < F[i]:
                X[i], F[i] = xn, fn
        hist.append(F.min())
    return X, F, hist


def pso(f, lb, ub, n, it_max, rng):
    X, F = _init(f, lb, ub, n, rng)
    V = np.zeros_like(X)
    PB, PF = X.copy(), F.copy()
    hist = []
    for it in range(it_max):
        g = PB[np.argmin(PF)].copy()
        for i in range(n):
            V[i] = 0.72 * V[i] + 1.49 * rng.random(len(lb)) * (PB[i] - X[i]) + 1.49 * rng.random(len(lb)) * (g - X[i])
            X[i] = _clip(X[i] + V[i], lb, ub)
            F[i] = f(X[i])
            if F[i] < PF[i]:
                PB[i], PF[i] = X[i].copy(), F[i]
        hist.append(PF.min())
    return PB, PF, hist


def ga(f, lb, ub, n, it_max, rng):
    X, F = _init(f, lb, ub, n, rng)
    hist = []
    for it in range(it_max):
        order = np.argsort(F)
        Xn = [X[order[0]].copy()]
        Fn = [F[order[0]]]
        while len(Xn) < n:
            def tour():
                a, b = rng.integers(0, n, 2)
                return X[a] if F[a] < F[b] else X[b]
            p1, p2 = tour(), tour()
            al = rng.random()
            c = al * p1 + (1 - al) * p2
            if rng.random() < 0.15:
                c = c + 0.08 * (ub - lb) * rng.standard_normal(len(lb))
            c = _clip(c, lb, ub)
            Xn.append(c)
            Fn.append(f(c))
        X, F = np.array(Xn), np.array(Fn)
        hist.append(F.min())
    return X, F, hist


ALGOS = {"SFO": sfo, "GOA": goa, "Hybrid SFO-GOA": hybrid, "GWO": gwo, "PSO": pso, "GA": ga}

# Denklemler (tek kaynak: `kod/evbms.py`)

Makale denklemleri buradan alınır. Burada değişiklik yapılırsa `kod/tests/test_evbms.py` testleri güncellenmeli ve koşturulmalı.
Sembol işaretleri: akım I > 0 deşarj, I < 0 şarj/rejen. SoH kesir (0–1).

## Plant

| No | Denklem | Not |
|---|---|---|
| (R) | `R_hücre = R_ref(SoC) · exp[E_R/R_g · (1/T − 1/T_ref)] · [1 + k_R (1 − SoH)]` | R_ref: CORA IT5101, 26–28 °C kutusu. E_R ve k_R VARSAYIM (taranır). |
| (V) | `V_oc = N_s · OCV(SoC)`, `R_p = R_hücre · N_s / N_p`, `V_term = V_oc − I R_p` | OCV: CORA kapasite testi, IR düzeltmeli |
| (P) | `P_term = (V_oc − I R_p) I` ⇒ `I = [V_oc − √(V_oc² − 4 R_p P_term)] / (2 R_p)` | güç sınırlı; D<0 ise `I = V_oc/(2R_p)` |
| (S) | `SoC_{k+1} = SoC_k − I Δt / (N_p Q₀ SoH · 3600)` | |
| (W) | `P_w = (m a + m g C_rr + ½ ρ C_dA v²) v` | |
| (Q) | `P_term = P_w/η_dr + P_aux + P_cool` (P_w ≥ 0); `P_term = P_aux + P_cool + P_w φ(v) η_rg` (P_w < 0) | `φ(v) = φ_max · clip[(v−2)/3, 0, 1]` |
| (T1) | `T_{k+1} = T_k + Δt (I² R_p − Q_rem) / C_pack` | `C_pack = C_hücre N_s N_p κ`, C_hücre CORA uydurması |
| (T2) | `Q_rem = (UA₀ + UA_c u)(T − T_sink)`, `T_sink = T_amb − ΔT_chill u` | UA_c, ΔT_chill VARSAYIM |
| (T3) | `u = clip[K_p e + K_i ∫e, 0, u_max]`, `e = T − T_set`, `P_cool = P_cool,max u³` | PI, anti-windup |
| (A1) | `Δloss% = k_efc · (ΔAh_hücre / 2Q₀) · exp[E_a/R_g (1/T_ref − 1/T)] · [1 + γ max(0, C − C_ref)]` | k_efc = 0,0372 %/EFC (Lu #3, 20 °C). E_a ve γ VARSAYIM. |

## BMS (kontrol yasası)

| No | Denklem | Modlar |
|---|---|---|
| (L1) | `s_SoH = 1 − g (1 − SoH_est)` | aware_S, aware_RS (diğerlerinde 1) |
| (L2) | `d_T = clip[(T_crit − T)/(T_crit − T_der), 0, 1]` | fixed hariç |
| (L3) | `I_dis,C = c_dis · N_p Q₀ · s_SoH · d_T` | |
| (L4) | `I_ch,C = c_ch · N_p Q₀ · s_SoH · d_T · taper(SoC)`, `taper = clip[(SoC_max − SoC)/0,10, 0, 1]` | |
| (L5) | `I_dis,V = max[0, (V_oc − N_s V_min)/R̂_p]`, `I_ch,V = max[0, (N_s V_max − V_oc)/R̂_p]` | unaware, aware_S, aware_RS |
| (L6) | `I_dis,max = min(I_dis,C, I_dis,V)`, `I_ch,max = min(I_ch,C, I_ch,V)`; SoC penceresi dışında ilgili yön 0 | |
| (L7) | `I = min{I_dis,max, max[−I_ch,max, I_istek]}`, ardından fiziksel kesme sınırları | |

**R̂_p (BMS'in direnç tahmini):** `aware_RS` modunda `R(SoC,T,SoH_est)` (denklem R, k_R,nom ile), diğerlerinde taze hücre `R(SoC,T,1)`.

**Miyop baseline (mod `myopic`, B1):** `μ f_T (1 + γ(2c − 1)) = 1 − 2cK`, `c = I/(N_p Q₀)`, `K = N_p Q₀ R̂_p / V_oc`, `f_T = exp[E_a/R_g (1/T_ref − 1/T)]`; c ≤ C_ref dalında `c = (1 − μ f_T)/(2K)`. Elde edilen sınır (L3–L4) yerine geçer (s_SoH = 1), (L2), (L5), (L6) korunur. μ ≥ 1 ⇒ sınır 0.

## Modlar

| Mod | s_SoH | R tahmini | Gerilim sınırı | Termal derating |
|---|---|---|---|---|
| `fixed` | 1 | – | yok | yok |
| `unaware` | 1 | taze | var | var |
| `aware_S` (yalnız kapasite) | (L1) | taze | var | var |
| `aware_RS` (önerilen) | (L1) | R(SoH_est) | var | var |
| `myopic` (baseline) | 1 | R(SoH_est) | var | var + (B1) |

## Durum ve doğrulama notları

- Eski makaledeki (v4) Eq. (5), (8)–(12) kodla eşleşmiyordu. Burada koddaki her ifade bu tablodadır.
- VARSAYIM olarak işaretli parametreler literatürden doğrulanacak ve duyarlılık analiziyle taranacak: `k_R`, `E_R`, `E_a`, `γ`, `UA_c`, `ΔT_chill`, `P_cool,max`, `η_dr`, `η_rg`, `φ_max`, `P_aux`.
- Pakette hücre sayısı `N_p = 22`, CORA WLTP tepe C-oranına (≈ 2,5C) göre boyutlandırıldı (≈ 19,6 kWh). Büyük paketlerde hücre başına akım düşük kalır ve termal etki küçülür.

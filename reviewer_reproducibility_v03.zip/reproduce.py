"""Portable reviewer entry point. Expected results are never used as simulated outputs."""
from pathlib import Path
import argparse, hashlib, json, os, platform, shutil, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
STAGES = {
    'quick': ['tests/test_evbms.py', '@replay', 'v3/istatistik.py'],
    'benchmark': ['v3/bench.py', 'v3/istatistik.py'],
    'controllers': ['v3/karsilastirma.py'],
    'pareto': ['v3/pareto.py', 'v3/fig_pareto.py'],
    'grids': ['faz3d_cephe.py', 'faz6_miyop.py', 'faz7_cizelge.py', 'reviewer_derived.py'],
    'revisions': ['v3/revizyon_soh.py', 'v3/revizyon_soh2.py', 'v3/revizyon_direnc.py'],
    'sensitivity': ['faz4_duyarlilik.py'],
    'transfer': ['faz3c_pareto.py'],
    'lu': ['lu_soh_egrileri.py', 'v3/fig_lu.py'],
    'cora': ['cora_R_ocv.py', 'cora_ocv_capcheck.py', 'cora_gerilim_dogrulama.py', 'cora_termal_uydurma.py'],
}
EXPECTED = {
    'benchmark':['v3/'+n+'.csv' for n in ('bench_runs','bench_vectors','bench_conv','tab9_optimizer','tab14_best','tab15_pairs')],
    'controllers':['v3/'+n+'.csv' for n in ('tab7_kontrol','tab8_rejen','tab10_duyarlilik')],
    'pareto':['v3/'+n+'.csv' for n in ('pareto_front','pareto_compromise','pareto_summary')],
    'grids':[n+'.csv' for n in ('faz3d_grid','faz3d_summary','faz6_grid','faz6_summary','faz7_secilen','faz7_test','tab_scenarios','tab_oracle_eps2','fixed_cooling_matched')],
    'revisions':['v3/'+n+'.csv' for n in ('rev_soh_esdeger','rev_soh_ince','rev_soh_tek_set','rev_direnc_orani')],
    'sensitivity':['faz4_duyarlilik.csv'],
    'transfer':[n+'.csv' for n in ('faz3c_vectors','faz3c_test','faz3c_summary')],
    'lu':['lu_fade_fit.csv','v3/tab6_lu.csv'],
    'cora':[n+'.csv' for n in ('cora_gerilim_dogrulama','cora_termal_fit','cora_termal_fit_test')],
}
EXPECTED['quick']=['v3/bench_runs.csv','v3/pareto_front.csv','faz3c_test.csv',*EXPECTED['controllers'],*EXPECTED['benchmark'][3:]]

def verify():
    manifest = json.loads((ROOT/'MANIFEST.json').read_text())
    bad = []
    for name, digest in manifest.items():
        p = ROOT/name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            bad.append(name)
    print(json.dumps({'checked':len(manifest), 'mismatches':bad}, indent=2))
    return not bad

def compare(actual, expected, columns=None):
    import numpy as np
    import pandas as pd
    a, e = pd.read_csv(actual), pd.read_csv(expected)
    if columns is not None: a, e = a[columns], e[columns]
    else:
        ignored = {'time_s', 'wall_s'}
        a, e = a.drop(columns=list(ignored), errors='ignore'), e.drop(columns=list(ignored), errors='ignore')
    label=expected.relative_to(ROOT/'reference_results').as_posix() if expected.is_relative_to(ROOT/'reference_results') else expected.relative_to(ROOT).as_posix()
    result = {'file':label, 'rows':len(a), 'pass':True, 'differences':[]}
    if list(a.columns) != list(e.columns) or a.shape != e.shape:
        result['pass']=False;result['differences']=['schema/row-count mismatch'];return result
    for c in a.columns:
        if pd.api.types.is_numeric_dtype(e[c]) and pd.api.types.is_numeric_dtype(a[c]):
            ok = np.isclose(a[c], e[c], rtol=1e-7, atol=1e-9, equal_nan=True)
            if not ok.all():
                diff=np.abs(a[c].to_numpy()-e[c].to_numpy())
                finite=diff[np.isfinite(diff)]
                result['differences'].append({'column':c,'bad_rows':int((~ok).sum()), 'max_absolute_error':float(finite.max()) if len(finite) else None})
        elif not a[c].fillna('<NA>').astype(str).equals(e[c].fillna('<NA>').astype(str)):
            result['differences'].append({'column':c, 'error':'text/order mismatch'})
    result['pass'] = not result['differences']
    return result

def replay(work):
    import dataclasses
    import numpy as np
    import pandas as pd
    kod=work/'yeni_calisma/kod';sys.path[:0]=[str(kod/'v3'),str(kod)]
    import objective as ob
    from evbms import simulate, Scenario
    import karsilastirma as kc
    out=work/'yeni_calisma/sonuclar'; refdir=ROOT/'reference_results'
    checks=[]
    def save(name, rows, cols=None):
        dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
        pd.DataFrame(rows).to_csv(dest,index=False)
        checks.append(compare(dest,refdir/name,cols))
    # Re-evaluate all 180 saved vectors; recorded nfe is metadata, not a replay check.
    vectors=pd.read_csv(refdir/'v3/bench_vectors.csv'); original=pd.read_csv(refdir/'v3/bench_runs.csv')
    baseline=simulate(ob.NOMINAL, ob.SCEN, ob.PAR);rows=[]
    for _,v in vectors.iterrows():
        r=simulate(ob.vec_to_ctrl(v[ob.NAMES].to_numpy(float)),ob.SCEN,ob.PAR)
        ft,fe,fa,fp=ob.terms(r,baseline,ob.SCEN.T_amb_C)
        rows.append(dict(algo=v.algo,run=v.run,J=sum(ob.W[k]*val for k,val in zip(('T','E','age','perf'),(ft,fe,fa,fp))),
            nfe=original[(original.algo==v.algo)&(original.run==v.run)].iloc[0].nfe,
            fT=ft,fE=fe,fAge=fa,fPerf=fp,Tmax=r['Tmax_C'],shortfall_pct=100*r['shortfall_frac'],kWh100=r['kWh_per_100km'],loss100=r['loss_pct_per_100km']))
    cols=[c for c in rows[0] if c!='nfe'];save('v3/bench_runs.csv',rows,cols)
    # Stats require decision vectors/convergence traces: explicit archived inputs, not regenerated search histories.
    for name in ('bench_vectors.csv','bench_conv.csv'):shutil.copy2(refdir/'v3'/name,out/'v3'/name)
    for name in ('tab7_kontrol.csv','tab8_rejen.csv','tab10_duyarlilik.csv'):
        rows=[]
        for _,v in pd.read_csv(refdir/'v3'/name).iterrows():
            s=Scenario(cycle=v.get('cycle','UDDS' if name=='tab8_rejen.csv' else 'WLTP'),T_amb_C=25.,SoH0=.8,soc0=.9)
            p=ob.PAR;w=dict(ob.W);extra={}
            if name=='tab7_kontrol.csv':extra['cycle']=s.cycle
            elif name=='tab8_rejen.csv':p=dataclasses.replace(p,regen_share=0. if v.tag=='disabled' else .7)
            else:
                extra['level']=v.level
                if v.tag=='ambient':s=dataclasses.replace(s,T_amb_C=float(v.level.split()[0]))
                if v.tag=='SoH':s=dataclasses.replace(s,SoH0=float(v.level.split()[0])/100)
                if v.tag=='C_th':p=dataclasses.replace(p,C_cell_J_K=p.C_cell_J_K*float(v.level[1:]))
                if v.tag=='UA_cool':p=dataclasses.replace(p,UA_cool_pack_W_K=p.UA_cool_pack_W_K*float(v.level[1:]))
                if v.tag=='k_R,true':p=dataclasses.replace(p,kR_true=float(v.level))
                if v.tag=='no performance term':ob.W.update(perf=0.,T=.25,E=.3,age=.45)
            baseline=simulate(ob.NOMINAL,s,ob.PAR if name=='tab8_rejen.csv' else p)
            x=v[ob.NAMES].to_numpy(float)
            row=kc.row(v.tag,v['mode'],x,s,p,baseline,**extra)
            row.update(dict(zip(ob.NAMES,x)));rows.append(row)
            ob.W.clear();ob.W.update(w)
        save('v3/'+name,rows)
    import pareto
    rows=[]
    for _,v in pd.read_csv(refdir/'v3/pareto_front.csv').iterrows():
        x=v[ob.NAMES].to_numpy(float);f,r=pareto.objs(x)
        rows.append(dict(id=v.id,**dict(zip(ob.NAMES,x)),fT=f[0],fCool=f[1],fAge=f[2],fPerf=f[3],Tmax=r['Tmax_C'],Tend=r['T_end_C'],coolWh=1000*r['E_cool_kWh'],loss100=r['loss_pct_per_100km'],shortfall_pct=100*r['shortfall_frac'],viol=r['n_violations'],kWh100=r['kWh_per_100km']))
    save('v3/pareto_front.csv',rows)
    from faz3c_pareto import TRAIN, TEST, row as transfer_row
    from optimize import vec_to_ctrl, NOMINAL
    rows=[transfer_row('fixed',np.nan,NOMINAL,n,s,p,'train' if i<len(TRAIN) else 'test') for i,(n,s,p) in enumerate(TRAIN+TEST)]
    for _,v in pd.read_csv(refdir/'faz3c_vectors.csv').iterrows():
        ctrl=vec_to_ctrl(v['mode'],v[['c_dis','c_ch','g_soh','T_der','T_set','Kp','log10Ki']].to_numpy(float))
        for split,suite in [('train',TRAIN),('test',TEST)]:
            rows += [transfer_row(v['mode'],v.eps,ctrl,n,s,p,split) for n,s,p in suite]
    save('faz3c_test.csv',rows)
    return checks

def run(args):
    work=Path(args.work).resolve() if args.work else ROOT/'runs'/f'{args.stage}_{time.strftime("%Y%m%d_%H%M%S")}'
    if work.exists():raise SystemExit('Work directory already exists; choose a new --work directory.')
    work.mkdir(parents=True)
    shutil.copytree(ROOT/'yeni_calisma',work/'yeni_calisma',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.nbc','*.nbi'))
    out=work/'yeni_calisma/sonuclar';(out/'v3').mkdir(parents=True)
    (work/'yeni_calisma/sekiller/v3').mkdir(parents=True)
    stages=list(STAGES)[1:] if args.stage=='all-python' else [args.stage]
    # Full pipeline order makes dependencies explicit.
    if args.stage=='all-python':stages=['lu','cora','benchmark','controllers','pareto','grids','revisions','sensitivity','transfer']
    if 'lu' in stages:shutil.copytree(ROOT/'Battery Degradation Datasets (Two Types of Lithium-ion Batteries)',work/'Battery Degradation Datasets (Two Types of Lithium-ion Batteries)')
    if 'cora' in stages:
        src=Path(args.cora_dir).resolve() if args.cora_dir else ROOT/'matlab_simulink_project/external_validation/CORA_WLTP'
        for item in json.loads((ROOT/'provenance/cora_raw_manifest.json').read_text()):
            p=src/item['name']
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
                raise SystemExit(f'Missing/changed CORA input: {p}. Extract the companion raw-data ZIP first.')
        shutil.copytree(src,work/'matlab_simulink_project/external_validation/CORA_WLTP')
    regenerated_inputs=[]
    if 'cora' in stages:regenerated_inputs+=['cora_R_soc_T.csv','cora_ocv_soc.csv','cora_ocv_curve.csv']
    if 'lu' in stages:regenerated_inputs+=['lu_soh_trajectories.csv']
    for name in regenerated_inputs:
        (work/'yeni_calisma/veri'/name).unlink(missing_ok=True)
    archived=[]
    if args.stage=='quick':archived=['v3/bench_vectors.csv','v3/bench_conv.csv']
    if args.stage=='revisions':
        for name in ('faz3d_grid.csv','faz6_grid.csv'):
            shutil.copy2(ROOT/'reference_results'/name,out/name);archived.append(name)
    env=os.environ.copy();env.update(PYTHONUTF8='1',MPLBACKEND='Agg',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    report={'stage':args.stage,'python':sys.version,'platform':platform.platform(),'archived_dependency_inputs':archived,'commands':[],'comparisons':[]}
    start=time.time();failed=False
    for stage in stages:
        for script in STAGES[stage]:
            print(f'RUN {stage}: {script}',flush=True)
            t=time.time()
            if script=='@replay':
                report['comparisons']+=replay(work);continue
            with (work/(stage+'_'+Path(script).stem+'.log')).open('w',encoding='utf-8') as log:
                proc=subprocess.run([sys.executable,str(work/'yeni_calisma/kod'/script)],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
            report['commands'].append({'script':script,'exit_code':proc.returncode,'seconds':round(time.time()-t,3)})
            if proc.returncode:failed=True;break
        if failed:break
    already={x['file'] for x in report['comparisons']}
    for actual in sorted(out.rglob('*.csv')):
        name=actual.relative_to(out).as_posix();expected=ROOT/'reference_results'/name
        if name in archived or name in already:continue
        if args.stage=='quick' and name in ('v3/bench_vectors.csv','v3/bench_conv.csv'):continue
        if expected.exists():report['comparisons'].append(compare(actual,expected))
    for name in regenerated_inputs:
        actual=work/'yeni_calisma/veri'/name;expected=ROOT/'yeni_calisma/veri'/name
        if actual.exists():report['comparisons'].append(compare(actual,expected))
        else:report['comparisons'].append({'file':name,'pass':False,'error':'regenerated input missing'})
    checked={c['file'] for c in report['comparisons']}
    for stage in stages:
        for name in EXPECTED[stage]:
            if name not in checked:report['comparisons'].append({'file':name,'pass':False,'error':'required output not checked'})
    report['elapsed_seconds']=round(time.time()-start,3)
    report['pass']=not failed and bool(report['comparisons']) and all(x['pass'] for x in report['comparisons'])
    (work/'validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2));print('REPORT',work/'validation_report.json')
    return report['pass']

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['verify','compare',*STAGES,'all-python'])
    parser.add_argument('--work',help='New output directory; never overwrites an existing directory')
    parser.add_argument('--cora-dir',help='Directory containing all 410 original CORA parquet files')
    parser.add_argument('--actual');parser.add_argument('--expected')
    args=parser.parse_args()
    if args.stage=='verify':ok=verify()
    elif args.stage=='compare':
        result=compare(Path(args.actual),Path(args.expected).resolve());print(json.dumps(result,indent=2));ok=result['pass']
    else:ok=run(args)
    sys.exit(0 if ok else 1)

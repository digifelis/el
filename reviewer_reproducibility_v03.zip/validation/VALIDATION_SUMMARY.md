# Validation performed during packaging

All 36 reference result CSV files were regenerated and compared successfully. Four processed-data CSVs were also regenerated and checked. The full Python stages were executed individually in dependency-compatible isolated work directories; the single combined `all-python` command was not itself run end-to-end. Standalone revisions explicitly used archived grids, which were separately regenerated and matched.

Comparisons use rtol=1e-7, atol=1e-9; timing is excluded. See the individual JSON reports and `coverage.csv` for row-level scope. These are numerical reproduction results, not a claim that every manuscript assumption is experimentally validated.

| Stage | Result | Measured seconds | Compared CSVs |
|---|---|---:|---:|
| lu | PASS | 29.5 | 3 |
| cora | PASS | 51.0 | 6 |
| benchmark | PASS | 316.6 | 6 |
| controllers | PASS | 316.7 | 3 |
| pareto | PASS | 21.9 | 3 |
| grids | PASS | 31.1 | 9 |
| revisions | PASS | 39.6 | 4 |
| sensitivity | PASS | 19.4 | 1 |
| transfer | PASS | 169.9 | 3 |
| matlab | PASS | 1003.2 | 2 |

The MATLAB run includes 18 main scenarios and eight BMS-error scenarios. It used a disposable copy of the author's licensed R2025b model, a fresh build of 12 referenced simulation targets, and the documented MSVC NaN workaround. All 26 rows matched. The Composer model was not recreated from the GUI instructions during this validation; the existing author's configured model was copied. Model fingerprints are supplied separately.

Additional checks: five physical consistency tests; ZIP extraction followed by a successful quick check (~12 s); a new virtual environment with all pinned requirements installed and `pip check` passing; quick, Lu and CORA repeated successfully there; intentional numeric corruption, missing row, and missing numeric value rejected; a modified README rejected by the integrity checker; raw ZIP CRC and all 410 Parquet SHA-256 checks passed.

The manuscript and all original research-source hashes remained unchanged. Full experiment reruns used the research environment with the same pinned scientific package versions; only quick, Lu and CORA were additionally rerun in the freshly installed environment. No Linux/macOS test or independent external reviewer test is claimed.

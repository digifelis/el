# Reviewer reproducibility package — manuscript v03

This package accompanies **Resistance- and state-of-health-aware current limiting for electric-vehicle battery packs: what it buys, what it costs, and when it fails**. It contains executable research code, input data, saved control vectors, immutable expected CSV results, and automatic numerical comparisons. The manuscript and original research workspace are not modified by these commands.

## Start here

Use Python **3.11** (tested with 3.11.5, Windows x64). The pinned requirements were also installed into a fresh virtual environment; quick, Lu and CORA checks passed there. Extract the ZIP into a writable folder. From that folder:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python reproduce.py verify
.venv\Scripts\python reproduce.py quick
```

On Linux/macOS replace `.venv\Scripts\python` with `.venv/bin/python`. Other operating systems have not been validated here. Installation needs Internet access; simulation is offline. No GPU is required. Reserve at least 4 GB of disk for core experiments and more for raw-data runs. Multiprocess grids use available CPU cores; allow adequate RAM or run those stages on a workstation.

Each command creates a **new** directory under `runs/`. To choose its location, pass `--work NEW_DIRECTORY`. Existing directories are rejected. Logs, regenerated CSVs/figures, and `validation_report.json` are written there. Exit code 0 means all comparisons performed by that stage passed; exit code 1 means a failure. Read the report to see exactly which outputs were checked. No result is silently rounded to force agreement.

`quick` runs five independent physical consistency tests and **re-simulates**, using archived vectors, 180 optimizer solutions, 36 controller/ablation cases, 48 Pareto points, and 272 transfer cases. It recomputes optimizer statistics. It does **not** rerun optimization: NFE counts and convergence trajectories are archived metadata. Convergence figures in this mode visualize those archived trajectories. Use `benchmark` for a new search and new trajectories.

Numerical comparisons use `abs(actual - expected) <= 1e-9 + 1e-7*abs(expected)`, with matching missing values allowed. Text and row order must match. Wall-clock timing is excluded. Stochastic searches have fixed seeds, but floating-point/library differences can still alter search paths; such differences are reported as failures, not hidden. Images are regenerated; their binary PDF/PNG bytes are not compared.

## Recompute experiments

Run stages independently (the `python` below is your activated environment's Python):

| Command | What is recomputed | Main outputs |
|---|---|---|
| `python reproduce.py lu` | Raw Excel cell trajectories, fits and figures | `lu_fade_fit.csv`, `v3/tab6_lu.csv`; figures 4–7 |
| `python reproduce.py benchmark` | 6 optimizers × 30 seeds; 24 candidates; 41 iterations, hybrid 40 | `bench_runs/vectors/conv.csv`, Tables IX, XIV, XV; figures 8, 10, 11 |
| `python reproduce.py controllers` | Control comparisons, regeneration, ablations; 5 restarts each | Tables VII, VIII, X |
| `python reproduce.py pareto` | NSGA-II, 48 population, 40 generations | Pareto front, selections, summary; figure 9 |
| `python reproduce.py grids` | 17-scenario controller and myopic grids; held-out scheduling | `faz3d_*`, `faz6_*`, `faz7_*` |
| `python reproduce.py revisions` | SoH equivalence, finer unaware grid, shared-setting test, resistance error | `rev_soh_*`, `rev_direnc_orani.csv` |
| `python reproduce.py sensitivity` | Physical parameter and BMS-information perturbations | `faz4_duyarlilik.csv` |
| `python reproduce.py transfer` | Differential evolution on 8 training scenarios; evaluation on 9 test scenarios | `faz3c_*` |
| `python reproduce.py cora` | Resistance/OCV extraction, voltage holdout, thermal fit/holdout | `cora_*`; requires raw companion |
| `python reproduce.py all-python` | All above in dependency order, including raw data fits | Full Python pipeline |

Standalone `revisions` uses the archived `faz3d_grid.csv` and `faz6_grid.csv` as explicitly identified inputs. `all-python` regenerates those grids first. No archived result CSV is installed as a generated output in the full pipeline. Core simulation uses the supplied processed OCV and fixed calibration constants; fitting raw data reports fitted values but does not silently rewrite constants in `evbms.py`. The physical model uses rounded constants as in the manuscript.

Seeds: optimizer benchmark `1000..1029`; comparison restarts `0..4`; NSGA-II `42`, hypervolume Monte Carlo `4242`; transfer differential evolution `7`. Expected function evaluations are 1008 per benchmark run except GA (967), and 1968 for NSGA-II. Runtime depends on hardware. See `validation/` for measured stage times and the exact scope completed during packaging; long stages can take many minutes.

## Raw CORA data

The separate `reviewer_reproducibility_v03_CORA_raw.zip` contains the 410 original Parquet files (~1.38 GB before compression) and the source README/manifest. Extract it **inside this package folder**, producing:

```
matlab_simulink_project/external_validation/CORA_WLTP/Qtzl_Cycle_...
```

Alternatively use `python reproduce.py cora --cora-dir PATH_TO_CORA_WLTP`. All 410 file SHA-256 values are checked against `provenance/cora_raw_manifest.json` before fitting. Selection is based on the sorted corpus; dropping unused files can change train/test selection. The original source README is retained for attribution and column definitions.

## MATLAB closed-loop experiments

MATLAB R2025b, Simulink and Powertrain Blockset are required. These results are a separate vehicle model, not the Python reduced model. MathWorks model files are not redistributed. See `MATLAB_REPRODUCTION.md` and the supplied author-written `.m` files. Python success does not establish MATLAB reproduction. The packaging validation report explicitly distinguishes MATLAB status.

## Contents and interpretation

* `yeni_calisma/kod/`: research implementations; numerical Python code retained from the study. `reviewer_derived.py` is a new packaging adapter that regenerates scenario, oracle and cooling-matched summaries previously exported interactively, using the unchanged model and grid outputs.
* `yeni_calisma/veri/`: processed model inputs and driving cycles.
* `Battery Degradation Datasets (Two Types of Lithium-ion Batteries)/`: original Dataset #3/#5 Excel workbooks.
* `reference_results/`: frozen author results used only as comparison targets or explicitly named archived inputs.
* `provenance/`: raw-data inventory, source attribution and portability-change record.
* `validation/`: reports from actual executions during package preparation.
* `KNOWN_ISSUES.md`: manuscript/implementation discrepancies and scope limitations.
* `MANIFEST.json`: SHA-256 inventory of distributed package files (excluding itself and runtime outputs).

Table numbering follows v03. Tables I–V include notation, assumptions and protocols, not independent experiments. Later scenario/oracle/closed-loop tables draw on the named `faz*` CSVs. Document-generation scripts that copy old manuscript tables were deliberately omitted: numerical CSVs and executable stages are the reproducibility evidence. Figures 1–3 are conceptual diagrams, not simulated data. This package does not automatically rewrite or rebuild the Word manuscript.

Before citing this package, use its actual deposited DOI or repository URL. No public deposit has been created by preparing these local files. See `DATA_AVAILABILITY_DRAFT.md` for a statement to complete after deposition.

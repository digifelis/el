# Data and result dictionary

The scripts retain the original Turkish filenames: `veri` = data, `sonuclar` = results, `sekiller` = figures, `kod` = code. CSVs use decimal points and comma separators. A missing grid optimum means no candidate satisfies the specified constraint; it is not zero loss.

## Inputs

* `cora_ocv_curve.csv`: `soc` in percent, `ocv_cell_V` in volts, `n` samples per bin. The simulator divides SoC by 100, adds endpoint anchors, and enforces monotonic voltage. See `evbms.py` for the exact operations.
* `cora_R_soc_T.csv`, `cora_ocv_soc.csv`: diagnostic resistance and rest-voltage bins from CORA; the model's R anchors are coded explicitly.
* `lu_soh_trajectories.csv`: cell-specific normalized capacity trajectories from the two Excel workbooks; the two chemistries are not pooled.
* `drive_cycles/`: time in seconds, WLTP speed in km/h, EPA UDDS/US06 speed in mph; converted to m/s by the simulator.
* CORA source Parquet column names include their units. Preserve the original README and use the exact corpus manifest. Sensor filtering and cycle selection are in `cora_*` scripts.

## Shared model and controller conventions

* SoC and SoH are fractions internally; scenario names such as `SoH80` denote 0.80. Temperatures and derating/setpoint thresholds are °C; Arrhenius expressions convert them to kelvin.
* `c_dis`, `c_ch`: discharge/charge C-rate limit multipliers. `g`, `g_soh`, `g_SoH`: health gain (or the mode-specific myopic/MPC tuning parameter). `T_der`, `T_set`: °C. `Kp`, `Ki`: cooling PI gains. `log10Ki` is converted by `10**log10Ki`.
* `fixed`: nominal fixed controller. `unaware`: tuned without explicit SoH scaling. `aware_S`: SoH scaling. `aware_RS`: SoH and resistance/voltage-aware limits. `myopic` and `mpc`: the implemented comparator laws, not external toolboxes.
* The reduced model has 96S22P, 2.54-Ah nominal cells, 1-s time steps. The closed-loop reference vehicle has a separate 96S47P, 2.6958-Ah-cell plant.

## Numerical results

* `Tmax`, `Tmax_C`, `Tend`: °C. `coolWh`, `regen_Wh`: Wh; fields ending `_kWh` are kWh. `kWh100`, `kWh_per_100km`: kWh per 100 km. `loss100`, `loss_per100km`: modeled capacity-loss proxy in percent per 100 km.
* `loss_rel`, `kWh_rel`: ratios to the scenario's fixed reference; 1.0 is equal to that reference. A reported difference in percentage points is 100 times a difference between these ratios, not a fractional relative improvement.
* `shortfall_pct`: total unmet traction-energy fraction × 100. `short_ind` / `short_ind_pct`: max(0, total shortfall minus physical-reference shortfall) × 100. `eps` in `faz3c_*` is a fraction; `eps` in grid-summary CSVs is in percent. Do not interchange them.
* `outwindow_s`, `viol_s`, `window_s`, `n_violations`: voltage-window violation duration/count (1 s per reduced-model sample). In MATLAB CSVs `t_outside_window_s` integrates elapsed time and is not simply a sample count.
* `J`: scalar objective; `fT`, `fE`, `fAge`, `fPerf`: its terms. Benchmark/comparison weights are 0.20/0.25/0.35/0.20 except the explicitly labeled no-performance ablation. See KNOWN_ISSUES.md for the +0.5 °C regularizer and regeneration normalization.
* Pareto `fT`, `fCool`, `fAge`, `fPerf` use different normalization from scalar `fT`: temperature rise/30, cooling Wh/250, aging ratio, performance penalty. `id` identifies the final population position. `selection` marks the feasible knee and individual extrema.
* `nfe`, `nfev`: objective evaluation counts. `run`: zero-based benchmark replicate. `it`: one-based stored convergence iteration. `time_s`, `wall_s`: measured runtime, excluded from equality checks.
* `tab15_pairs.csv`: `winA`, `winB` compare paired seed runs; `p` is the two-sided exact sign-test p-value; `holm_p` is multiplicity-adjusted; `cliff` and `A12` compare all cross-pairs of the two distributions. Smaller J is better.
* MATLAB `speed_RMSE_mps`: speed tracking RMSE in m/s; `Vcell_min/max`: per-cell V; `I_min_A`, `I_max_A`: pack A; `Ah_throughput`: integral of absolute pack current / 3600. `soc_end_pct` is percent. BMS temperature input is the scenario temperature, not simulated cell temperature.

The executable scripts are the definitive description of aggregations. The reference CSVs retain full precision; manuscript tables round values for display.
